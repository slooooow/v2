
import { CategoryConfig } from '../types/wordpress';
import { TrendingUp, BarChart3, Building2, Cpu, Bitcoin } from 'lucide-react';

export const CATEGORY_CONFIGS: CategoryConfig[] = [
  {
    slug: 'mercado',
    name: 'Mercado',
    color: '#3b82f6',
    icon: TrendingUp
  },
  {
    slug: 'acoes',
    name: 'Ações',
    color: '#10b981',
    icon: BarChart3
  },
  {
    slug: 'fiis',
    name: 'FIIs',
    color: '#f59e0b',
    icon: Building2
  },
  {
    slug: 'tecnologia',
    name: 'Tecnologia',
    color: '#8b5cf6',
    icon: Cpu
  },
  {
    slug: 'criptomoedas',
    name: 'Criptomoedas',
    color: '#ec4899',
    icon: Bitcoin
  }
];

export const getCategoryConfig = (slug: string): CategoryConfig | undefined => {
  return CATEGORY_CONFIGS.find(config => config.slug === slug);
};

export const getCategoryColor = (slug: string): string => {
  const config = getCategoryConfig(slug);
  return config?.color || '#6b7280';
};

export const getCategoryName = (slug: string): string => {
  const config = getCategoryConfig(slug);
  return config?.name || slug;
};

export const getCategoryIcon = (slug: string) => {
  const config = getCategoryConfig(slug);
  return config?.icon || TrendingUp;
};
