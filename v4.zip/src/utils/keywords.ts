
export const extractKeywords = (content: string, title: string = ''): string[] => {
  // Remove HTML tags and normalize text
  const cleanText = content.replace(/<[^>]*>/g, ' ').toLowerCase();
  const cleanTitle = title.replace(/<[^>]*>/g, ' ').toLowerCase();
  
  // Combine title and content, giving more weight to title
  const fullText = `${cleanTitle} ${cleanTitle} ${cleanText}`;
  
  // Common Portuguese stop words to exclude
  const stopWords = new Set([
    'a', 'o', 'e', 'é', 'de', 'do', 'da', 'em', 'um', 'uma', 'para', 'com', 'não', 
    'que', 'se', 'por', 'mais', 'como', 'mas', 'foi', 'ao', 'ele', 'ela', 'até', 
    'pelo', 'pela', 'na', 'no', 'os', 'as', 'dos', 'das', 'nos', 'nas', 'tem', 
    'ter', 'ou', 'são', 'seu', 'sua', 'seus', 'suas', 'este', 'esta', 'isso', 
    'isto', 'aquele', 'aquela', 'pode', 'podem', 'vai', 'vão', 'será', 'sobre',
    'quando', 'onde', 'muito', 'muita', 'muitos', 'muitas', 'também', 'ainda',
    'já', 'só', 'bem', 'assim', 'depois', 'antes', 'então', 'agora', 'aqui',
    'ali', 'lá', 'hoje', 'ontem', 'amanhã', 'sempre', 'nunca', 'nada', 'tudo'
  ]);
  
  // Extract words (minimum 3 characters)
  const words = fullText
    .match(/\b[a-záàâãéêíóôõúç]+\b/g) || [];
  
  // Count word frequency
  const wordCount = new Map<string, number>();
  words.forEach(word => {
    if (word.length >= 3 && !stopWords.has(word)) {
      wordCount.set(word, (wordCount.get(word) || 0) + 1);
    }
  });
  
  // Sort by frequency and get top keywords
  const sortedWords = Array.from(wordCount.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([word]) => word.charAt(0).toUpperCase() + word.slice(1));
  
  return sortedWords;
};
