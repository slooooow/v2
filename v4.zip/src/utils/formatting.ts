
export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  }).format(date);
};

export const formatRelativeDate = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
  
  if (diffInHours < 1) {
    return 'Agora mesmo';
  } else if (diffInHours < 24) {
    return `${diffInHours}h atrás`;
  } else if (diffInHours < 24 * 7) {
    const days = Math.floor(diffInHours / 24);
    return `${days}d atrás`;
  } else {
    return formatDate(dateString);
  }
};

export const stripHtml = (html: string): string => {
  const tmp = document.createElement('div');
  tmp.innerHTML = html;
  return tmp.textContent || tmp.innerText || '';
};

export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength).trim() + '...';
};

export const getImageUrl = (post: any, size: string = 'medium_large'): string => {
  if (post._embedded?.['wp:featuredmedia']?.[0]) {
    const media = post._embedded['wp:featuredmedia'][0];
    return media.media_details?.sizes?.[size]?.source_url || media.source_url;
  }
  return '/placeholder.svg';
};

export const getAuthorName = (post: any): string => {
  if (post._embedded?.author?.[0]) {
    return post._embedded.author[0].name;
  }
  return 'Finver Finance';
};

export const getCategoryFromPost = (post: any): string => {
  if (post._embedded?.['wp:term']?.[0]?.[0]) {
    return post._embedded['wp:term'][0][0].slug;
  }
  return 'mercado';
};

export const getCategoryColor = (slug: string): string => {
  const colors: { [key: string]: string } = {
    mercado: '#3b82f6',
    acoes: '#10b981',
    fiis: '#f59e0b',
    tecnologia: '#8b5cf6',
    criptomoedas: '#ec4899'
  };
  return colors[slug] || '#6b7280';
};

export const getCategoryName = (slug: string): string => {
  const names: { [key: string]: string } = {
    mercado: 'Mercado',
    acoes: 'Ações',
    fiis: 'FIIs',
    tecnologia: 'Tecnologia',
    criptomoedas: 'Criptomoedas'
  };
  return names[slug] || slug;
};
