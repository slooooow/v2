
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { MessageCircle, Calendar } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { wordpressApi } from '../services/wordpress';
import { formatDate } from '../utils/formatting';
import LoadingSpinner from './LoadingSpinner';
import CommentForm from './CommentForm';

interface CommentsSectionProps {
  postId: number;
  className?: string;
}

const CommentsSection: React.FC<CommentsSectionProps> = ({ 
  postId, 
  className = "" 
}) => {
  const { data: comments = [], isLoading, refetch } = useQuery({
    queryKey: ['comments', postId],
    queryFn: () => wordpressApi.getCommentsByPost(postId),
    enabled: !!postId,
  });

  const handleCommentAdded = () => {
    refetch();
  };

  // Função para obter avatar do usuário
  const getUserAvatar = (authorId: string) => {
    // Tentar obter avatar salvo no localStorage
    const savedAvatar = localStorage.getItem(`avatar_${authorId}`);
    if (savedAvatar) {
      return savedAvatar;
    }
    
    // Fallback para Gravatar baseado no ID do autor
    const hash = btoa(authorId.toString()).replace(/=+$/, '');
    return `https://www.gravatar.com/avatar/${hash}?s=40&d=identicon&r=g`;
  };

  if (isLoading) {
    return (
      <div className={`space-y-6 ${className}`}>
        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6">
          <div className="flex items-center justify-center py-8">
            <LoadingSpinner size="small" text="Carregando comentários..." />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Formulário para novos comentários */}
      <CommentForm postId={postId} onCommentAdded={handleCommentAdded} />

      {/* Lista de comentários */}
      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6">
        <div className="flex items-center space-x-2 mb-6">
          <MessageCircle className="w-5 h-5 text-blue-400" />
          <h3 className="text-xl font-bold text-white">
            Comentários ({comments.length})
          </h3>
        </div>

        {comments.length === 0 ? (
          <div className="text-center py-8">
            <MessageCircle className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">Ainda não há comentários neste artigo.</p>
            <p className="text-gray-500 text-sm mt-2">Seja o primeiro a comentar!</p>
          </div>
        ) : (
          <div className="space-y-6">
            {comments.map((comment) => (
              <div 
                key={comment.id} 
                className="border-l-2 border-blue-500/30 pl-4 py-2"
              >
                <div className="flex items-center space-x-3 mb-3">
                  <Avatar className="w-10 h-10">
                    <AvatarImage 
                      src={getUserAvatar(comment.author.toString())} 
                      alt={comment.author_name}
                    />
                    <AvatarFallback className="bg-blue-600 text-white font-bold text-sm">
                      {comment.author_name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <span className="text-white font-semibold text-sm">
                        {comment.author_name}
                      </span>
                      <div className="flex items-center space-x-1 text-gray-400 text-xs">
                        <Calendar size={12} />
                        <span>{formatDate(comment.date)}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div 
                  className="text-gray-300 text-sm leading-relaxed prose prose-sm prose-invert max-w-none [&>p]:mb-2 [&>p:last-child]:mb-0 ml-13"
                  dangerouslySetInnerHTML={{ 
                    __html: comment.content.rendered 
                  }}
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CommentsSection;
