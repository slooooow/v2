
import React from 'react';
import { Mail, TrendingUp, Bell, ArrowRight } from 'lucide-react';

interface CTABannerProps {
  type: 'newsletter' | 'analysis';
}

const CTABanner: React.FC<CTABannerProps> = ({ type }) => {
  const configs = {
    newsletter: {
      icon: Mail,
      title: 'Assine Nossa Newsletter',
      subtitle: 'Receba as principais notícias do mercado financeiro direto no seu e-mail',
      buttonText: 'Assinar Gratuitamente',
      gradient: 'from-blue-600 to-purple-600',
      floatingIcons: [Mail, Bell, TrendingUp]
    },
    analysis: {
      icon: TrendingUp,
      title: 'Análises Exclusivas Premium',
      subtitle: 'Tenha acesso a relatórios detalhados e recomendações de investimento',
      buttonText: 'Conhecer Premium',
      gradient: 'from-emerald-600 to-blue-600',
      floatingIcons: [TrendingUp, Bell, Mail]
    }
  };

  const config = configs[type];
  const IconComponent = config.icon;

  return (
    <div className="relative my-12 overflow-hidden">
      <div className={`relative glass rounded-3xl p-8 lg:p-12 bg-gradient-to-r ${config.gradient}/20`}>
        {/* Elementos flutuantes de fundo */}
        <div className="absolute inset-0 overflow-hidden">
          {config.floatingIcons.map((Icon, index) => (
            <Icon
              key={index}
              className={`absolute text-white/10 animate-float ${
                index === 0 ? 'top-4 right-8 w-12 h-12' :
                index === 1 ? 'bottom-6 left-12 w-8 h-8 animation-delay-1000' :
                'top-1/2 right-1/4 w-6 h-6 animation-delay-2000'
              }`}
              style={{
                animationDelay: `${index * 1000}ms`
              }}
            />
          ))}
        </div>

        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between">
          <div className="flex-1 mb-6 lg:mb-0 lg:mr-8">
            <div className="flex items-center space-x-3 mb-4">
              <div className={`w-12 h-12 bg-gradient-to-br ${config.gradient} rounded-xl flex items-center justify-center`}>
                <IconComponent className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl lg:text-3xl font-bold text-white text-glow">
                {config.title}
              </h3>
            </div>
            <p className="text-gray-300 text-lg leading-relaxed max-w-2xl">
              {config.subtitle}
            </p>
          </div>

          <div className="flex-shrink-0">
            <button className={`group relative px-8 py-4 bg-gradient-to-r ${config.gradient} rounded-xl font-semibold text-white transition-all duration-300 hover:scale-105 hover:shadow-glow-lg overflow-hidden`}>
              <span className="relative z-10 flex items-center space-x-2">
                <span>{config.buttonText}</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
              </span>
              
              {/* Efeito de brilho */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </button>
          </div>
        </div>

        {/* Efeito de borda brilhante */}
        <div className="absolute inset-0 rounded-3xl border border-white/20 pointer-events-none" />
      </div>
    </div>
  );
};

export default CTABanner;
