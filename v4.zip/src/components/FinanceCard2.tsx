import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { TrendingUp, TrendingDown, ExternalLink, BarChart3, Globe } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';

interface FinanceCardProps {
  symbol: string;
  isCrypto: boolean;
  token: string;
}

interface BrapiQuote {
  symbol: string;
  shortName?: string;
  longName?: string;
  logourl?: string;
  coinImageUrl?: string;
  coinName?: string;
  coin?: string;
  regularMarketPrice: number;
  regularMarketChange: number;
  regularMarketChangePercent: number;
  currency: string;
  marketCap?: number;
  regularMarketVolume?: number;
  regularMarketDayHigh?: number;
  regularMarketDayLow?: number;
}

interface HistoricalData {
  date: string | number;
  open: number;
  high: number;
  low: number;
  close: number;
  adjustedClose: number;
  volume: number;
}

const FinanceCard: React.FC<FinanceCardProps> = ({ symbol, isCrypto, token }) => {
  // Buscar cotação principal
  const { data: quote, isLoading: loadingQuote, isError } = useQuery<BrapiQuote | null>({
    queryKey: ['quote', symbol, isCrypto],
    queryFn: async () => {
      if (isCrypto) {
        try {
          // Buscar dados da criptomoeda com histórico
          const cryptoUrl = `https://brapi.dev/api/v2/crypto?coin=${symbol.toLowerCase()}&currency=BRL&range=5d&interval=1d&token=${token}`;
          
          const res = await fetch(cryptoUrl);
          
          if (!res.ok) {
            throw new Error(`HTTP error! status: ${res.status}`);
          }
          
          const json = await res.json();
          
          if (json.coins && json.coins.length > 0) {
            const coinData = json.coins[0];
            
            // Mapear os dados para o formato esperado
            return {
              symbol: coinData.coin || coinData.symbol || symbol.toUpperCase(),
              shortName: coinData.coin || coinData.symbol,
              longName: coinData.coinName || coinData.name || coinData.coin,
              coinName: coinData.coinName,
              coin: coinData.coin,
              coinImageUrl: coinData.coinImageUrl || coinData.logo,
              regularMarketPrice: coinData.regularMarketPrice || coinData.price || coinData.lastPrice,
              regularMarketChange: coinData.regularMarketChange || coinData.change || 0,
              regularMarketChangePercent: coinData.regularMarketChangePercent || coinData.changePercent || 0,
              regularMarketDayHigh: coinData.regularMarketDayHigh || coinData.dayHigh,
              regularMarketDayLow: coinData.regularMarketDayLow || coinData.dayLow,
              regularMarketVolume: coinData.regularMarketVolume || coinData.volume,
              marketCap: coinData.marketCap,
              currency: coinData.currency || 'BRL',
              historicalDataPrice: coinData.historicalDataPrice || []
            } as BrapiQuote & { historicalDataPrice: HistoricalData[] };
          }
          
          return null;
          
        } catch (error) {
          console.error(`Erro ao buscar crypto ${symbol}:`, error);
          return null;
        }
      } else {
        // Endpoint para ações (mantém igual)
        const url = `https://brapi.dev/api/quote/${symbol}?range=5d&interval=1d&token=${token}`;
        
        const res = await fetch(url);
        const json = await res.json();
        
        if (json.results && json.results.length > 0) {
          return json.results[0] as BrapiQuote;
        }
        return null;
      }
    },
    enabled: !!symbol && !!token,
    refetchInterval: 30000,
    retry: 2,
  });

  // Loading
  if (loadingQuote) {
    return (
      <Card className="bg-gray-800/50 border-gray-700">
        <CardContent className="p-4">
          <div className="animate-pulse flex space-x-4">
            <div className="rounded-full bg-gray-600 h-8 w-8"></div>
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-gray-600 rounded w-3/4"></div>
              <div className="h-4 bg-gray-600 rounded w-1/2"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isError || !quote) {
    return null;
  }

  // Formatadores
  const formatPrice = (price: number, currency: string) =>
    new Intl.NumberFormat('pt-BR', { 
      style: 'currency', 
      currency: currency || 'BRL' 
    }).format(price);

  const formatPercent = (pct: number) =>
    `${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%`;

  const formatLargeNumber = (num: number) => {
    if (num >= 1e12) return `${(num / 1e12).toFixed(2)}T`;
    if (num >= 1e9) return `${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `${(num / 1e6).toFixed(2)}M`;
    if (num >= 1e3) return `${(num / 1e3).toFixed(2)}K`;
    return num.toFixed(0);
  };

  // Dados do card
  const logoUrl = isCrypto ? quote.coinImageUrl : quote.logourl;
  const displayName = quote.longName || quote.coinName || quote.shortName || quote.symbol;
  const isPositive = quote.regularMarketChangePercent >= 0;

  // Função para truncar nome
  const truncateName = (name: string, maxLength: number = 20) => {
    if (name.length <= maxLength) return name;
    return name.slice(0, maxLength - 3) + '...';
  };

  // Dados do gráfico - agora suporta criptomoedas também
  const histData = (quote as any)?.historicalDataPrice;
  const chartData = histData && Array.isArray(histData)
    ? histData.slice(-10).map((item: HistoricalData, i: number) => ({
        time: i,
        price: item.close ?? item.adjustedClose,
        timestamp: typeof item.date === 'number' ? new Date(item.date * 1000).toLocaleDateString() : item.date,
      }))
    : [];

  // Função para abrir análises externas
  const openExternalAnalysis = () => {
    if (isCrypto) {
      // Para criptomoedas, abrir CoinMarketCap ou CoinGecko
      const coinGeckoUrl = `https://www.coingecko.com/pt/moedas/${quote.coin?.toLowerCase() || symbol.toLowerCase()}`;
      window.open(coinGeckoUrl, '_blank');
    } else {
      // Para ações, manter o Finver
      const finverUrl = `https://finver.finance/analisys/${encodeURIComponent(quote.symbol)}`;
      window.open(finverUrl, '_blank');
    }
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-lg flex items-center justify-between">
          <div className="flex items-center space-x-3 min-w-0 flex-1">
            {logoUrl && (
              <img
                src={logoUrl}
                alt={`Logo ${displayName}`}
                className="w-8 h-8 rounded-full bg-white p-1 flex-shrink-0"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            )}
            <div className="min-w-0 flex-1">
              <span className="block truncate font-semibold text-sm sm:text-base" title={displayName}>
                {truncateName(displayName, 18)}
              </span>
              {isCrypto && (
                <span className="text-xs text-gray-400">
                  {quote.coin || quote.symbol}
                </span>
              )}
            </div>
          </div>
          <span className="text-xs sm:text-sm text-gray-400 font-mono flex-shrink-0 ml-2">
            {quote.symbol}
          </span>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Preço e variação */}
        <div className="space-y-2">
          <div className="text-xl sm:text-2xl font-bold text-white">
            {formatPrice(quote.regularMarketPrice, quote.currency)}
          </div>
          <div className={`flex items-center space-x-2 text-sm ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
            {isPositive ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            <span className="font-semibold">
              {formatPrice(quote.regularMarketChange, quote.currency)}
            </span>
            <span className="font-semibold">
              ({formatPercent(quote.regularMarketChangePercent)})
            </span>
          </div>
        </div>

        {/* Informações adicionais para criptomoedas */}
        {isCrypto && (quote.marketCap || quote.regularMarketVolume) && (
          <div className="grid grid-cols-2 gap-4 text-xs text-gray-300">
            {quote.marketCap && (
              <div>
                <span className="text-gray-400">Market Cap:</span>
                <div className="font-semibold">{formatPrice(quote.marketCap, quote.currency)}</div>
              </div>
            )}
            {quote.regularMarketVolume && (
              <div>
                <span className="text-gray-400">Volume 24h:</span>
                <div className="font-semibold">{formatLargeNumber(quote.regularMarketVolume)}</div>
              </div>
            )}
          </div>
        )}

        {/* Máxima e mínima do dia */}
        {(quote.regularMarketDayHigh || quote.regularMarketDayLow) && (
          <div className="text-xs text-gray-300">
            <span className="text-gray-400">Variação do dia:</span>
            <div className="flex justify-between mt-1">
              {quote.regularMarketDayLow && (
                <span>Mín: {formatPrice(quote.regularMarketDayLow, quote.currency)}</span>
              )}
              {quote.regularMarketDayHigh && (
                <span>Máx: {formatPrice(quote.regularMarketDayHigh, quote.currency)}</span>
              )}
            </div>
          </div>
        )}

        {/* Gráfico (para ações e criptomoedas) */}
        {chartData.length > 0 && (
          <div className="h-32">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <XAxis hide />
                <YAxis hide domain={['dataMin', 'dataMax']} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#374151',
                    border: '1px solid #4B5563',
                    borderRadius: '6px',
                    color: '#fff',
                  }}
                  formatter={(value: number) => [formatPrice(value, quote.currency), 'Preço']}
                  labelFormatter={(label) => `Data: ${chartData[label]?.timestamp || 'N/A'}`}
                />
                <Line
                  type="monotone"
                  dataKey="price"
                  stroke={isPositive ? '#10B981' : '#EF4444'}
                  strokeWidth={2}
                  dot={false}
                  connectNulls={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Botões de ação */}
        <div className="space-y-2">
          <Button
            onClick={openExternalAnalysis}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white text-sm"
          >
            {isCrypto ? (
              <>
                <Globe size={16} className="mr-2" />
                Ver no CoinGecko
              </>
            ) : (
              <>
                <ExternalLink size={16} className="mr-2" />
                Análises no Finver
              </>
            )}
          </Button>
          
          {isCrypto && (
            <Button
              onClick={() => {
                const coinMarketCapUrl = `https://coinmarketcap.com/pt-br/currencies/${quote.coin?.toLowerCase() || symbol.toLowerCase()}/`;
                window.open(coinMarketCapUrl, '_blank');
              }}
              variant="outline"
              className="w-full border-gray-600 text-gray-300 hover:bg-gray-700 text-sm"
            >
              <BarChart3 size={16} className="mr-2" />
              CoinMarketCap
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default FinanceCard;

