
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { UserLogin } from '../types/wordpress';
import { useAuth } from '../hooks/useAuth';
import { Link } from 'react-router-dom';

const loginSchema = z.object({
  username: z.string().min(1, 'Username ou email é obrigatório'),
  password: z.string().min(1, 'Senha é obrigatória'),
});

interface LoginFormProps {
  onSuccess?: () => void;
}

const LoginForm: React.FC<LoginFormProps> = ({ onSuccess }) => {
  const { login, isLoading } = useAuth();

  const form = useForm<UserLogin>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  const onSubmit = async (data: UserLogin) => {
    console.log('=== SUBMIT DO FORMULÁRIO ===');
    console.log('Dados do formulário (sem senha):', { username: data.username });
    
    const success = await login(data);
    if (success) {
      form.reset();
      onSuccess?.();
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6">
        <h2 className="text-2xl font-bold text-white mb-6 text-center">Entrar</h2>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Username ou Email</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="Seu username ou email"
                      className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Senha</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="password"
                      placeholder="Sua senha"
                      className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isLoading ? 'Entrando...' : 'Entrar'}
            </Button>
          </form>
        </Form>

        <div className="mt-6 text-center">
          <p className="text-gray-400">
            Não tem uma conta?{' '}
            <Link to="/registro" className="text-blue-400 hover:text-blue-300">
              Criar conta
            </Link>
          </p>
          
          <div className="mt-4 p-3 bg-gray-700/50 rounded-lg">
            <p className="text-xs text-gray-400">
              💡 Use as mesmas credenciais que você usou no registro.<br/>
              Pode ser username ou email + senha.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
