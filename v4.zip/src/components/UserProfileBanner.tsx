import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useProfileSync } from '../hooks/useProfileSync';
import { User, Calendar, Shield, Star, LogOut, Edit, Upload, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { toast } from '@/hooks/use-toast';
import { wordpressApi } from '../services/wordpress';
import { useIsMobile } from '../hooks/use-mobile';

interface UserProfileBannerProps {
  onEditToggle?: (isEditing: boolean) => void;
}

const UserProfileBanner: React.FC<UserProfileBannerProps> = ({ onEditToggle }) => {
  const { user, logout } = useAuth();
  const { triggerSync } = useProfileSync();
  const [profilePhoto, setProfilePhoto] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isMobile = useIsMobile();

  useEffect(() => {
    if (user) {
      const savedAvatar = localStorage.getItem(`avatar_${user.id}`);
      if (savedAvatar) {
        setProfilePhoto(savedAvatar);
      } else if (user.email) {
        const gravatarUrl = getGravatarUrl(user.email);
        setProfilePhoto(gravatarUrl);
      }
    }
  }, [user]);

  // Listen for avatar updates from sync
  useEffect(() => {
    const handleAvatarUpdate = (event: CustomEvent) => {
      if (user && event.detail.userId === user.id) {
        console.log('=== UPDATING AVATAR FROM SYNC ===', event.detail.avatar);
        setProfilePhoto(event.detail.avatar);
      }
    };

    window.addEventListener('avatarUpdate', handleAvatarUpdate as EventListener);
    
    return () => {
      window.removeEventListener('avatarUpdate', handleAvatarUpdate as EventListener);
    };
  }, [user]);

  const getGravatarUrl = (email: string, size: number = 120) => {
    const hash = btoa(email.toLowerCase().trim()).replace(/=+$/, '');
    return `https://www.gravatar.com/avatar/${hash}?s=${size}&d=identicon&r=g`;
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    // Validar tipo de arquivo
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Arquivo inválido",
        description: "Por favor, selecione uma imagem válida (JPG, PNG, GIF).",
        variant: "destructive",
      });
      return;
    }

    // Validar tamanho do arquivo (máximo 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast({
        title: "Arquivo muito grande",
        description: "A imagem deve ter no máximo 2MB.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);

    try {
      console.log('=== INICIANDO UPLOAD DE AVATAR ===');
      
      // Criar preview local primeiro
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string;
        setProfilePhoto(imageUrl);
      };
      reader.readAsDataURL(file);

      // Tentar fazer upload via API do WordPress
      const uploadedUrl = await wordpressApi.uploadAvatar(user.id, file);
      
      if (uploadedUrl) {
        console.log('✅ Upload bem-sucedido, salvando URL:', uploadedUrl);
        
        // Salvar no localStorage como backup
        localStorage.setItem(`avatar_${user.id}`, uploadedUrl);
        
        // Atualizar estado local
        setProfilePhoto(uploadedUrl);
        
        // Trigger sync para outras instâncias
        triggerSync({
          userId: user.id,
          avatar: uploadedUrl
        });
        
        toast({
          title: "Avatar atualizado!",
          description: "Sua foto de perfil foi atualizada com sucesso.",
        });
      } else {
        throw new Error('Upload falhou');
      }
    } catch (error: any) {
      console.error('=== ERRO NO UPLOAD ===', error);
      
      // Usar Gravatar como fallback em caso de erro
      if (user.email) {
        const gravatarUrl = getGravatarUrl(user.email);
        setProfilePhoto(gravatarUrl);
        localStorage.setItem(`avatar_${user.id}`, gravatarUrl);
        
        // Trigger sync para outras instâncias
        triggerSync({
          userId: user.id,
          avatar: gravatarUrl
        });
        
        toast({
          title: "Avatar configurado!",
          description: "Usando Gravatar como alternativa. Para personalizar, crie uma conta no Gravatar.com",
        });
      } else {
        toast({
          title: "Erro no upload",
          description: "Não foi possível atualizar o avatar. Tente novamente.",
          variant: "destructive",
        });
      }
    } finally {
      setIsUploading(false);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleEditProfile = () => {
    const newEditingState = !isEditingProfile;
    setIsEditingProfile(newEditingState);
    
    // Notificar o componente pai sobre a mudança
    onEditToggle?.(newEditingState);
    
    toast({
      title: "Modo de edição",
      description: newEditingState ? "Agora você pode editar suas informações nos cards abaixo" : "Edição cancelada",
    });
  };

  const getRoleDisplay = (roles: string[]) => {
    const roleMap: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
      administrator: { label: 'Administrador', icon: <Shield className="w-4 h-4" />, color: 'text-red-400' },
      editor: { label: 'Editor', icon: <Star className="w-4 h-4" />, color: 'text-purple-400' },
      author: { label: 'Autor', icon: <User className="w-4 h-4" />, color: 'text-blue-400' },
      subscriber: { label: 'Assinante', icon: <User className="w-4 h-4" />, color: 'text-green-400' },
    };
    
    const role = roles?.[0] || 'subscriber';
    const roleInfo = roleMap[role] || roleMap.subscriber;
    
    return (
      <div className={`flex items-center space-x-2 ${roleInfo.color}`}>
        {roleInfo.icon}
        <span className="font-medium">{roleInfo.label}</span>
      </div>
    );
  };

  const handleLogout = () => {
    logout();
  };

  // Função para obter o nome completo
  const getFullName = () => {
    if (user?.first_name && user?.last_name) {
      return `${user.first_name} ${user.last_name}`;
    }
    return user?.name || 'Nome não informado';
  };

  if (!user) return null;

  const displayUrl = profilePhoto || (user?.email ? getGravatarUrl(user.email) : '');

  return (
    <div className="relative w-full">
      {/* Background Pattern */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />
      
      {/* Banner Content - Altura otimizada para mobile e desktop */}
      <div className="relative bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 py-4 sm:py-6 lg:py-8">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col space-y-4 sm:space-y-6">
            {/* User Info Section - Layout otimizado para mobile e desktop */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start space-y-4 sm:space-y-0 sm:space-x-6">
              {/* Avatar with Upload */}
              <div className="relative group flex-shrink-0">
                <div className="w-20 h-20 sm:w-24 sm:h-24 lg:w-28 lg:h-28 rounded-full overflow-hidden bg-white/20 p-1 shadow-2xl">
                  <Avatar className="w-full h-full">
                    <AvatarImage 
                      src={displayUrl} 
                      alt={`Avatar de ${user.name}`}
                      className="object-cover"
                    />
                    <AvatarFallback className="bg-gradient-to-br from-blue-600 to-purple-600 text-white font-bold text-xl">
                      {user.name?.charAt(0).toUpperCase() || <User className="w-8 h-8" />}
                    </AvatarFallback>
                  </Avatar>
                </div>
                
                {/* Camera Icon */}
                <button
                  onClick={triggerFileInput}
                  className="absolute -bottom-1 -right-1 bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-full shadow-lg transition-all duration-200 hover:scale-110 border-2 border-white"
                  title="Alterar foto do perfil"
                >
                  {isUploading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  ) : (
                    <Camera className="w-4 h-4" />
                  )}
                </button>
                
                {/* Status Indicator */}
                <div className="absolute bottom-2 left-2 w-4 h-4 bg-green-500 rounded-full border-2 border-white shadow-lg"></div>
              </div>

              {/* User Details */}
              <div className="flex-1 text-center sm:text-left min-w-0">
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-2">
                  {getFullName()}
                </h1>
                <p className="text-blue-100 text-base sm:text-lg mb-3">@{user.username}</p>
                
                <div className="flex flex-col sm:flex-row items-center justify-center sm:justify-start gap-4">
                  {getRoleDisplay(user.roles)}
                  
                  <div className="flex items-center space-x-2 text-blue-100">
                    <Calendar className="w-4 h-4" />
                    <span className="text-sm">
                      Membro desde {new Date(user.registered_date).toLocaleDateString('pt-BR', {
                        month: 'short',
                        year: 'numeric'
                      })}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons - Layout responsivo */}
            <div className="flex flex-col sm:flex-row gap-3 justify-center sm:justify-start">
              <Button
                onClick={handleEditProfile}
                variant="outline"
                className={`bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm transition-all duration-200 ${
                  isEditingProfile ? 'bg-orange-500/80 border-orange-400' : ''
                }`}
                size={isMobile ? "default" : "lg"}
              >
                <Edit className="w-4 h-4 mr-2" />
                {isEditingProfile ? 'Cancelar Edição' : 'Editar Perfil'}
              </Button>
              
              <Button
                onClick={handleLogout}
                variant="destructive"
                className="bg-red-600/80 hover:bg-red-700 backdrop-blur-sm transition-all duration-200"
                size={isMobile ? "default" : "lg"}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/gif"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
};

export default UserProfileBanner;
