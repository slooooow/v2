
import React from 'react';
import { TrendingUp, BarChart3, DollarSign } from 'lucide-react';

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background com gradiente animado */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-purple-900/20 to-emerald-900/20" />
      
      {/* Elementos flutuantes de fundo */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-float" />
        <div className="absolute top-3/4 right-1/4 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
        <div className="absolute bottom-1/4 left-1/3 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
      </div>

      {/* Ícones flutuantes */}
      <TrendingUp className="absolute top-20 right-20 w-8 h-8 text-blue-400/30 animate-bounce-slow" />
      <BarChart3 className="absolute bottom-32 left-16 w-6 h-6 text-purple-400/30 animate-bounce-slow" style={{ animationDelay: '0.5s' }} />
      <DollarSign className="absolute top-1/3 left-8 w-10 h-10 text-emerald-400/30 animate-bounce-slow" style={{ animationDelay: '1.5s' }} />

      {/* Conteúdo principal */}
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="animate-fade-in-up">
          {/* Badge */}
          <div className="inline-flex items-center space-x-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full px-4 py-2 mb-8">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-sm text-gray-300">Portal de Notícias Financeiras</span>
          </div>

          {/* Título principal */}
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-white mb-6 leading-tight">
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-emerald-400 bg-clip-text text-transparent">
              Finver Finance
            </span>
            <br />
            <span className="text-glow">Seu Portal</span>
            <br />
            <span className="text-2xl sm:text-3xl lg:text-4xl text-gray-300 font-normal">
              de Notícias Financeiras
            </span>
          </h1>

          {/* Subtítulo */}
          <p className="text-lg sm:text-xl text-gray-400 mb-12 max-w-2xl mx-auto leading-relaxed">
            Acompanhe as principais notícias do mercado financeiro, análises especializadas 
            e insights exclusivos sobre ações, FIIs, tecnologia e criptomoedas.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button className="group relative px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl font-semibold text-white transition-all duration-300 hover:scale-105 hover:shadow-glow-lg overflow-hidden">
              <span className="relative z-10">Explorar Notícias</span>
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </button>
            
            <button className="px-8 py-4 glass rounded-xl font-semibold text-white transition-all duration-300 hover:bg-white/10 hover:scale-105">
              Assinar Newsletter
            </button>
          </div>
        </div>

        {/* Métricas em destaque */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-20 animate-fade-in-up">
          {[
            { label: 'Notícias Diárias', value: '50+' },
            { label: 'Categorias', value: '5' },
            { label: 'Leitores Ativos', value: '10k+' }
          ].map((metric, index) => (
            <div
              key={index}
              className="glass rounded-2xl p-6 text-center hover:bg-white/10 transition-all duration-300"
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className="text-3xl font-bold text-white mb-2">{metric.value}</div>
              <div className="text-gray-400 text-sm">{metric.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
