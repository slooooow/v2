import React from 'react';
import { useNavigate } from 'react-router-dom';
import RegisterForm from '../components/RegisterForm';

const Register: React.FC = () => {
  const navigate = useNavigate();

  const handleSuccess = () => {
    navigate('/login');
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#0d1117' }}>
      {/* Espaçamento maior para evitar sobreposição com navbar no desktop */}
      <div className="h-20 md:h-32"></div>
      
      {/* Container principal com padding top maior para desktop */}
      <div className="pt-[80px] md:pt-[120px] pb-8 px-4">
        <div className="flex justify-center">
          <div className="w-full max-w-md">
            <RegisterForm onSuccess={handleSuccess} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;

