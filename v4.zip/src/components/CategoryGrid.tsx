
import React from 'react';
import { Link } from 'react-router-dom';
import { CATEGORY_CONFIGS } from '../utils/categories';

const CategoryGrid: React.FC = () => {
  return (
    <div className="mb-20">
      <div className="text-center mb-16">
        <h2 className="text-5xl font-black text-white mb-6 tracking-tight">
          Explore por Categorias
        </h2>
        <p className="text-gray-400 text-xl">Descubra as últimas notícias organizadas por setores</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
        {CATEGORY_CONFIGS.map((category, index) => {
          const IconComponent = category.icon;
          
          return (
            <Link
              key={category.slug}
              to={`/categoria/${category.slug}`}
              className="group relative bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 hover:border-white/20 p-8 text-center rounded-2xl transition-all duration-500 hover:shadow-2xl animate-fade-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Background effect */}
              <div 
                className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-2xl"
                style={{
                  background: `radial-gradient(circle at center, ${category.color}, transparent 70%)`
                }}
              />
              
              {/* Icon container - ALINHADO À ESQUERDA E CENTRALIZADO NA COLUNA NO MOBILE */}
              <div className="relative z-10 flex flex-col items-center">
                {/* Container para ícone e título - ALINHADO À ESQUERDA NO MOBILE */}
                <div className="flex flex-row sm:flex-col items-center justify-start sm:justify-center space-x-4 sm:space-x-0 mb-0 sm:mb-0 w-full">
                  <div
                    className="w-12 h-12 sm:w-16 sm:h-16 flex items-center justify-center rounded-xl transition-all duration-500 mb-0 sm:mb-6 flex-shrink-0"
                    style={{ 
                      background: `linear-gradient(135deg, ${category.color}40, ${category.color}60)`
                    }}
                  >
                    <IconComponent 
                      className="w-6 h-6 sm:w-8 sm:h-8 text-white"
                    />
                  </div>
                  
                  {/* Category name - ALINHADO À ESQUERDA NO MOBILE */}
                  <h3 className="text-white font-bold text-lg group-hover:text-blue-300 transition-colors duration-300 text-left sm:text-center flex-1">
                    {category.name}
                  </h3>
                </div>
              </div>
              
              {/* Animated border inside the card */}
              <div 
                className="absolute bottom-4 left-1/2 transform -translate-x-1/2 w-0 h-1 group-hover:w-3/4 transition-all duration-500 rounded-full"
                style={{ backgroundColor: category.color }}
              />
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default CategoryGrid;
