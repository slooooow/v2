
import React from 'react';
import { getCategoryConfig } from '../utils/categories';

interface CategoryHeaderProps {
  name: string;
  color: string;
  slug: string;
  description?: string;
}

const CategoryHeader: React.FC<CategoryHeaderProps> = ({ 
  name, 
  color, 
  slug, 
  description 
}) => {
  const categoryConfig = getCategoryConfig(slug);
  const IconComponent = categoryConfig?.icon;

  return (
    <div className="relative overflow-hidden rounded-3xl mb-12">
      {/* Background com gradiente */}
      <div 
        className="relative p-8 lg:p-12"
        style={{
          background: `linear-gradient(135deg, ${color}20 0%, ${color}10 50%, transparent 100%)`
        }}
      >
        {/* Elementos decorativos */}
        <div className="absolute inset-0 opacity-30">
          <div 
            className="absolute top-4 right-8 w-32 h-32 rounded-full blur-3xl animate-float"
            style={{ backgroundColor: `${color}40` }}
          />
          <div 
            className="absolute bottom-6 left-12 w-24 h-24 rounded-full blur-2xl animate-float"
            style={{ 
              backgroundColor: `${color}30`,
              animationDelay: '1s'
            }}
          />
        </div>

        {/* Conteúdo */}
        <div className="relative z-10 flex items-center space-x-6">
          <div 
            className="w-16 h-16 lg:w-20 lg:h-20 rounded-2xl flex items-center justify-center glass"
            style={{ backgroundColor: `${color}30` }}
          >
            {IconComponent && (
              <IconComponent 
                className="w-8 h-8 lg:w-10 lg:h-10 text-white" 
                style={{ color: color }}
              />
            )}
          </div>
          
          <div>
            <h1 className="text-3xl lg:text-5xl font-bold text-white mb-2 text-glow">
              {name}
            </h1>
            {description && (
              <p className="text-gray-300 text-lg max-w-2xl leading-relaxed">
                {description}
              </p>
            )}
          </div>
        </div>

        {/* Borda brilhante */}
        <div 
          className="absolute inset-0 rounded-3xl border pointer-events-none"
          style={{ borderColor: `${color}30` }}
        />
      </div>
    </div>
  );
};

export default CategoryHeader;
