import React from 'react';
import { Post } from '../types/wordpress';
import { CategoryConfig } from '../types/wordpress';
import RelatedPosts from './RelatedPosts';
import TagsCard from './TagsCard';
import DynamicFinanceCard from './DynamicFinanceCard';
import SavePostButton from './SavePostButton';

interface PostSidebarProps {
  post: Post;
  categoryConfig: CategoryConfig | null;
  relatedPosts: Post[];
  contentKeywords: string[];
}

const PostSidebar: React.FC<PostSidebarProps> = ({ 
  post, 
  categoryConfig, 
  relatedPosts,
  contentKeywords 
}) => {
  return (
    <div className="lg:col-span-4 space-y-8">
      {/* Save Post Button */}
      <SavePostButton post={post} />

      {/* Dynamic Finance Card */}
      <DynamicFinanceCard
        title={post.title.rendered}
        keywords={contentKeywords}
        content={post.content.rendered}
      />

      {/* Related Posts */}
      <div className="hidden lg:block">
        <RelatedPosts posts={relatedPosts} />
      </div>

      {/* Tags */}
      <TagsCard 
        categoryConfig={categoryConfig}
        contentKeywords={contentKeywords} 
      />
    </div>
  );
};

export default PostSidebar;

