
import React from 'react';
import { Post } from '../types/wordpress';
import CommentsSection from './CommentsSection';

interface PostContentProps {
  post: Post;
}

const PostContent: React.FC<PostContentProps> = ({ post }) => {
  return (
    <div className="lg:col-span-8">
      {/* Article Content */}
      <article className="prose prose-lg prose-invert max-w-none">
        <div 
          className="text-gray-300 leading-relaxed [&>p]:mb-6 sm:[&>p]:mb-8 [&>p]:text-base sm:[&>p]:text-lg [&>h2]:text-2xl sm:[&>h2]:text-3xl [&>h2]:font-bold [&>h2]:text-white [&>h2]:mt-8 sm:[&>h2]:mt-12 [&>h2]:mb-4 sm:[&>h2]:mb-6 [&>h3]:text-xl sm:[&>h3]:text-2xl [&>h3]:font-semibold [&>h3]:text-white [&>h3]:mt-6 sm:[&>h3]:mt-8 [&>h3]:mb-3 sm:[&>h3]:mb-4 [&>ul]:list-disc [&>ul]:pl-6 sm:[&>ul]:pl-8 [&>ul]:mb-6 sm:[&>ul]:mb-8 [&>ol]:list-decimal [&>ol]:pl-6 sm:[&>ol]:pl-8 [&>ol]:mb-6 sm:[&>ol]:mb-8 [&>blockquote]:border-l-4 [&>blockquote]:border-blue-500 [&>blockquote]:pl-4 sm:[&>blockquote]:pl-6 [&>blockquote]:italic [&>blockquote]:text-gray-400 [&>blockquote]:bg-gray-800/30 [&>blockquote]:py-3 sm:[&>blockquote]:py-4 [&>blockquote]:my-6 sm:[&>blockquote]:my-8"
          dangerouslySetInnerHTML={{ __html: post.content.rendered }}
        />
      </article>

      {/* Comments Section */}
      <div className="mt-12">
        <CommentsSection postId={post.id} />
      </div>
    </div>
  );
};

export default PostContent;
