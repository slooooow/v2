
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormMessage } from '@/components/ui/form';
import { useAuth } from '../hooks/useAuth';
import { useSavedPosts } from '../hooks/useSavedPosts';
import { wordpressApi } from '../services/wordpress';
import { toast } from '@/hooks/use-toast';
import { MessageCircle, Send } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const commentSchema = z.object({
  content: z.string().min(10, 'Comentário deve ter pelo menos 10 caracteres'),
});

interface CommentFormProps {
  postId: number;
  postTitle?: string;
  postSlug?: string;
  onCommentAdded?: () => void;
  parentId?: number;
  placeholder?: string;
}

const CommentForm: React.FC<CommentFormProps> = ({ 
  postId, 
  postTitle,
  postSlug,
  onCommentAdded, 
  parentId,
  placeholder = "Escreva seu comentário..." 
}) => {
  const { isLoggedIn, user } = useAuth();
  const { addUserComment } = useSavedPosts();

  const form = useForm<{ content: string }>({
    resolver: zodResolver(commentSchema),
    defaultValues: {
      content: '',
    },
  });

  // Função para obter avatar do usuário logado
  const getUserAvatar = () => {
    if (!user) return '';
    
    // Tentar obter avatar salvo no localStorage
    const savedAvatar = localStorage.getItem(`avatar_${user.id}`);
    if (savedAvatar) {
      return savedAvatar;
    }
    
    // Fallback para Gravatar baseado no email
    if (user.email) {
      const hash = btoa(user.email.toLowerCase().trim()).replace(/=+$/, '');
      return `https://www.gravatar.com/avatar/${hash}?s=32&d=identicon&r=g`;
    }
    
    return '';
  };

  const onSubmit = async (data: { content: string }) => {
    if (!user) return;
    
    try {
      const comment = await wordpressApi.createComment(postId, data.content, parentId);
      
      // Adicionar comentário ao sistema local
      addUserComment({
        content: data.content,
        post_id: postId.toString(),
        post_slug: postSlug || '',
        post_title: postTitle || 'Artigo'
      });
      
      form.reset();
      toast({
        title: "Comentário enviado!",
        description: "Seu comentário foi enviado e está aguardando aprovação.",
      });
      onCommentAdded?.();
    } catch (error: any) {
      toast({
        title: "Erro ao enviar comentário",
        description: error.response?.data?.message || "Erro ao enviar comentário",
        variant: "destructive",
      });
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6">
        <div className="flex items-center space-x-2 mb-4">
          <MessageCircle className="w-5 h-5 text-blue-400" />
          <h3 className="text-lg font-semibold text-white">Deixe seu comentário</h3>
        </div>
        <div className="text-center py-8">
          <MessageCircle className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 mb-4">Você precisa estar logado para comentar.</p>
          <div className="space-x-4">
            <Link to="/login">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                Fazer Login
              </Button>
            </Link>
            <Link to="/registro">
              <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                Criar Conta
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6">
      <div className="flex items-center space-x-2 mb-4">
        <MessageCircle className="w-5 h-5 text-blue-400" />
        <h3 className="text-lg font-semibold text-white">
          {parentId ? 'Responder comentário' : 'Deixe seu comentário'}
        </h3>
      </div>

      <div className="flex items-center space-x-3 mb-4">
        <Avatar className="w-8 h-8">
          <AvatarImage 
            src={getUserAvatar()} 
            alt={user?.name || 'Avatar'}
          />
          <AvatarFallback className="bg-blue-600 text-white font-bold text-sm">
            {user?.name?.charAt(0).toUpperCase() || 'U'}
          </AvatarFallback>
        </Avatar>
        <span className="text-white font-medium">{user?.name}</span>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="content"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <textarea
                    {...field}
                    placeholder={placeholder}
                    rows={4}
                    className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end">
            <Button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Send className="w-4 h-4 mr-2" />
              Enviar Comentário
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default CommentForm;
