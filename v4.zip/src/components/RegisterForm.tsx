import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { UserRegistration } from '../types/wordpress';
import { useAuth } from '../hooks/useAuth';
import { Link } from 'react-router-dom';
import RegistrationHelp from './RegistrationHelp';
import SystemDiagnostics from './SystemDiagnostics';
import { Eye, EyeOff, Check, X, AlertCircle, Shield, User, Mail } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { wordpressApi } from '../services/wordpress';

// Schema de validação robusto
const registerSchema = z.object({
  username: z.string()
    .min(3, 'Username deve ter pelo menos 3 caracteres')
    .max(20, 'Username deve ter no máximo 20 caracteres')
    .regex(/^[a-zA-Z0-9_]+$/, 'Username deve conter apenas letras, números e underscore'),
  email: z.string()
    .email('Email inválido')
    .min(5, 'Email deve ter pelo menos 5 caracteres'),
  password: z.string()
    .min(8, 'Senha deve ter pelo menos 8 caracteres')
    .regex(/[A-Z]/, 'Senha deve conter pelo menos uma letra maiúscula')
    .regex(/[a-z]/, 'Senha deve conter pelo menos uma letra minúscula')
    .regex(/[0-9]/, 'Senha deve conter pelo menos um número')
    .regex(/[^A-Za-z0-9]/, 'Senha deve conter pelo menos um caractere especial (!@#$%^&*)'),
  confirmPassword: z.string(),
  first_name: z.string().optional(),
  last_name: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Senhas não coincidem",
  path: ["confirmPassword"],
});

interface RegisterFormProps {
  onSuccess?: () => void;
}

interface PasswordStrength {
  score: number;
  label: string;
  color: string;
  requirements: {
    length: boolean;
    uppercase: boolean;
    lowercase: boolean;
    number: boolean;
    special: boolean;
  };
}

const RegisterForm: React.FC<RegisterFormProps> = ({ onSuccess }) => {
  const { register, isLoading } = useAuth();
  const [showHelp, setShowHelp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState<PasswordStrength>({
    score: 0,
    label: 'Muito fraca',
    color: 'text-red-500',
    requirements: {
      length: false,
      uppercase: false,
      lowercase: false,
      number: false,
      special: false,
    }
  });
  const [emailValidation, setEmailValidation] = useState<{
    isChecking: boolean;
    isAvailable: boolean | null;
    message: string;
  }>({
    isChecking: false,
    isAvailable: null,
    message: ''
  });
  const [usernameValidation, setUsernameValidation] = useState<{
    isChecking: boolean;
    isAvailable: boolean | null;
    message: string;
  }>({
    isChecking: false,
    isAvailable: null,
    message: ''
  });

  const form = useForm<UserRegistration & { confirmPassword: string }>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      first_name: '',
      last_name: '',
    },
  });

  // Função para calcular força da senha
  const calculatePasswordStrength = (password: string): PasswordStrength => {
    const requirements = {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /[0-9]/.test(password),
      special: /[^A-Za-z0-9]/.test(password),
    };

    const score = Object.values(requirements).filter(Boolean).length;
    
    let label = 'Muito fraca';
    let color = 'text-red-500';
    
    if (score >= 5) {
      label = 'Muito forte';
      color = 'text-green-500';
    } else if (score >= 4) {
      label = 'Forte';
      color = 'text-blue-500';
    } else if (score >= 3) {
      label = 'Média';
      color = 'text-yellow-500';
    } else if (score >= 2) {
      label = 'Fraca';
      color = 'text-orange-500';
    }

    return { score, label, color, requirements };
  };

  // Verificar disponibilidade de email
  const checkEmailAvailability = async (email: string) => {
    if (!email || !z.string().email().safeParse(email).success) {
      setEmailValidation({ isChecking: false, isAvailable: null, message: '' });
      return;
    }

    setEmailValidation({ isChecking: true, isAvailable: null, message: 'Verificando...' });

    try {
      // Verificar no localStorage (modo desenvolvimento)
      if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        const existingUsers = JSON.parse(localStorage.getItem('dev_users') || '[]');
        const emailExists = existingUsers.find((u: any) => u.email === email);
        
        if (emailExists) {
          setEmailValidation({
            isChecking: false,
            isAvailable: false,
            message: 'Este email já está em uso'
          });
        } else {
          setEmailValidation({
            isChecking: false,
            isAvailable: true,
            message: 'Email disponível'
          });
        }
        return;
      }

      // Verificar via API (produção)
      // Nota: Esta é uma verificação simulada, pois a API do WordPress não tem endpoint específico para isso
      // Em produção, seria necessário criar um endpoint customizado
      setTimeout(() => {
        setEmailValidation({
          isChecking: false,
          isAvailable: true,
          message: 'Email disponível'
        });
      }, 1000);

    } catch (error) {
      setEmailValidation({
        isChecking: false,
        isAvailable: null,
        message: 'Erro ao verificar email'
      });
    }
  };

  // Verificar disponibilidade de username
  const checkUsernameAvailability = async (username: string) => {
    if (!username || username.length < 3) {
      setUsernameValidation({ isChecking: false, isAvailable: null, message: '' });
      return;
    }

    setUsernameValidation({ isChecking: true, isAvailable: null, message: 'Verificando...' });

    try {
      // Verificar no localStorage (modo desenvolvimento)
      if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        const existingUsers = JSON.parse(localStorage.getItem('dev_users') || '[]');
        const usernameExists = existingUsers.find((u: any) => u.username === username);
        
        if (usernameExists) {
          setUsernameValidation({
            isChecking: false,
            isAvailable: false,
            message: 'Este username já está em uso'
          });
        } else {
          setUsernameValidation({
            isChecking: false,
            isAvailable: true,
            message: 'Username disponível'
          });
        }
        return;
      }

      // Verificar via API (produção)
      setTimeout(() => {
        setUsernameValidation({
          isChecking: false,
          isAvailable: true,
          message: 'Username disponível'
        });
      }, 1000);

    } catch (error) {
      setUsernameValidation({
        isChecking: false,
        isAvailable: null,
        message: 'Erro ao verificar username'
      });
    }
  };

  // Debounce para verificações
  useEffect(() => {
    const email = form.watch('email');
    const timeoutId = setTimeout(() => {
      if (email) checkEmailAvailability(email);
    }, 500);
    return () => clearTimeout(timeoutId);
  }, [form.watch('email')]);

  useEffect(() => {
    const username = form.watch('username');
    const timeoutId = setTimeout(() => {
      if (username) checkUsernameAvailability(username);
    }, 500);
    return () => clearTimeout(timeoutId);
  }, [form.watch('username')]);

  // Monitorar força da senha
  useEffect(() => {
    const password = form.watch('password');
    if (password) {
      setPasswordStrength(calculatePasswordStrength(password));
    }
  }, [form.watch('password')]);

  const onSubmit = async (data: UserRegistration & { confirmPassword: string }) => {
    // Verificar se email e username estão disponíveis
    if (emailValidation.isAvailable === false) {
      form.setError('email', { message: 'Este email já está em uso' });
      return;
    }

    if (usernameValidation.isAvailable === false) {
      form.setError('username', { message: 'Este username já está em uso' });
      return;
    }

    // Remover confirmPassword antes de enviar
    const { confirmPassword, ...registrationData } = data;
    
    const success = await register(registrationData);
    if (success) {
      form.reset();
      onSuccess?.();
      setShowHelp(false);
    } else {
      setShowHelp(true);
    }
  };

  const PasswordRequirement = ({ met, text }: { met: boolean; text: string }) => (
    <div className={`flex items-center space-x-2 text-sm ${met ? 'text-green-400' : 'text-gray-400'}`}>
      {met ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
      <span>{text}</span>
    </div>
  );

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <User className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white">Criar Conta</h2>
          <p className="text-gray-400 mt-2">Junte-se à nossa comunidade financeira</p>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="first_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Nome</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Seu nome"
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="last_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Sobrenome</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Seu sobrenome"
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300 flex items-center space-x-2">
                    <User className="w-4 h-4" />
                    <span>Username *</span>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        placeholder="Seu username"
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 pr-10"
                      />
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                        {usernameValidation.isChecking && (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
                        )}
                        {!usernameValidation.isChecking && usernameValidation.isAvailable === true && (
                          <Check className="w-4 h-4 text-green-500" />
                        )}
                        {!usernameValidation.isChecking && usernameValidation.isAvailable === false && (
                          <X className="w-4 h-4 text-red-500" />
                        )}
                      </div>
                    </div>
                  </FormControl>
                  {usernameValidation.message && (
                    <p className={`text-xs mt-1 ${
                      usernameValidation.isAvailable === true ? 'text-green-400' : 
                      usernameValidation.isAvailable === false ? 'text-red-400' : 'text-gray-400'
                    }`}>
                      {usernameValidation.message}
                    </p>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300 flex items-center space-x-2">
                    <Mail className="w-4 h-4" />
                    <span>Email *</span>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type="email"
                        placeholder="seu@email.com"
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 pr-10"
                      />
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                        {emailValidation.isChecking && (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
                        )}
                        {!emailValidation.isChecking && emailValidation.isAvailable === true && (
                          <Check className="w-4 h-4 text-green-500" />
                        )}
                        {!emailValidation.isChecking && emailValidation.isAvailable === false && (
                          <X className="w-4 h-4 text-red-500" />
                        )}
                      </div>
                    </div>
                  </FormControl>
                  {emailValidation.message && (
                    <p className={`text-xs mt-1 ${
                      emailValidation.isAvailable === true ? 'text-green-400' : 
                      emailValidation.isAvailable === false ? 'text-red-400' : 'text-gray-400'
                    }`}>
                      {emailValidation.message}
                    </p>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300 flex items-center space-x-2">
                    <Shield className="w-4 h-4" />
                    <span>Senha *</span>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Sua senha"
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </FormControl>
                  
                  {/* Indicador de força da senha */}
                  {field.value && (
                    <div className="mt-2 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-400">Força da senha:</span>
                        <span className={`text-xs font-medium ${passwordStrength.color}`}>
                          {passwordStrength.label}
                        </span>
                      </div>
                      <div className="w-full bg-gray-600 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full transition-all duration-300 ${
                            passwordStrength.score >= 5 ? 'bg-green-500' :
                            passwordStrength.score >= 4 ? 'bg-blue-500' :
                            passwordStrength.score >= 3 ? 'bg-yellow-500' :
                            passwordStrength.score >= 2 ? 'bg-orange-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${(passwordStrength.score / 5) * 100}%` }}
                        />
                      </div>
                      
                      {/* Requisitos da senha */}
                      <div className="grid grid-cols-1 gap-1 mt-2">
                        <PasswordRequirement 
                          met={passwordStrength.requirements.length} 
                          text="Mínimo 8 caracteres" 
                        />
                        <PasswordRequirement 
                          met={passwordStrength.requirements.uppercase} 
                          text="Uma letra maiúscula" 
                        />
                        <PasswordRequirement 
                          met={passwordStrength.requirements.lowercase} 
                          text="Uma letra minúscula" 
                        />
                        <PasswordRequirement 
                          met={passwordStrength.requirements.number} 
                          text="Um número" 
                        />
                        <PasswordRequirement 
                          met={passwordStrength.requirements.special} 
                          text="Um caractere especial (!@#$%^&*)" 
                        />
                      </div>
                    </div>
                  )}
                  
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Confirmar Senha *</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="Confirme sua senha"
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                      >
                        {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Alerta de segurança */}
            <Alert className="bg-blue-500/10 border-blue-500/20">
              <AlertCircle className="h-4 w-4 text-blue-400" />
              <AlertDescription className="text-blue-200 text-sm">
                Sua senha será criptografada e mantida segura. Nunca compartilhe suas credenciais.
              </AlertDescription>
            </Alert>

            <Button
              type="submit"
              disabled={isLoading || passwordStrength.score < 5 || emailValidation.isAvailable === false || usernameValidation.isAvailable === false}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white h-12 font-medium"
            >
              {isLoading ? (
                <div className="flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>Criando conta...</span>
                </div>
              ) : (
                'Criar Conta'
              )}
            </Button>
          </form>
        </Form>

        <div className="mt-6 text-center">
          <p className="text-gray-400">
            Já tem uma conta?{' '}
            <Link to="/login" className="text-blue-400 hover:text-blue-300 font-medium">
              Fazer login
            </Link>
          </p>
        </div>
      </div>

      {showHelp && (
        <>
          <SystemDiagnostics />
          <RegistrationHelp />
        </>
      )}
    </div>
  );
};

export default RegisterForm;

