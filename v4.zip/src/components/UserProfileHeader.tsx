
import React, { useState, useRef } from 'react';
import { useAuth } from '../hooks/useAuth';
import { User, LogOut, Camera, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { toast } from '@/hooks/use-toast';
import { wordpressApi } from '../services/wordpress';

const UserProfileHeader: React.FC = () => {
  const { user, logout } = useAuth();
  const [profilePhoto, setProfilePhoto] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (user) {
      const savedAvatar = localStorage.getItem(`avatar_${user.id}`);
      if (savedAvatar) {
        setProfilePhoto(savedAvatar);
      } else if (user.email) {
        const gravatarUrl = getGravatarUrl(user.email);
        setProfilePhoto(gravatarUrl);
      }
    }
  }, [user]);

  const getGravatarUrl = (email: string, size: number = 80) => {
    const hash = btoa(email.toLowerCase().trim()).replace(/=+$/, '');
    return `https://www.gravatar.com/avatar/${hash}?s=${size}&d=identicon&r=g`;
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: "Arquivo inválido",
        description: "Por favor, selecione uma imagem válida.",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast({
        title: "Arquivo muito grande",
        description: "A imagem deve ter no máximo 2MB.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);

    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string;
        setProfilePhoto(imageUrl);
      };
      reader.readAsDataURL(file);

      const uploadedUrl = await wordpressApi.uploadAvatar(user.id, file);
      
      if (uploadedUrl) {
        localStorage.setItem(`avatar_${user.id}`, uploadedUrl);
        setProfilePhoto(uploadedUrl);
        
        toast({
          title: "Avatar atualizado!",
          description: "Sua foto de perfil foi atualizada com sucesso.",
        });
      }
    } catch (error: any) {
      if (user.email) {
        const gravatarUrl = getGravatarUrl(user.email);
        setProfilePhoto(gravatarUrl);
        localStorage.setItem(`avatar_${user.id}`, gravatarUrl);
      }
      
      toast({
        title: "Erro no upload",
        description: "Não foi possível atualizar o avatar.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  if (!user) return null;

  const displayUrl = profilePhoto || (user?.email ? getGravatarUrl(user.email) : '');

  return (
    <div className="bg-white/5 backdrop-blur-lg border-b border-white/10">
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            {/* Avatar com upload */}
            <div className="relative group">
              <div className="w-20 h-20 rounded-full overflow-hidden bg-gradient-to-br from-blue-500 to-purple-600 p-0.5">
                <Avatar className="w-full h-full">
                  <AvatarImage 
                    src={displayUrl} 
                    alt={`Avatar de ${user.name}`}
                    className="object-cover"
                  />
                  <AvatarFallback className="bg-gradient-to-br from-blue-600 to-purple-600 text-white font-bold text-2xl">
                    {user.name?.charAt(0).toUpperCase() || <User className="w-8 h-8" />}
                  </AvatarFallback>
                </Avatar>
              </div>
              
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="absolute -bottom-1 -right-1 bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-full shadow-lg transition-all duration-200 hover:scale-110"
              >
                {isUploading ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <Camera className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Info do usuário */}
            <div>
              <h1 className="text-2xl font-bold text-white mb-1">
                {user.name}
              </h1>
              <p className="text-gray-300 text-sm">@{user.username}</p>
              <p className="text-gray-400 text-xs mt-1">
                Membro desde {new Date(user.registered_date).toLocaleDateString('pt-BR')}
              </p>
            </div>
          </div>

          {/* Botões de ação */}
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <Settings className="w-4 h-4 mr-2" />
              Configurações
            </Button>
            
            <Button
              onClick={logout}
              variant="destructive"
              className="bg-red-600/80 hover:bg-red-700"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/gif"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
};

export default UserProfileHeader;
