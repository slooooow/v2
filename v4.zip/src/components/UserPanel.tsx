import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { wordpressApi } from '../services/wordpress';
import { toast } from '@/hooks/use-toast';
import { User, LogOut, Edit, Mail, Calendar, Shield, Star } from 'lucide-react';
import ProfilePhotoUpload from './ProfilePhotoUpload';

const profileSchema = z.object({
  first_name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  last_name: z.string().min(2, 'Sobrenome deve ter pelo menos 2 caracteres'),
  email: z.string().email('Email inválido'),
});

const UserPanel: React.FC = () => {
  const { user, logout } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [profilePhoto, setProfilePhoto] = useState<string>('');

  // Carregar avatar salvo quando o componente inicializar
  useEffect(() => {
    if (user) {
      const savedAvatar = localStorage.getItem(`avatar_${user.id}`);
      if (savedAvatar) {
        console.log('✅ Avatar carregado do localStorage:', savedAvatar);
        setProfilePhoto(savedAvatar);
      }
    }
  }, [user]);

  const form = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      first_name: user?.first_name || '',
      last_name: user?.last_name || '',
      email: user?.email || '',
    },
  });

  const onSubmit = async (data: z.infer<typeof profileSchema>) => {
    if (!user) return;

    try {
      await wordpressApi.updateUserProfile(user.id, data);
      setIsEditing(false);
      toast({
        title: "Perfil atualizado!",
        description: "Suas informações foram atualizadas com sucesso.",
      });
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar perfil",
        description: error.response?.data?.message || "Erro ao atualizar perfil",
        variant: "destructive",
      });
    }
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso.",
    });
  };

  const handlePhotoChange = (photoUrl: string) => {
    console.log('📸 Avatar atualizado:', photoUrl);
    setProfilePhoto(photoUrl);
    // Salvar também no localStorage como backup
    if (user) {
      localStorage.setItem(`avatar_${user.id}`, photoUrl);
    }
  };

  const getRoleDisplay = (roles: string[]) => {
    const roleMap: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
      administrator: { label: 'Administrador', icon: <Shield className="w-4 h-4" />, color: 'text-red-400' },
      editor: { label: 'Editor', icon: <Star className="w-4 h-4" />, color: 'text-purple-400' },
      author: { label: 'Autor', icon: <User className="w-4 h-4" />, color: 'text-blue-400' },
      subscriber: { label: 'Assinante', icon: <User className="w-4 h-4" />, color: 'text-green-400' },
    };
    
    const role = roles?.[0] || 'subscriber';
    const roleInfo = roleMap[role] || roleMap.subscriber;
    
    return (
      <div className={`flex items-center space-x-2 ${roleInfo.color}`}>
        {roleInfo.icon}
        <span className="font-medium">{roleInfo.label}</span>
      </div>
    );
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="bg-gray-800/90 backdrop-blur-sm border-gray-700/50 shadow-2xl">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <User className="w-16 h-16 text-gray-500 mx-auto" />
              <p className="text-gray-300">Usuário não encontrado.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Card Principal do Perfil - Design Aprimorado */}
      <Card className="bg-gradient-to-br from-gray-800/95 to-gray-900/95 backdrop-blur-sm border-gray-700/50 shadow-2xl overflow-hidden">
        {/* Header com Gradiente */}
        <div className="h-32 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 relative">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="absolute bottom-4 left-6">
            <h1 className="text-white text-2xl font-bold tracking-tight">Meu Perfil</h1>
            <p className="text-blue-100 text-sm">Gerencie suas informações pessoais</p>
          </div>
        </div>

        <CardContent className="relative -mt-8 pt-0">
          {/* Foto do Perfil Sobreposta */}
          <div className="flex justify-center mb-8">
            <div className="relative">
              <ProfilePhotoUpload
                currentPhoto={profilePhoto}
                userName={user.name}
                onPhotoChange={handlePhotoChange}
              />
            </div>
          </div>

          {/* Informações do Usuário */}
          <div className="text-center mb-8 space-y-2">
            <h2 className="text-white text-3xl font-bold">{user.name}</h2>
            <p className="text-gray-400 text-lg">@{user.username}</p>
            {getRoleDisplay(user.roles)}
          </div>

          {/* Botão de Edição */}
          <div className="flex justify-center mb-8">
            <Button
              variant="outline"
              onClick={() => setIsEditing(!isEditing)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:border-gray-500 transition-all duration-200 px-8"
            >
              <Edit className="w-4 h-4 mr-2" />
              {isEditing ? 'Cancelar Edição' : 'Editar Perfil'}
            </Button>
          </div>

          {/* Formulário de Edição ou Exibição */}
          {isEditing ? (
            <div className="bg-gray-800/50 rounded-lg p-6 border border-gray-700/50">
              <h3 className="text-white text-xl font-semibold mb-6 flex items-center">
                <Edit className="w-5 h-5 mr-2 text-blue-400" />
                Editar Informações
              </h3>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="first_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300 font-medium">Nome</FormLabel>
                          <FormControl>
                            <Input 
                              {...field} 
                              className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 transition-colors"
                              placeholder="Seu nome"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="last_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300 font-medium">Sobrenome</FormLabel>
                          <FormControl>
                            <Input 
                              {...field} 
                              className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 transition-colors"
                              placeholder="Seu sobrenome"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-300 font-medium">Email</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="email"
                            className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 transition-colors"
                            placeholder="seu@email.com"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-center space-x-4 pt-4">
                    <Button
                      type="submit"
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 shadow-lg transition-all duration-200"
                    >
                      Salvar Alterações
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsEditing(false)}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700 px-8"
                    >
                      Cancelar
                    </Button>
                  </div>
                </form>
              </Form>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Informações Pessoais */}
              <div className="bg-gray-800/50 rounded-lg p-6 border border-gray-700/50 hover:border-gray-600/50 transition-colors">
                <div className="flex items-center mb-4">
                  <Mail className="w-5 h-5 text-blue-400 mr-2" />
                  <h3 className="text-white font-semibold">Contato</h3>
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-gray-400 text-sm">Email</p>
                    <p className="text-white font-medium">{user.email}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Nome Completo</p>
                    <p className="text-white font-medium">
                      {user.first_name} {user.last_name}
                    </p>
                  </div>
                </div>
              </div>

              {/* Informações da Conta */}
              <div className="bg-gray-800/50 rounded-lg p-6 border border-gray-700/50 hover:border-gray-600/50 transition-colors">
                <div className="flex items-center mb-4">
                  <Calendar className="w-5 h-5 text-green-400 mr-2" />
                  <h3 className="text-white font-semibold">Conta</h3>
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-gray-400 text-sm">Membro desde</p>
                    <p className="text-white font-medium">
                      {new Date(user.registered_date).toLocaleDateString('pt-BR', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Tipo de Conta</p>
                    {getRoleDisplay(user.roles)}
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Card de Ações da Conta - Design Aprimorado */}
      <Card className="bg-gray-800/90 backdrop-blur-sm border-gray-700/50 shadow-xl">
        <CardHeader className="text-center pb-4">
          <CardTitle className="text-white text-xl">Configurações da Conta</CardTitle>
          <CardDescription className="text-gray-400">
            Gerencie suas preferências e configurações de segurança
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
          <Button
            onClick={handleLogout}
            variant="destructive"
            className="px-8 py-2 font-medium shadow-lg hover:shadow-xl transition-all duration-200"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sair da Conta
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserPanel;
