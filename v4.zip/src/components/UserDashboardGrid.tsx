
import React, { useState } from 'react';
import { User, Settings } from 'lucide-react';
import UserProfilePanel from './UserProfilePanel';
import UserProfileSettings from './UserProfileSettings';

const UserDashboardGrid: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'profile' | 'settings'>('profile');

  const tabs = [
    {
      id: 'profile' as const,
      label: 'Perfil',
      icon: User,
      description: 'Gerencie suas informações pessoais'
    },
    {
      id: 'settings' as const,
      label: 'Configurações',
      icon: Settings,
      description: 'Notificações e preferências'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-gray-900 to-slate-800 px-4 sm:px-6 lg:px-8 py-8">
      <div className="max-w-7xl mx-auto">
        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Navigation Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 sticky top-24">
              <h3 className="text-lg font-semibold text-white mb-6">Navegação</h3>
              <nav className="space-y-2">
                {tabs.map((tab) => {
                  const IconComponent = tab.icon;
                  const isActive = activeTab === tab.id;
                  
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                        isActive
                          ? 'bg-blue-600 text-white shadow-lg'
                          : 'text-gray-300 hover:bg-gray-700/50 hover:text-white'
                      }`}
                    >
                      <IconComponent className="w-5 h-5" />
                      <div className="text-left">
                        <p className="font-medium">{tab.label}</p>
                        <p className="text-xs opacity-75">{tab.description}</p>
                      </div>
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Content Area */}
          <div className="lg:col-span-3">
            {activeTab === 'profile' && <UserProfilePanel />}
            {activeTab === 'settings' && <UserProfileSettings />}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboardGrid;
