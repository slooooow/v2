import React, { useState } from 'react';
import { Mail, TrendingUp, Bell, ArrowRight, Sparkles, Target, Zap, Star, Award, Users, BarChart3, ExternalLink } from 'lucide-react';

interface FullWidthCTAProps {
  type: 'newsletter' | 'premium' | 'notification' | 'finver';
}

const FullWidthCTA: React.FC<FullWidthCTAProps> = ({ type }) => {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleNotificationToggle = async () => {
    if (!('Notification' in window)) {
      alert('Este navegador não suporta notificações');
      return;
    }

    if (Notification.permission === 'granted') {
      setNotificationsEnabled(!notificationsEnabled);
      if (!notificationsEnabled) {
        new Notification('Notificações ativadas!', {
          body: 'Você receberá alertas sobre as principais notícias do mercado.',
          icon: '/favicon.ico'
        });
      }
    } else if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        setNotificationsEnabled(true);
        new Notification('Notificações ativadas!', {
          body: 'Você receberá alertas sobre as principais notícias do mercado.',
          icon: '/favicon.ico'
        });
      }
    } else {
      alert('As notificações estão bloqueadas. Ative nas configurações do seu navegador.');
    }
  };

  const handleEmailSubmit = async () => {
    if (!email) return;
    setIsSubmitting(true);
    // Simular envio
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSubmitting(false);
    setEmail('');
    alert('Email cadastrado com sucesso!');
  };

  const configs = {
    newsletter: {
      icon: Mail,
      title: 'Newsletter Premium',
      subtitle: 'Receba análises exclusivas e alertas de mercado diretamente no seu email',
      buttonText: 'Assinar Newsletter Gratuita',
      gradient: 'from-blue-600 via-purple-600 to-blue-800',
      accent: 'from-blue-400 to-purple-400',
      features: [], // Removido as features da newsletter
      stats: [] // Removido as estatísticas da newsletter
    },
    premium: {
      icon: TrendingUp,
      title: 'Análises Premium',
      subtitle: 'Tenha acesso a relatórios exclusivos e insights profissionais do mercado',
      buttonText: 'Explorar Assinatura Premium',
      gradient: 'from-emerald-600 via-green-600 to-teal-600',
      accent: 'from-emerald-400 to-green-400',
      features: [
        { icon: Target, text: 'Relatórios detalhados' },
        { icon: Users, text: 'Consultoria especializada' },
        { icon: Zap, text: 'Suporte prioritário' }
      ],
      stats: [
        { number: '5k+', label: 'Assinantes Premium' },
        { number: '50+', label: 'Relatórios/Mês' },
        { number: '95%', label: 'Satisfação' },
        { number: '24h', label: 'Suporte' }
      ]
    },
    notification: {
      icon: Bell,
      title: 'Alertas Inteligentes',
      subtitle: 'Receba notificações instantâneas sobre as movimentações mais importantes',
      buttonText: notificationsEnabled ? 'Notificações Ativas' : 'Ativar Notificações',
      gradient: 'from-purple-600 via-pink-600 to-purple-800',
      accent: 'from-purple-400 to-pink-400',
      features: [],
      stats: []
    },
    finver: {
      icon: BarChart3,
      title: 'Finver Finance',
      subtitle: 'A plataforma completa de análise financeira e mercado de capitais',
      buttonText: 'Acessar Finver.Finance',
      gradient: 'from-orange-600 via-yellow-600 to-orange-800',
      accent: 'from-orange-400 to-yellow-400',
      features: [
        { icon: BarChart3, text: 'Análises técnicas avançadas' },
        { icon: TrendingUp, text: 'Dados em tempo real' },
        { icon: Target, text: 'Estratégias personalizadas' }
      ],
      stats: [
        { number: '100k+', label: 'Dados Processados' },
        { number: '50+', label: 'Indicadores' },
        { number: '24/7', label: 'Monitoramento' },
        { number: '⚡ Real-time', label: 'Atualizações' }
      ]
    }
  };

  const config = configs[type];
  const IconComponent = config.icon;

  return (
    <div className="relative my-16 overflow-hidden w-screen left-1/2 -translate-x-1/2">
      <div className="relative">
        {/* Background with animated elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className={`absolute -top-32 -right-32 w-96 h-96 bg-gradient-to-br ${config.gradient} blur-3xl opacity-20 animate-pulse`} />
          <div className={`absolute -bottom-32 -left-32 w-80 h-80 bg-gradient-to-tr ${config.accent} blur-3xl opacity-30 animate-pulse`} style={{ animationDelay: '1s' }} />
          
          {/* Floating elements */}
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="absolute w-3 h-3 bg-white/10 rounded-full animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${i * 0.5}s`,
                animationDuration: `${4 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>

        {/* Main content */}
        <div className="relative bg-gray-800/30 backdrop-blur-sm border-y border-gray-700/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-32 max-w-7xl">
            <div className="text-center mb-12 sm:mb-16">
              {/* Icon with modern styling */}
              <div className="relative inline-flex items-center justify-center mb-6 sm:mb-8">
                <div 
                  className={`w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 bg-gradient-to-br ${config.gradient} rounded-xl flex items-center justify-center relative overflow-hidden group`}
                >
                  <IconComponent className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 text-white relative z-10" />
                  <div className={`absolute inset-0 bg-gradient-to-br ${config.gradient} blur-xl opacity-50 animate-pulse`} />
                </div>
              </div>

              {/* Title with modern typography */}
              <h2 className={`text-3xl sm:text-4xl lg:text-6xl font-black mb-6 sm:mb-8 bg-gradient-to-r ${config.accent} bg-clip-text text-transparent animate-fade-in-up tracking-tight px-4`}>
                {config.title}
              </h2>
              
              <p className="text-gray-300 text-base sm:text-lg lg:text-xl leading-relaxed max-w-3xl mx-auto mb-8 sm:mb-12 animate-fade-in-up px-4" style={{ animationDelay: '0.2s' }}>
                {config.subtitle}
              </p>

              {/* Features grid with modern cards - centralized text - só mostra se tiver features */}
              {config.features.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-12 sm:mb-16 max-w-4xl mx-auto px-4">
                  {config.features.map((feature, index) => (
                    <div 
                      key={index} 
                      className="group flex flex-col items-center justify-center text-center space-y-3 p-4 sm:p-6 bg-gray-700/30 backdrop-blur-sm border border-gray-600/30 rounded-xl hover:bg-gray-600/40 hover:border-white/20 transition-all duration-300 animate-fade-in-up"
                      style={{ animationDelay: `${0.3 + index * 0.1}s` }}
                    >
                      <feature.icon className={`w-5 h-5 sm:w-6 sm:h-6 text-transparent bg-gradient-to-r ${config.accent} bg-clip-text`} />
                      <span className="text-gray-300 font-medium text-sm sm:text-base">{feature.text}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* CTA Section with enhanced interactivity */}
            <div className="flex flex-col items-center space-y-6 sm:space-y-8 mb-12 sm:mb-16 px-4">
              {type === 'newsletter' && (
                <div className="flex flex-col lg:flex-row gap-4 sm:gap-6 w-full max-w-3xl">
                  <div className="relative flex-1">
                    <input
                      type="email"
                      placeholder="Digite seu melhor email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-6 sm:px-8 py-4 sm:py-6 bg-gray-700/50 backdrop-blur-sm border border-gray-600/50 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-base sm:text-lg"
                    />
                  </div>
                  <button 
                    onClick={handleEmailSubmit}
                    disabled={isSubmitting || !email}
                    className={`group px-8 sm:px-10 py-4 sm:py-6 bg-gradient-to-r ${config.gradient} font-bold text-white text-base sm:text-lg rounded-xl transition-all duration-300 hover:shadow-2xl flex items-center justify-center min-w-fit disabled:opacity-50 disabled:cursor-not-allowed relative overflow-hidden`}
                  >
                    {isSubmitting ? (
                      <div className="animate-spin w-5 h-5 sm:w-6 sm:h-6 border-2 border-white/30 border-t-white rounded-full" />
                    ) : (
                      <>
                        <Mail className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3 relative z-10" />
                        <span className="relative z-10">Assinar Agora</span>
                        <ArrowRight className="ml-2 sm:ml-3 w-5 h-5 sm:w-6 sm:h-6 relative z-10 transform group-hover:translate-x-1 transition-transform duration-200" />
                      </>
                    )}
                  </button>
                </div>
              )}
              
              {type === 'notification' && (
                <button 
                  onClick={handleNotificationToggle}
                  className={`group px-8 sm:px-12 py-4 sm:py-6 bg-gradient-to-r ${config.gradient} font-bold text-white text-lg sm:text-xl rounded-2xl transition-all duration-300 hover:shadow-2xl flex items-center relative overflow-hidden ${notificationsEnabled ? 'opacity-75' : ''}`}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                  <IconComponent className="w-6 h-6 sm:w-7 sm:h-7 mr-3 sm:mr-4 relative z-10" />
                  <span className="relative z-10">{config.buttonText}</span>
                  {!notificationsEnabled && <ArrowRight className="ml-3 sm:ml-4 w-6 h-6 sm:w-7 sm:h-7 relative z-10 transform group-hover:translate-x-1 transition-transform duration-200" />}
                </button>
              )}

              {type === 'premium' && (
                <button className={`group px-8 sm:px-12 py-4 sm:py-6 bg-gradient-to-r ${config.gradient} font-bold text-white text-lg sm:text-xl rounded-2xl transition-all duration-300 hover:shadow-2xl flex items-center relative overflow-hidden`}>
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                  <IconComponent className="w-6 h-6 sm:w-7 sm:h-7 mr-3 sm:mr-4 relative z-10" />
                  <span className="relative z-10">{config.buttonText}</span>
                  <ArrowRight className="ml-3 sm:ml-4 w-6 h-6 sm:w-7 sm:h-7 relative z-10 transform group-hover:translate-x-1 transition-transform duration-200" />
                </button>
              )}

              {type === 'finver' && (
                <a 
                  href="https://finver.finance" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className={`group px-8 sm:px-12 py-4 sm:py-6 bg-gradient-to-r ${config.gradient} font-bold text-white text-lg sm:text-xl rounded-2xl transition-all duration-300 hover:shadow-2xl flex items-center relative overflow-hidden`}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                  <IconComponent className="w-6 h-6 sm:w-7 sm:h-7 mr-3 sm:mr-4 relative z-10" />
                  <span className="relative z-10">{config.buttonText}</span>
                  <ExternalLink className="ml-3 sm:ml-4 w-6 h-6 sm:w-7 sm:h-7 relative z-10 transform group-hover:translate-x-1 transition-transform duration-200" />
                </a>
              )}
            </div>

            {/* Enhanced stats section - só mostra se tiver stats */}
            {config.stats.length > 0 && (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 pt-12 sm:pt-16 border-t border-gray-700/50 px-4">
                {config.stats.map((stat, index) => (
                  <div 
                    key={index} 
                    className="text-center group cursor-pointer animate-fade-in-up"
                    style={{ animationDelay: `${0.5 + index * 0.1}s` }}
                  >
                    <div className="relative mb-3 sm:mb-4">
                      <div className="text-2xl sm:text-3xl lg:text-4xl font-black text-white mb-1 sm:mb-2 group-hover:scale-110 transition-transform duration-300">
                        {stat.number}
                      </div>
                      <div className={`absolute inset-0 text-2xl sm:text-3xl lg:text-4xl font-black bg-gradient-to-r ${config.accent} bg-clip-text text-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300`}>
                        {stat.number}
                      </div>
                    </div>
                    <div className="text-gray-400 text-xs sm:text-sm font-medium">{stat.label}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FullWidthCTA;
