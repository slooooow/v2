
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info, Settings, Plug, Code } from 'lucide-react';

const RegistrationHelp: React.FC = () => {
  return (
    <Card className="bg-gray-800 border-gray-700 mt-6">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Info className="w-5 h-5" />
        </CardTitle>
        <CardDescription className="text-gray-400">
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert className="bg-gray-700 border-gray-600">
          <Plug className="h-4 w-4" />
          <AlertDescription className="text-gray-300">
            <br />
            <br />
            2. Na aba "General" → "Account" marque "Enable registration"
            <br />
            3. Vá em "Registration" e configure os campos obrigatórios
            <br />
            4. Salve as configurações
          </AlertDescription>
        </Alert>

        <Alert className="bg-gray-700 border-gray-600">
          <Settings className="h-4 w-4" />
          <AlertDescription className="text-gray-300">
            <strong>Passo 2: Habilitar API REST</strong>
            <br />
            <br />
            2. Procure por "REST API" e habilite
            <br />
            3. Ou adicione este código ao functions.php:
            <pre className="bg-gray-900 p-2 rounded mt-2 text-xs overflow-x-auto">
add_filter('um_rest_api_enabled', '__return_true');`}
            </pre>
          </AlertDescription>
        </Alert>

        <Alert className="bg-gray-700 border-gray-600">
          <Code className="h-4 w-4" />
          <AlertDescription className="text-gray-300">
            <strong>Passo 3: Endpoint personalizado (alternativo)</strong>
            <br />
            Se a API REST não funcionar, adicione este endpoint personalizado ao functions.php:
            <pre className="bg-gray-900 p-2 rounded mt-2 text-xs overflow-x-auto">
{`add_action('rest_api_init', function () {
    'methods' => 'POST',
    'callback' => 'um_custom_registration',
    'permission_callback' => '__return_true'
  ));
});

function um_custom_registration($request) {
  $parameters = $request->get_json_params();
  
  // Validar dados
  if (empty($parameters['username']) || empty($parameters['email']) || empty($parameters['password'])) {
    return new WP_Error('missing_fields', 'Campos obrigatórios não preenchidos', array('status' => 400));
  }
  
  $user_id = wp_create_user(
    $parameters['username'],
    $parameters['password'],
    $parameters['email']
  );
  
  if (is_wp_error($user_id)) {
    return new WP_Error('registration_failed', $user_id->get_error_message(), array('status' => 400));
  }
  
  update_user_meta($user_id, 'first_name', sanitize_text_field($parameters['first_name']));
  update_user_meta($user_id, 'last_name', sanitize_text_field($parameters['last_name']));
  
  // Ativar conta se necessário
  do_action('um_registration_complete', $user_id, array());
  
  return array(
    'message' => 'Usuário registrado com sucesso',
    'user_id' => $user_id,
    'status' => 'success'
  );
}`}
            </pre>
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
};

export default RegistrationHelp;
