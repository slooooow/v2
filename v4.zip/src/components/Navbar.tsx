import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, User, LogIn, LogOut } from 'lucide-react';
import { CATEGORY_CONFIGS } from '../utils/categories';
import { useAuth } from '../hooks/useAuth';
import SearchBar from './SearchBar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuAnimationPhase, setMenuAnimationPhase] = useState(0);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isLoggedIn, logout } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
      // Animação em fases para o blur gradativo
      setMenuAnimationPhase(1);
      setTimeout(() => setMenuAnimationPhase(2), 100);
      setTimeout(() => setMenuAnimationPhase(3), 200);
      setTimeout(() => setMenuAnimationPhase(4), 300);
    } else {
      document.body.style.overflow = 'unset';
      setMenuAnimationPhase(0);
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMenuOpen]);

  const getCategoryColor = (categorySlug: string) => {
    const category = CATEGORY_CONFIGS.find(cat => cat.slug === categorySlug);
    return category ? category.color : '#3b82f6';
  };

  const getCurrentCategorySlug = () => {
    const pathSegments = location.pathname.split('/');
    if (pathSegments[1] === 'categoria') {
      return pathSegments[2];
    }
    return null;
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const currentCategorySlug = getCurrentCategorySlug();

  return (
    <>
      {/* Navbar Principal */}
      <nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-gray-900/70 backdrop-blur-xl border-b border-white/5'
            : 'bg-gray-900/50 backdrop-blur-md'
        }`}
      >
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link
              to="/"
              className="flex items-center space-x-3 text-xl font-bold text-white hover:text-blue-400 transition-colors duration-200 z-50 relative"
            >
              <div className="w-8 h-8 flex items-center justify-center">
                <img 
                  src="/lovable-uploads/d5f08bad-4a22-451b-8cd0-d2cbce38848c.png" 
                  alt="Finver Logo" 
                  className="w-8 h-8 object-contain"
                />
              </div>
              <span>Finver</span>
            </Link>

            {/* Desktop Menu */}
            <div className="hidden lg:flex items-center space-x-6">
              <Link
                to="/"
                className={`px-5 py-3 rounded-lg text-sm font-medium transition-all duration-200 hover:bg-white/10 ${
                  location.pathname === '/' ? 'text-blue-400 bg-white/5' : 'text-gray-300 hover:text-white'
                }`}
              >
                Home
              </Link>
              {CATEGORY_CONFIGS.map((category) => {
                const isActive = location.pathname === `/categoria/${category.slug}`;
                return (
                  <Link
                    key={category.slug}
                    to={`/categoria/${category.slug}`}
                    className={`px-5 py-3 rounded-lg text-sm font-medium transition-all duration-200 hover:bg-white/10 ${
                      isActive
                        ? 'text-white'
                        : 'text-gray-300 hover:text-white'
                    }`}
                    style={{
                      backgroundColor: isActive ? `${category.color}30` : undefined,
                      color: isActive ? category.color : undefined
                    }}
                  >
                    {category.name}
                  </Link>
                );
              })}
            </div>

            {/* Desktop - Search Bar e Auth Buttons */}
            <div className="hidden lg:flex items-center space-x-8">
              <div className="max-w-md">
                <SearchBar />
              </div>
              
              {/* Auth Buttons */}
              {isLoggedIn ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white px-4 py-2"
                    >
                      <User className="w-4 h-4 mr-2" />
                      {user?.name || 'Usuário'}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent 
                    align="end" 
                    className="bg-gray-800 border-gray-700"
                  >
                    <DropdownMenuItem 
                      asChild
                      className="text-gray-300 hover:bg-gray-700 hover:text-white cursor-pointer"
                    >
                      <Link to="/dashboard">
                        <User className="w-4 h-4 mr-2" />
                        Painel do Usuário
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-gray-700" />
                    <DropdownMenuItem 
                      onClick={handleLogout}
                      className="text-gray-300 hover:bg-gray-700 hover:text-white cursor-pointer"
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Sair
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="flex items-center space-x-4">
                  <Button 
                    asChild
                    variant="outline" 
                    size="sm"
                    className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white hover:border-gray-500 px-6 py-2"
                  >
                    <Link to="/login">
                      <LogIn className="w-4 h-4 mr-2" />
                      Login
                    </Link>
                  </Button>
                  <Button 
                    asChild
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2"
                  >
                    <Link to="/registro">Registrar</Link>
                  </Button>
                </div>
              )}
            </div>

            {/* Mobile Menu Button - Melhorado */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className={`lg:hidden p-3 rounded-2xl transition-all duration-500 ease-out z-50 relative overflow-hidden ${
                isMenuOpen 
                  ? 'bg-white/20 text-white shadow-2xl scale-110 backdrop-blur-sm border border-white/20' 
                  : 'text-gray-300 hover:text-white hover:bg-white/10 hover:scale-105 border border-transparent'
              }`}
              aria-label="Toggle menu"
            >
              {/* Background gradient animado */}
              <div className={`absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 transition-opacity duration-500 ${
                isMenuOpen ? 'opacity-100' : 'opacity-0'
              }`} />
              
              <div className="relative">
                <div className={`transition-all duration-500 ease-out ${
                  isMenuOpen ? 'rotate-180 scale-110' : 'rotate-0 scale-100'
                }`}>
                  {isMenuOpen ? (
                    <X size={24} className="transition-all duration-300" />
                  ) : (
                    <Menu size={24} className="transition-all duration-300" />
                  )}
                </div>
              </div>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu - Blur Gradativo Estilo iOS */}
      <div 
        className={`fixed inset-0 z-[9999] lg:hidden transition-all duration-700 ease-out ${
          isMenuOpen 
            ? 'opacity-100 visible' 
            : 'opacity-0 invisible'
        }`}
        style={{ top: '80px' }}
      >
        {/* Backdrop com blur gradativo em camadas */}
        <div className="absolute inset-0">
          {/* Camada 1 - Blur inicial */}
          <div 
            className={`absolute inset-0 bg-black/10 backdrop-blur-[1px] transition-all duration-300 ease-out ${
              menuAnimationPhase >= 1 ? 'opacity-100' : 'opacity-0'
            }`}
            onClick={() => setIsMenuOpen(false)}
          />
          
          {/* Camada 2 - Blur médio */}
          <div 
            className={`absolute inset-0 bg-black/15 backdrop-blur-[3px] transition-all duration-400 ease-out ${
              menuAnimationPhase >= 2 ? 'opacity-100' : 'opacity-0'
            }`}
            onClick={() => setIsMenuOpen(false)}
          />
          
          {/* Camada 3 - Blur intenso */}
          <div 
            className={`absolute inset-0 bg-black/20 backdrop-blur-[6px] transition-all duration-500 ease-out ${
              menuAnimationPhase >= 3 ? 'opacity-100' : 'opacity-0'
            }`}
            onClick={() => setIsMenuOpen(false)}
          />
          
          {/* Camada 4 - Blur final estilo iOS */}
          <div 
            className={`absolute inset-0 bg-black/25 backdrop-blur-[10px] transition-all duration-600 ease-out ${
              menuAnimationPhase >= 4 ? 'opacity-100' : 'opacity-0'
            }`}
            onClick={() => setIsMenuOpen(false)}
          />
        </div>
        
        {/* Menu Content - Estilo iOS */}
        <div 
          className={`absolute top-0 left-0 right-0 transition-all duration-700 ease-out ${
            isMenuOpen 
              ? 'transform translate-y-0 opacity-100' 
              : 'transform -translate-y-full opacity-0'
          }`}
          style={{
            maxHeight: 'calc(100vh - 80px)',
            background: 'linear-gradient(180deg, rgba(17, 24, 39, 0.98) 0%, rgba(17, 24, 39, 0.95) 100%)',
            backdropFilter: 'blur(20px)',
            borderRadius: '0 0 32px 32px',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.05)'
          }}
        >
          {/* Search Bar Mobile - Melhorada */}
          <div className="p-6 border-b border-white/10">
            <div className="relative">
              <SearchBar />
              <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-blue-500/5 to-purple-500/5 pointer-events-none" />
            </div>
          </div>
          
          {/* Menu Items - Estilo iOS */}
          <div className="overflow-y-auto p-6" style={{ maxHeight: 'calc(100vh - 260px)' }}>
            <div className="space-y-3">
              {/* Navigation Links - Botões estilo iOS */}
              <Link
                to="/"
                onClick={() => setIsMenuOpen(false)}
                className={`group block px-6 py-5 rounded-2xl text-lg font-medium transition-all duration-400 hover:scale-[1.02] active:scale-[0.98] ${
                  location.pathname === '/' 
                    ? 'text-white bg-gradient-to-r from-blue-500/20 to-blue-600/20 border border-blue-400/30 shadow-lg shadow-blue-500/10' 
                    : 'text-gray-300 hover:text-white hover:bg-white/10 border border-white/5 hover:border-white/20'
                }`}
                style={{
                  backdropFilter: 'blur(10px)',
                  boxShadow: location.pathname === '/' 
                    ? '0 8px 32px rgba(59, 130, 246, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                    : '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.05)'
                }}
              >
                <div className="flex items-center space-x-4">
                  <div className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    location.pathname === '/' 
                      ? 'bg-blue-400 shadow-lg shadow-blue-400/50' 
                      : 'bg-gray-500 group-hover:bg-white'
                  }`}></div>
                  <span className="font-semibold">Home</span>
                  {location.pathname === '/' && (
                    <div className="ml-auto w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                  )}
                </div>
              </Link>
              
              {CATEGORY_CONFIGS.map((category, index) => {
                const isActive = location.pathname === `/categoria/${category.slug}`;
                return (
                  <Link
                    key={category.slug}
                    to={`/categoria/${category.slug}`}
                    onClick={() => setIsMenuOpen(false)}
                    className={`group block px-6 py-5 rounded-2xl text-lg font-medium transition-all duration-400 hover:scale-[1.02] active:scale-[0.98] border ${
                      isActive
                        ? 'text-white border-white/30 shadow-lg'
                        : 'text-gray-300 hover:text-white hover:bg-white/10 border-white/5 hover:border-white/20'
                    }`}
                    style={{
                      background: isActive 
                        ? `linear-gradient(135deg, ${category.color}20, ${category.color}10)` 
                        : undefined,
                      borderLeftColor: category.color,
                      borderLeftWidth: '4px',
                      backdropFilter: 'blur(10px)',
                      boxShadow: isActive 
                        ? `0 8px 32px ${category.color}15, inset 0 1px 0 rgba(255, 255, 255, 0.1)` 
                        : '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.05)'
                    }}
                  >
                    <div className="flex items-center space-x-4">
                      <div 
                        className={`w-3 h-3 rounded-full transition-all duration-300 ${
                          isActive ? 'shadow-lg' : 'group-hover:scale-110'
                        }`}
                        style={{ 
                          backgroundColor: category.color,
                          boxShadow: isActive ? `0 0 12px ${category.color}60` : undefined
                        }}
                      ></div>
                      <span className="font-semibold">{category.name}</span>
                      {isActive && (
                        <div 
                          className="ml-auto w-2 h-2 rounded-full animate-pulse" 
                          style={{ backgroundColor: category.color }}
                        />
                      )}
                    </div>
                  </Link>
                );
              })}

              {/* Separador estilo iOS */}
              <div className="my-6 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

              {/* Auth Buttons Mobile - Estilo iOS */}
              {isLoggedIn ? (
                <>
                  <Link
                    to="/dashboard"
                    onClick={() => setIsMenuOpen(false)}
                    className="group block px-6 py-5 rounded-2xl text-lg font-medium text-gray-300 hover:text-white hover:bg-white/10 border border-white/5 hover:border-white/20 transition-all duration-400 hover:scale-[1.02] active:scale-[0.98]"
                    style={{
                      backdropFilter: 'blur(10px)',
                      boxShadow: '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.05)'
                    }}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center">
                        <User className="w-5 h-5 text-white" />
                      </div>
                      <span className="font-semibold">Painel do Usuário</span>
                      <div className="ml-auto w-2 h-2 rounded-full bg-green-400 group-hover:animate-pulse" />
                    </div>
                  </Link>
                  
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsMenuOpen(false);
                    }}
                    className="group w-full text-left px-6 py-5 rounded-2xl text-lg font-medium text-gray-300 hover:text-white hover:bg-red-500/10 border border-red-500/20 hover:border-red-500/40 transition-all duration-400 hover:scale-[1.02] active:scale-[0.98]"
                    style={{
                      backdropFilter: 'blur(10px)',
                      boxShadow: '0 4px 16px rgba(239, 68, 68, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.05)'
                    }}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-r from-red-500 to-red-600 flex items-center justify-center">
                        <LogOut className="w-5 h-5 text-white" />
                      </div>
                      <span className="font-semibold">Sair</span>
                    </div>
                  </button>
                </>
              ) : (
                <>
                  <Link
                    to="/login"
                    onClick={() => setIsMenuOpen(false)}
                    className="group block px-6 py-5 rounded-2xl text-lg font-medium text-gray-300 hover:text-white hover:bg-white/10 border border-white/20 hover:border-white/40 transition-all duration-400 hover:scale-[1.02] active:scale-[0.98]"
                    style={{
                      backdropFilter: 'blur(10px)',
                      boxShadow: '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
                    }}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-r from-gray-600 to-gray-700 flex items-center justify-center group-hover:from-blue-500 group-hover:to-blue-600 transition-all duration-300">
                        <LogIn className="w-5 h-5 text-white" />
                      </div>
                      <span className="font-semibold">Login</span>
                    </div>
                  </Link>
                  
                  <Link
                    to="/registro"
                    onClick={() => setIsMenuOpen(false)}
                    className="group block px-6 py-5 rounded-2xl text-lg font-medium text-white border border-blue-500/50 transition-all duration-400 hover:scale-[1.02] active:scale-[0.98]"
                    style={{
                      background: 'linear-gradient(135deg, #3B82F6, #1D4ED8)',
                      backdropFilter: 'blur(10px)',
                      boxShadow: '0 8px 32px rgba(59, 130, 246, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2)'
                    }}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                        <div className="w-3 h-3 rounded-full bg-white animate-pulse" />
                      </div>
                      <span className="font-bold">Registrar</span>
                      <div className="ml-auto">
                        <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                          <div className="w-2 h-2 rounded-full bg-white" />
                        </div>
                      </div>
                    </div>
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;

