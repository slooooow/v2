
import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Play, Clock, TrendingUp, ArrowRight, Sparkles, Twitter, Facebook, Linkedin, Copy } from 'lucide-react';
import { WordPressPost } from '../types/wordpress';
import { formatRelativeDate, stripHtml, getImageUrl, getCategoryFromPost, getCategoryColor, getCategoryName } from '../utils/formatting';

interface NewsSliderProps {
  posts: WordPressPost[];
}

const NewsSlider: React.FC<NewsSliderProps> = ({ posts }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isHovered, setIsHovered] = useState(false);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);
  
  // Mínima distância de swipe necessária
  const minSwipeDistance = 50;
  
  // Initialize component after mount to prevent double animation
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsInitialized(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);
  
  useEffect(() => {
    if (!isPlaying || isHovered || !isInitialized) return;
    
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % posts.length);
    }, 10000); // 10 segundos
    
    return () => clearInterval(timer);
  }, [posts.length, isPlaying, isHovered, isInitialized]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % posts.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + posts.length) % posts.length);
  };

  // Funções de touch para swipe
  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    if (isLeftSwipe) {
      nextSlide();
    }
    if (isRightSwipe) {
      prevSlide();
    }
  };

  const handleShare = (platform?: string) => {
    const currentPost = posts[currentSlide];
    const url = `${window.location.origin}/post/${currentPost.slug}`;
    const title = stripHtml(currentPost.title.rendered);
    
    if (platform === 'twitter') {
      window.open(`https://twitter.com/intent/tweet?url=${url}&text=${title}`, '_blank');
    } else if (platform === 'facebook') {
      window.open(`https://facebook.com/sharer/sharer.php?u=${url}`, '_blank');
    } else if (platform === 'linkedin') {
      window.open(`https://linkedin.com/sharing/share-offsite/?url=${url}`, '_blank');
    } else if (platform === 'copy') {
      navigator.clipboard.writeText(url);
      setShowShareMenu(false);
    } else {
      setShowShareMenu(!showShareMenu);
    }
  };

  if (!posts.length) return null;

  return (
    <div 
      ref={sliderRef}
      className="relative w-full overflow-hidden mb-12 sm:mb-20 group"
      style={{ 
        height: '80vh',
        marginTop: '80px' // Ajustado para corresponder à altura do navbar (h-20 = 80px)
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* Swipe indicator fixo - apenas no mobile, posicionado no topo */}
      <div className="block sm:hidden absolute top-20 left-1/2 -translate-x-1/2 z-30 text-center">
        <span className="text-white/80 text-xs flex items-center justify-center space-x-2 animate-pulse bg-black/40 backdrop-blur-sm px-4 py-2 rounded-full border border-white/20">
          <span>Deslize para navegar</span>
          <div className="flex space-x-1">
            <div className="w-1 h-1 bg-white/80 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
            <div className="w-1 h-1 bg-white/80 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
            <div className="w-1 h-1 bg-white/80 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
          </div>
        </span>
      </div>

      {/* Main slider container */}
      <div className="relative h-full overflow-hidden">
        <div 
          className="flex transition-transform duration-1000 ease-out h-full"
          style={{ transform: `translateX(-${currentSlide * 100}%)` }}
        >
          {posts.map((post, index) => {
            const categorySlug = getCategoryFromPost(post);
            const categoryColor = getCategoryColor(categorySlug);
            const categoryName = getCategoryName(categorySlug);
            const imageUrl = getImageUrl(post);

            return (
              <div key={post.id} className="min-w-full h-full relative flex-shrink-0 group/slide">
                {/* Background image with proper containment */}
                <div className="absolute inset-0 overflow-hidden">
                  <img
                    src={imageUrl}
                    alt={stripHtml(post.title.rendered)}
                    className={`w-full h-full object-cover object-center sm:object-left transition-transform duration-[8s] ${
                      index === currentSlide ? 'scale-110' : 'scale-100'
                    }`}
                  />
                  
                  {/* Multi-layer gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-r from-black/95 from-0% via-black/70 via-50% to-transparent to-90%" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/60 to-transparent" />
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-transparent to-purple-900/20" />
                </div>
                
                {/* Content overlay - with controlled animation based on initialization */}
                <div className="absolute inset-0 flex items-end">
                  <div className="w-full p-4 sm:p-6 lg:pl-32 lg:pr-16 lg:py-16 pb-8 sm:pb-16">
                    <div className="max-w-5xl">
                      {/* Category badge */}
                      <div className={`flex items-center space-x-4 mb-3 sm:mb-6 ${isInitialized ? 'animate-fade-in-up' : 'opacity-100'}`}>
                        <span
                          className="px-3 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm font-bold text-white backdrop-blur-md border border-white/20 shadow-lg rounded-full"
                          style={{ 
                            background: `linear-gradient(135deg, ${categoryColor}, ${categoryColor}cc)`,
                            boxShadow: `0 8px 32px ${categoryColor}40`
                          }}
                        >
                          {categoryName}
                        </span>
                      </div>

                      {/* Meta info row */}
                      <div className={`flex items-center space-x-3 sm:space-x-4 lg:space-x-6 mb-3 sm:mb-8 ${isInitialized ? 'animate-fade-in-up' : 'opacity-100'}`} style={{ animationDelay: isInitialized ? '0.2s' : '0s' }}>
                        <div className="flex items-center text-gray-300 text-xs sm:text-sm glass px-3 py-1.5 sm:px-4 sm:py-2 rounded-full">
                          <Clock className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                          {formatRelativeDate(post.date)}
                        </div>
                        <div className="hidden sm:flex items-center text-gray-300 text-xs sm:text-sm glass px-3 py-1.5 sm:px-4 sm:py-2 rounded-full">
                          <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                          Em alta
                        </div>
                      </div>
                      
                      {/* Title with responsive sizing */}
                      <a 
                        href={`/post/${post.slug}`}
                        className="block"
                      >
                        <h2 
                          className={`text-xl sm:text-3xl lg:text-7xl font-black text-white mb-3 sm:mb-6 leading-tight ${isInitialized ? 'animate-fade-in-up' : 'opacity-100'} transition-colors duration-500 ease-in-out group-hover/slide:text-white line-clamp-3 sm:line-clamp-none`}
                          style={{ 
                            animationDelay: isInitialized ? '0.4s' : '0s',
                            color: index === currentSlide ? 
                              (isHovered ? categoryColor : 'white') : 'white'
                          }}
                        >
                          {stripHtml(post.title.rendered)}
                        </h2>
                      </a>
                      
                      {/* Excerpt - hidden on small screens */}
                      <p className={`hidden md:block text-gray-200 text-lg lg:text-xl leading-relaxed mb-6 sm:mb-10 max-w-3xl ${isInitialized ? 'animate-fade-in-up' : 'opacity-100'} line-clamp-2`} style={{ animationDelay: isInitialized ? '0.6s' : '0s' }}>
                        {stripHtml(post.excerpt.rendered).substring(0, 120)}...
                      </p>
                      
                      {/* CTA Buttons - responsivos */}
                      <div className={`flex flex-col sm:flex-row gap-3 sm:gap-4 ${isInitialized ? 'animate-fade-in-up' : 'opacity-100'}`} style={{ animationDelay: isInitialized ? '0.8s' : '0s' }}>
                        <a
                          href={`/post/${post.slug}`}
                          className="group relative inline-flex items-center justify-center px-4 sm:px-6 lg:px-8 py-2.5 sm:py-3 lg:py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold rounded-xl transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/30 overflow-hidden"
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                          <Play className="w-4 h-4 sm:w-4 sm:h-4 lg:w-5 lg:h-5 mr-2 lg:mr-3 relative z-10" />
                          <span className="relative z-10 text-sm sm:text-sm lg:text-base">Ler Matéria</span>
                          <ArrowRight className="w-4 h-4 sm:w-4 sm:h-4 lg:w-5 lg:h-5 ml-2 lg:ml-3 relative z-10 group-hover:translate-x-1 transition-transform duration-300" />
                        </a>
                        
                        <div className="relative">
                          <button 
                            onClick={() => handleShare()}
                            className="group inline-flex items-center justify-center w-full sm:w-auto px-4 sm:px-6 lg:px-8 py-2.5 sm:py-3 lg:py-4 glass hover:bg-white/20 text-white font-semibold rounded-xl transition-all duration-300 hover:scale-105"
                          >
                            <Sparkles className="w-4 h-4 sm:w-4 sm:h-4 lg:w-5 lg:h-5 mr-2 lg:mr-3 group-hover:rotate-12 transition-transform duration-300" />
                            <span className="text-sm sm:text-sm lg:text-base">Compartilhar</span>
                          </button>
                          
                          {showShareMenu && (
                            <div className="absolute bottom-full left-0 mb-2 w-56 bg-gray-800/95 backdrop-blur-md border border-gray-700 rounded-xl shadow-2xl z-50">
                              <div className="p-2">
                                <button
                                  onClick={() => handleShare('twitter')}
                                  className="w-full flex items-center space-x-3 px-4 py-3 text-gray-300 hover:bg-blue-600/20 hover:text-blue-400 rounded-lg transition-colors duration-200"
                                >
                                  <Twitter className="w-4 h-4" />
                                  <span>Twitter</span>
                                </button>
                                <button
                                  onClick={() => handleShare('facebook')}
                                  className="w-full flex items-center space-x-3 px-4 py-3 text-gray-300 hover:bg-blue-700/20 hover:text-blue-500 rounded-lg transition-colors duration-200"
                                >
                                  <Facebook className="w-4 h-4" />
                                  <span>Facebook</span>
                                </button>
                                <button
                                  onClick={() => handleShare('linkedin')}
                                  className="w-full flex items-center space-x-3 px-4 py-3 text-gray-300 hover:bg-blue-600/20 hover:text-blue-400 rounded-lg transition-colors duration-200"
                                >
                                  <Linkedin className="w-4 h-4" />
                                  <span>LinkedIn</span>
                                </button>
                                <button
                                  onClick={() => handleShare('copy')}
                                  className="w-full flex items-center space-x-3 px-4 py-3 text-gray-300 hover:bg-gray-600/20 hover:text-white rounded-lg transition-colors duration-200"
                                >
                                  <Copy className="w-4 h-4" />
                                  <span>Copiar Link</span>
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Enhanced controls - responsivos */}
      <div className="absolute top-4 sm:top-8 right-4 sm:right-8 flex items-center space-x-2 sm:space-x-4 z-20">
        {/* Play/Pause */}
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="group p-3 sm:p-4 glass hover:bg-white/20 text-white rounded-xl transition-all duration-300 hover:scale-110"
        >
          {isPlaying ? (
            <TrendingUp className="w-4 h-4 sm:w-6 sm:h-6 group-hover:rotate-12 transition-transform duration-300" />
          ) : (
            <Play className="w-4 h-4 sm:w-6 sm:h-6 group-hover:scale-110 transition-transform duration-300" />
          )}
        </button>
        
        {/* Slide indicators */}
        <div className="flex space-x-1 sm:space-x-2 lg:space-x-3 glass p-1 sm:p-2 lg:p-3 rounded-xl">
          {posts.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`transition-all duration-500 relative overflow-hidden rounded-full ${
                index === currentSlide 
                  ? 'w-3 sm:w-4 lg:w-10 h-1.5 sm:h-2 lg:h-4 bg-gradient-to-r from-blue-400 to-purple-400' 
                  : 'w-1.5 sm:w-2 lg:w-4 h-1.5 sm:h-2 lg:h-4 bg-white/40 hover:bg-white/60'
              }`}
            >
              {index === currentSlide && (
                <div className="absolute inset-0 bg-gradient-to-r from-blue-300 to-purple-300 animate-pulse rounded-full" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Navigation arrows - desktop only */}
      <button
        onClick={prevSlide}
        className="hidden lg:block absolute left-8 top-1/2 -translate-y-1/2 p-4 glass hover:bg-white/20 text-white rounded-xl transition-all duration-300 hover:scale-110 z-20 group"
      >
        <ChevronLeft className="w-8 h-8 group-hover:-translate-x-1 transition-transform duration-300" />
      </button>
      
      <button
        onClick={nextSlide}
        className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2 p-4 glass hover:bg-white/20 text-white rounded-xl transition-all duration-300 hover:scale-110 z-20 group"
      >
        <ChevronRight className="w-8 h-8 group-hover:translate-x-1 transition-transform duration-300" />
      </button>

      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 w-full h-1 bg-white/20">
        <div 
          className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-300"
          style={{ width: `${((currentSlide + 1) / posts.length) * 100}%` }}
        />
      </div>
    </div>
  );
};

export default NewsSlider;
