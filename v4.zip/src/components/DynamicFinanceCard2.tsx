import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import FinanceCard from './FinanceCard';

interface DynamicFinanceCardProps {
  title: string;
  keywords: string[];
  content: string;
}

const DynamicFinanceCard: React.FC<DynamicFinanceCardProps> = ({ 
  title, 
  keywords, 
  content 
}) => {
  const [detectedSymbols, setDetectedSymbols] = useState<string[]>([]);
  const [stockMap, setStockMap] = useState<Map<string, string>>(new Map());
  const [cryptoSet, setCryptoSet] = useState<Set<string>>(new Set());
  
  // Token configurado
  const TOKEN = import.meta.env.VITE_BRAPI_TOKEN || 'xp4thdSxhTeWTP2S5j62WN';

  // Se não há token, renderizar mensagem informativa
  if (!TOKEN) {
    return (
      <div className="bg-yellow-600/20 border border-yellow-600/30 rounded-lg p-4 text-yellow-200">
        <p className="text-sm">
          💡 Configure a variável VITE_BRAPI_TOKEN para exibir informações financeiras dos ativos mencionados.
        </p>
      </div>
    );
  }

  // Buscar lista de ações disponíveis
  const { data: rawStockList, isLoading: loadingStocks, error: stocksError } = useQuery<string[]>({
    queryKey: ['stocksAvailable'],
    queryFn: async () => {
      try {
        const url = `https://brapi.dev/api/available?token=${TOKEN}`;
        const res = await fetch(url);
        
        if (!res.ok) {
          throw new Error(`HTTP error! status: ${res.status}`);
        }
        
        const json = await res.json();
        
        if (!json.stocks || !Array.isArray(json.stocks)) {
          console.error('Formato de resposta inválido para ações:', json);
          return [];
        }
        
        return json.stocks;
      } catch (error) {
        console.error('Erro ao buscar ações:', error);
        throw error;
      }
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
  });

  // Buscar lista de criptomoedas disponíveis
  const { data: rawCryptoList, isLoading: loadingCryptos, error: cryptosError } = useQuery<string[]>({
    queryKey: ['cryptoAvailable'],
    queryFn: async () => {
      try {
        const url = `https://brapi.dev/api/v2/crypto/available?token=${TOKEN}`;
        const res = await fetch(url);
        
        if (!res.ok) {
          const errorText = await res.text();
          console.error('Erro HTTP criptos:', res.status, errorText);
          throw new Error(`HTTP error! status: ${res.status}`);
        }
        
        const json = await res.json();
        
        if (!json.coins || !Array.isArray(json.coins)) {
          console.error('Formato de resposta inválido para criptos:', json);
          return [];
        }
        
        // Converter para maiúsculo para consistência
        const symbols = json.coins.map((coin: string) => coin.toUpperCase());
        return symbols;
      } catch (error) {
        console.error('Erro ao buscar criptomoedas:', error);
        throw error;
      }
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
  });

  // Processar lista de ações em Map
  useEffect(() => {
    if (!loadingStocks && rawStockList && !stocksError) {
      const map = new Map<string, string>();
      rawStockList.forEach(symbol => {
        map.set(symbol, symbol);
        const baseSymbol = symbol.replace(/\.SA$/, '');
        if (baseSymbol !== symbol) {
          map.set(baseSymbol, symbol);
        }
      });
      setStockMap(map);
    }
  }, [loadingStocks, rawStockList, stocksError]);

  // Processar lista de criptomoedas em Set
  useEffect(() => {
    if (!loadingCryptos && rawCryptoList && !cryptosError) {
      const set = new Set(rawCryptoList);
      setCryptoSet(set);
    }
  }, [loadingCryptos, rawCryptoList, cryptosError]);

  // Detectar tickers no texto
  useEffect(() => {
    if (loadingStocks || loadingCryptos) {
      return;
    }

    if (stocksError && cryptosError) {
      console.error('Erros em ambas as APIs');
      return;
    }

    if (stockMap.size === 0 && cryptoSet.size === 0) {
      return;
    }
    
    const fullText = `${title || ''} ${keywords.join(' ')} ${content || ''}`.toUpperCase();
    
    // Padrões melhorados para detecção de tickers
    const tickerPatterns = [
      // Tickers brasileiros (PETR4, VALE3, etc.)
      /\b[A-Z]{4}[0-9]{1,2}\b/g,
      // Tickers com .SA
      /\b[A-Z]{4}[0-9]{1,2}\.SA\b/g,
      // Criptomoedas - padrão mais flexível
      /\b[A-Z]{2,10}\b/g,
      // Padrões específicos para criptomoedas populares
      /\b(BITCOIN|BTC|ETHEREUM|ETH|BINANCE|BNB|CARDANO|ADA|SOLANA|SOL|RIPPLE|XRP|POLKADOT|DOT|DOGECOIN|DOGE|POLYGON|MATIC|AVALANCHE|AVAX|CHAINLINK|LINK|UNISWAP|UNI|LITECOIN|LTC|BITCOIN\s*CASH|BCH|STELLAR|XLM|ALGORAND|ALGO|VECHAIN|VET|FILECOIN|FIL|TRON|TRX|ETHEREUM\s*CLASSIC|ETC|THETA|COSMOS|ATOM|INTERNET\s*COMPUTER|ICP|EOS|AAVE|MAKER|MKR|SYNTHETIX|SNX|COMPOUND|COMP|YEARN|YFI|SUSHISWAP|SUSHI|CURVE|CRV|BALANCER|BAL|0X|ZRX|KYBER|KNC|LOOPRING|LRC|AUGUR|REP|ENJIN|ENJ|DECENTRALAND|MANA|SANDBOX|SAND|AXIE\s*INFINITY|AXS|SMOOTH\s*LOVE\s*POTION|SLP|CHILIZ|CHZ|BASIC\s*ATTENTION|BAT|ZILLIQA|ZIL|HOLO|HOT|HARMONY|ONE|HEDERA|HBAR|ZCASH|ZEC|DASH|QTUM|ICON|ICX|LISK|LSK|NANO|SIACOIN|SC|DIGIBYTE|DGB|RAVENCOIN|RVN|SYSCOIN|SYS|DECRED|DCR|KOMODO|KMD|ARDOR|ARDR|STRATIS|STRAT|WAVES|BITCOIN\s*GOLD|BTG|NEM|XEM|MONACOIN|MONA|GAS|ONTOLOGY|ONT|NEO|IOST|BITCOIN\s*SV|BSV|TETHER|USDT|USD\s*COIN|USDC|BINANCE\s*USD|BUSD|DAI|SHIBA\s*INU|SHIB|APECOIN|APE|CRONOS|CRO|NEAR\s*PROTOCOL|NEAR|FTX\s*TOKEN|FTT|LEO|QUANT|QNT|HUOBI\s*BTC|HBTC|MONERO|XMR|FLOW|TEZOS|XTZ|ELROND|EGLD|IOTA|MIOTA|KLAYTN|KLAY|THORCHAIN|RUNE|GALA|IMMUTABLE|IMX|GREEN\s*METAVERSE|GMT|GREEN\s*SATOSHI|GST|APTOS|APT|OPTIMISM|OP|ARBITRUM|ARB|BLUR|SUI|PEPE|FLOKI|BONK)\b/gi
    ];

    const allTokens = new Set<string>();
    
    // Extrair usando patterns
    tickerPatterns.forEach(pattern => {
      const matches = fullText.match(pattern) || [];
      matches.forEach(match => {
        // Normalizar nomes compostos para símbolos
        const normalizedMatch = match
          .replace(/\s+/g, '')
          .replace(/BITCOIN\s*CASH/gi, 'BCH')
          .replace(/ETHEREUM\s*CLASSIC/gi, 'ETC')
          .replace(/BITCOIN\s*GOLD/gi, 'BTG')
          .replace(/BITCOIN\s*SV/gi, 'BSV')
          .replace(/USD\s*COIN/gi, 'USDC')
          .replace(/BINANCE\s*USD/gi, 'BUSD')
          .replace(/SHIBA\s*INU/gi, 'SHIB')
          .replace(/NEAR\s*PROTOCOL/gi, 'NEAR')
          .replace(/FTX\s*TOKEN/gi, 'FTT')
          .replace(/HUOBI\s*BTC/gi, 'HBTC')
          .replace(/GREEN\s*METAVERSE/gi, 'GMT')
          .replace(/GREEN\s*SATOSHI/gi, 'GST')
          .replace(/AXIE\s*INFINITY/gi, 'AXS')
          .replace(/SMOOTH\s*LOVE\s*POTION/gi, 'SLP')
          .replace(/BASIC\s*ATTENTION/gi, 'BAT')
          .toUpperCase();
        
        allTokens.add(normalizedMatch);
      });
    });

    // Extrair palavras que podem ser tickers (mais conservador)
    const words = fullText.split(/[^A-Z0-9.]/).filter(word => 
      word && 
      word.length >= 2 && 
      word.length <= 6 && // Reduzido para ser mais específico
      /^[A-Z]/.test(word) &&
      !/^(THE|AND|FOR|ARE|BUT|NOT|YOU|ALL|CAN|HER|WAS|ONE|OUR|OUT|DAY|GET|HAS|HIM|HIS|HOW|ITS|MAY|NEW|NOW|OLD|SEE|TWO|WHO|BOY|DID|ITS|LET|PUT|SAY|SHE|TOO|USE)$/.test(word) // Excluir palavras comuns em inglês
    );
    
    words.forEach(word => allTokens.add(word));

    const tokens = Array.from(allTokens);
    
    // Buscar matches
    const matches = new Set<string>();
    tokens.forEach(token => {
      // Verificar ações
      if (stockMap.has(token)) {
        const fullSymbol = stockMap.get(token)!;
        matches.add(fullSymbol);
      }
      
      // Verificar criptomoedas
      if (cryptoSet.has(token)) {
        matches.add(token);
      }
    });
    
    const symbolsArray = Array.from(matches);
    setDetectedSymbols(symbolsArray);
  }, [loadingStocks, loadingCryptos, stockMap, cryptoSet, title, keywords, content, stocksError, cryptosError]);

  // Renderizar erros se houver
  if (stocksError && cryptosError) {
    return (
      <div className="bg-red-600/20 border border-red-600/30 rounded-lg p-4 text-red-200">
        <p className="text-sm mb-2">⚠️ Erro ao carregar dados financeiros da API BRAPI.</p>
        <details className="text-xs">
          <summary className="cursor-pointer">Ver detalhes dos erros</summary>
          <div className="mt-2 space-y-1">
            {stocksError && <div>Ações: {stocksError.message}</div>}
            {cryptosError && <div>Criptos: {cryptosError.message}</div>}
          </div>
        </details>
      </div>
    );
  }

  // Se não há símbolos detectados, não renderiza nada
  if (detectedSymbols.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white mb-4">
        Ativos Mencionados
      </h3>
      {detectedSymbols.map(symbol => (
        <FinanceCard
          key={symbol}
          symbol={symbol}
          isCrypto={cryptoSet.has(symbol)}
          token={TOKEN}
        />
      ))}
    </div>
  );
};

export default DynamicFinanceCard;

