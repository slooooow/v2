import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useSavedPosts } from '../hooks/useSavedPosts';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { wordpressApi } from '../services/wordpress';
import { toast } from '@/hooks/use-toast';
import { 
  User, LogOut, Edit, Mail, Calendar, Shield, Star, 
  Globe, Clock, Settings, Award, Eye, Heart,
  Camera, MapPin, Phone, Link as LinkIcon, Bell, 
  Smartphone, Zap, Crown, MessageSquare, Bookmark,
  Search, ExternalLink, Trash2, BarChart3, Activity, Share
} from 'lucide-react';
import ProfilePhotoUpload from './ProfilePhotoUpload';

const profileSchema = z.object({
  first_name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  last_name: z.string().min(2, 'Sobrenome deve ter pelo menos 2 caracteres'),
  email: z.string().email('Email inválido'),
});

const PremiumUserPanel: React.FC = () => {
  const { user, logout } = useAuth();
  const { savedPosts, userComments, userStats, getRecentActivities, savePost, unsavePost, addUserComment, removeUserComment } = useSavedPosts();
  const [isEditing, setIsEditing] = useState(false);
  const [profilePhoto, setProfilePhoto] = useState<string>('');
  const [pushNotifications, setPushNotifications] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    if (user) {
      const savedAvatar = localStorage.getItem(`avatar_${user.id}`);
      if (savedAvatar) {
        setProfilePhoto(savedAvatar);
      }
      
      // Load notification preferences from localStorage
      const savedPushNotifications = localStorage.getItem(`push_notifications_${user.id}`);
      const savedEmailNotifications = localStorage.getItem(`email_notifications_${user.id}`);
      
      if (savedPushNotifications !== null) {
        setPushNotifications(JSON.parse(savedPushNotifications));
      }
      if (savedEmailNotifications !== null) {
        setEmailNotifications(JSON.parse(savedEmailNotifications));
      }
    }
  }, [user]);

  const form = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      first_name: user?.first_name || '',
      last_name: user?.last_name || '',
      email: user?.email || '',
    },
  });

  const onSubmit = async (data: z.infer<typeof profileSchema>) => {
    if (!user) return;

    try {
      await wordpressApi.updateUserProfile(user.id, data);
      setIsEditing(false);
      toast({
        title: "Perfil atualizado!",
        description: "Suas informações foram atualizadas com sucesso.",
      });
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar perfil",
        description: error.response?.data?.message || "Erro ao atualizar perfil",
        variant: "destructive",
      });
    }
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso.",
    });
  };

  const handlePhotoChange = (photoUrl: string) => {
    setProfilePhoto(photoUrl);
    if (user) {
      localStorage.setItem(`avatar_${user.id}`, photoUrl);
    }
  };

  const handlePushNotificationChange = (enabled: boolean) => {
    setPushNotifications(enabled);
    if (user) {
      localStorage.setItem(`push_notifications_${user.id}`, JSON.stringify(enabled));
      toast({
        title: enabled ? "Notificações push ativadas" : "Notificações push desativadas",
        description: enabled 
          ? "Você receberá notificações push no seu dispositivo."
          : "Você não receberá mais notificações push.",
      });
    }
  };

  const handleEmailNotificationChange = (enabled: boolean) => {
    setEmailNotifications(enabled);
    if (user) {
      localStorage.setItem(`email_notifications_${user.id}`, JSON.stringify(enabled));
      toast({
        title: enabled ? "Notificações por email ativadas" : "Notificações por email desativadas",
        description: enabled 
          ? "Você receberá notificações por email."
          : "Você não receberá mais notificações por email.",
      });
    }
  };

  const handleUpgrade = () => {
    toast({
      title: "Upgrade em desenvolvimento",
      description: "A funcionalidade de upgrade estará disponível em breve!",
    });
  };

  const getRoleDisplay = (roles: string[]) => {
    const roleMap: Record<string, { label: string; icon: React.ReactNode; color: string; bgColor: string }> = {
      administrator: { 
        label: 'Administrador', 
        icon: <Shield className="w-4 h-4" />, 
        color: 'text-red-400',
        bgColor: 'bg-red-500/20 border-red-500/30'
      },
      editor: { 
        label: 'Editor', 
        icon: <Star className="w-4 h-4" />, 
        color: 'text-purple-400',
        bgColor: 'bg-purple-500/20 border-purple-500/30'
      },
      author: { 
        label: 'Autor', 
        icon: <User className="w-4 h-4" />, 
        color: 'text-blue-400',
        bgColor: 'bg-blue-500/20 border-blue-500/30'
      },
      subscriber: { 
        label: 'Assinante', 
        icon: <User className="w-4 h-4" />, 
        color: 'text-green-400',
        bgColor: 'bg-green-500/20 border-green-500/30'
      },
    };
    
    const role = roles?.[0] || 'subscriber';
    const roleInfo = roleMap[role] || roleMap.subscriber;
    
    return (
      <div className={`inline-flex items-center space-x-2 px-3 py-2 rounded-lg border ${roleInfo.bgColor} ${roleInfo.color}`}>
        {roleInfo.icon}
        <span className="font-medium text-sm">{roleInfo.label}</span>
      </div>
    );
  };

  const getFullName = () => {
    if (user?.first_name && user?.last_name) {
      return `${user.first_name} ${user.last_name}`;
    }
    return user?.name || 'Nome não informado';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getAccountAge = () => {
    if (!user?.registered_date) return 'Data não disponível';
    
    const registrationDate = new Date(user.registered_date);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - registrationDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 30) return `${diffDays} dias`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} meses`;
    return `${Math.floor(diffDays / 365)} anos`;
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: '#0d1117' }}>
        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8">
          <div className="text-center space-y-4">
            <User className="w-16 h-16 text-gray-500 mx-auto" />
            <p className="text-gray-300">Usuário não encontrado.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 sm:p-6 lg:p-8" style={{ backgroundColor: '#0d1117' }}>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header Premium */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-600/20 via-purple-600/20 to-pink-600/20 backdrop-blur-sm border border-gray-700/50">
          {/* Background Pattern */}
          <div 
            className="absolute inset-0 opacity-5"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            }}
          />
          
          <div className="relative p-8 sm:p-12">
            <div className="flex flex-col lg:flex-row items-center lg:items-start gap-8">
              {/* Avatar Section */}
              <div className="flex-shrink-0">
                <div className="relative">
                  <ProfilePhotoUpload
                    currentPhoto={profilePhoto}
                    userName={getFullName()}
                    onPhotoChange={handlePhotoChange}
                  />
                  <div className="absolute -bottom-2 -right-2 w-6 h-6 bg-green-500 rounded-full border-4 border-gray-900 animate-pulse"></div>
                </div>
              </div>

              {/* User Info */}
              <div className="flex-1 text-center lg:text-left space-y-4">
                <div>
                  <h1 className="text-4xl sm:text-5xl font-black text-white mb-2 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                    {getFullName()}
                  </h1>
                  <p className="text-xl text-gray-300 mb-4">@{user.username}</p>
                  {getRoleDisplay(user.roles)}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
                  <div className="bg-gray-800/30 rounded-xl p-4 border border-gray-700/30">
                    <div className="flex items-center space-x-2 text-blue-400 mb-2">
                      <Calendar className="w-4 h-4" />
                      <span className="text-sm font-medium">Membro há</span>
                    </div>
                    <p className="text-white font-bold">{getAccountAge()}</p>
                  </div>

                  <div className="bg-gray-800/30 rounded-xl p-4 border border-gray-700/30">
                    <div className="flex items-center space-x-2 text-green-400 mb-2">
                      <Globe className="w-4 h-4" />
                      <span className="text-sm font-medium">Status</span>
                    </div>
                    <p className="text-white font-bold">Online</p>
                  </div>

                  <div className="bg-gray-800/30 rounded-xl p-4 border border-gray-700/30">
                    <div className="flex items-center space-x-2 text-purple-400 mb-2">
                      <Award className="w-4 h-4" />
                      <span className="text-sm font-medium">ID</span>
                    </div>
                    <p className="text-white font-bold">#{user.id}</p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col gap-3">
                <Button
                  onClick={() => setIsEditing(!isEditing)}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  {isEditing ? 'Cancelar' : 'Editar Perfil'}
                </Button>
                
                <Button
                  onClick={handleLogout}
                  variant="outline"
                  className="border-red-500/50 text-red-400 hover:bg-red-500/10 hover:border-red-500"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sair
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs Premium */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-gray-800/50 border border-gray-700/50 backdrop-blur-sm h-14">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-blue-700 data-[state=active]:text-white">
              <BarChart3 className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="profile" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-purple-700 data-[state=active]:text-white">
              <User className="w-4 h-4 mr-2" />
              Perfil
            </TabsTrigger>
            <TabsTrigger value="comments" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-600 data-[state=active]:to-orange-700 data-[state=active]:text-white">
              <MessageSquare className="w-4 h-4 mr-2" />
              Comentários
            </TabsTrigger>
            <TabsTrigger value="saved" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-pink-700 data-[state=active]:text-white">
              <Bookmark className="w-4 h-4 mr-2" />
              Salvos
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-gray-600 data-[state=active]:to-gray-700 data-[state=active]:text-white">
              <Settings className="w-4 h-4 mr-2" />
              Configurações
            </TabsTrigger>
          </TabsList>

          {/* Tab: Dashboard */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Artigos Lidos</p>
                      <p className="text-2xl font-bold text-white">{userStats.articlesRead}</p>
                    </div>
                    <Eye className="w-8 h-8 text-blue-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Comentários</p>
                      <p className="text-2xl font-bold text-white">{userStats.totalComments}</p>
                    </div>
                    <MessageSquare className="w-8 h-8 text-orange-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Salvos</p>
                      <p className="text-2xl font-bold text-white">{userStats.totalSaved}</p>
                    </div>
                    <Bookmark className="w-8 h-8 text-pink-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Curtidas</p>
                      <p className="text-2xl font-bold text-white">{userStats.totalLikes}</p>
                    </div>
                    <Heart className="w-8 h-8 text-red-400" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Activity className="w-5 h-5" />
                  <span>Atividade Recente</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {getRecentActivities(5).length === 0 ? (
                  <div className="text-center py-8">
                    <Activity className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-400">Nenhuma atividade recente</p>
                    <p className="text-gray-500 text-sm">Comece explorando artigos para ver suas atividades aqui!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {getRecentActivities(5).map((activity) => (
                      <div key={activity.id} className="flex items-center space-x-3 p-3 bg-gray-700/30 rounded-lg">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          activity.type === 'comment' ? 'bg-orange-500/20 text-orange-400' :
                          activity.type === 'save' ? 'bg-pink-500/20 text-pink-400' :
                          activity.type === 'view' ? 'bg-blue-500/20 text-blue-400' :
                          activity.type === 'like' ? 'bg-red-500/20 text-red-400' :
                          'bg-green-500/20 text-green-400'
                        }`}>
                          {activity.type === 'comment' && <MessageSquare className="w-5 h-5" />}
                          {activity.type === 'save' && <Bookmark className="w-5 h-5" />}
                          {activity.type === 'view' && <Eye className="w-5 h-5" />}
                          {activity.type === 'like' && <Heart className="w-5 h-5" />}
                          {activity.type === 'share' && <Share className="w-5 h-5" />}
                        </div>
                        <div className="flex-1">
                          <p className="text-white text-sm font-medium">{activity.title}</p>
                          <p className="text-gray-400 text-xs">{activity.description}</p>
                          <p className="text-gray-500 text-xs">{new Date(activity.date).toLocaleString('pt-BR')}</p>
                        </div>
                        {activity.post_slug && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => window.open(`/post/${activity.post_slug}`, '_blank')}
                            className="text-blue-400 hover:text-blue-300"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Profile */}
          <TabsContent value="profile" className="space-y-6">
            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <User className="w-5 h-5" />
                  <span>Informações Pessoais</span>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Gerencie suas informações pessoais e como elas aparecem para outros usuários.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isEditing ? (
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="first_name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-300 font-medium">Nome</FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 h-12"
                                  placeholder="Seu nome"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="last_name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-300 font-medium">Sobrenome</FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 h-12"
                                  placeholder="Seu sobrenome"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300 font-medium">Email</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="email"
                                className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 h-12"
                                placeholder="seu@email.com"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex gap-4 pt-4">
                        <Button
                          type="submit"
                          className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white"
                        >
                          Salvar Alterações
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsEditing(false)}
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                        >
                          Cancelar
                        </Button>
                      </div>
                    </form>
                  </Form>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="bg-gray-700/30 rounded-xl p-4 border border-gray-600/30">
                        <div className="flex items-center mb-2">
                          <User className="w-4 h-4 text-blue-400 mr-2" />
                          <h4 className="text-gray-300 font-medium">Nome Completo</h4>
                        </div>
                        <p className="text-white text-lg">{getFullName()}</p>
                      </div>

                      <div className="bg-gray-700/30 rounded-xl p-4 border border-gray-600/30">
                        <div className="flex items-center mb-2">
                          <Mail className="w-4 h-4 text-green-400 mr-2" />
                          <h4 className="text-gray-300 font-medium">Email</h4>
                        </div>
                        <p className="text-white text-lg">{user.email}</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="bg-gray-700/30 rounded-xl p-4 border border-gray-600/30">
                        <div className="flex items-center mb-2">
                          <User className="w-4 h-4 text-purple-400 mr-2" />
                          <h4 className="text-gray-300 font-medium">Username</h4>
                        </div>
                        <p className="text-white text-lg">@{user.username}</p>
                      </div>

                      <div className="bg-gray-700/30 rounded-xl p-4 border border-gray-600/30">
                        <div className="flex items-center mb-2">
                          <Calendar className="w-4 h-4 text-yellow-400 mr-2" />
                          <h4 className="text-gray-300 font-medium">Membro desde</h4>
                        </div>
                        <p className="text-white text-lg">{formatDate(user.registered_date)}</p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Comentários */}
          <TabsContent value="comments" className="space-y-6">
            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <MessageSquare className="w-5 h-5" />
                  <span>Meus Comentários</span>
                  <Badge className="bg-orange-600 text-white">
                    {userComments.length}
                  </Badge>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Todos os comentários que você fez em publicações.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {userComments.length === 0 ? (
                  <div className="text-center py-12">
                    <MessageSquare className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-300 mb-2">Nenhum comentário ainda</h3>
                    <p className="text-gray-400 mb-6">Você ainda não fez nenhum comentário em publicações.</p>
                    <Button
                      variant="outline"
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <Search className="w-4 h-4 mr-2" />
                      Explorar Artigos
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {userComments.map((comment) => (
                      <div
                        key={comment.id}
                        className="bg-gray-700/50 rounded-xl p-4 border border-gray-600/50 hover:border-gray-500/50 transition-all duration-300"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h4 className="font-semibold text-white mb-1 hover:text-blue-400 cursor-pointer">
                              {comment.post_title}
                            </h4>
                            <div className="flex items-center space-x-3 text-sm text-gray-400">
                              <span>{new Date(comment.date).toLocaleDateString('pt-BR')}</span>
                              <Badge 
                                className={`text-xs ${
                                  comment.status === 'approved' 
                                    ? 'bg-green-600 text-white' 
                                    : comment.status === 'pending'
                                    ? 'bg-yellow-600 text-white'
                                    : 'bg-red-600 text-white'
                                }`}
                              >
                                {comment.status === 'approved' ? 'Aprovado' : 
                                 comment.status === 'pending' ? 'Pendente' : 'Spam'}
                              </Badge>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeUserComment(comment.id)}
                            className="text-red-400 hover:text-red-300 hover:bg-red-600/20"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        <div className="text-gray-300 text-sm leading-relaxed mb-3">
                          {comment.content.length > 200 
                            ? `${comment.content.substring(0, 200)}...` 
                            : comment.content}
                        </div>
                        <div className="flex items-center space-x-3">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => window.open(`/post/${comment.post_slug}`, '_blank')}
                            className="text-blue-400 hover:text-blue-300 hover:bg-blue-600/20"
                          >
                            <ExternalLink className="w-4 h-4 mr-2" />
                            Ver Publicação
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-gray-400 hover:text-gray-300 hover:bg-gray-600/20"
                          >
                            <Edit className="w-4 h-4 mr-2" />
                            Editar
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Salvos */}
          <TabsContent value="saved" className="space-y-6">
            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Bookmark className="w-5 h-5" />
                  <span>Publicações Salvas</span>
                  <Badge className="bg-pink-600 text-white">
                    {savedPosts.length}
                  </Badge>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Todas as publicações que você salvou para ler mais tarde.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {savedPosts.length === 0 ? (
                  <div className="text-center py-12">
                    <Bookmark className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-300 mb-2">Nenhuma publicação salva</h3>
                    <p className="text-gray-400 mb-6">Você ainda não salvou nenhuma publicação. Comece explorando nossos artigos!</p>
                    <Button
                      variant="outline"
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <Search className="w-4 h-4 mr-2" />
                      Explorar Artigos
                    </Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {savedPosts.map((post) => (
                      <div
                        key={post.id}
                        className="bg-gray-700/50 rounded-xl overflow-hidden border border-gray-600/50 hover:border-gray-500/50 transition-all duration-300 group"
                      >
                        {post.featured_media_url && (
                          <div className="aspect-video overflow-hidden">
                            <img
                              src={post.featured_media_url}
                              alt={post.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                          </div>
                        )}
                        <div className="p-4">
                          <h4 className="font-semibold text-white mb-2 line-clamp-2 hover:text-blue-400 cursor-pointer">
                            {post.title}
                          </h4>
                          <p className="text-gray-400 text-sm mb-3 line-clamp-2">
                            {post.excerpt && typeof post.excerpt === 'string' ? post.excerpt.replace(/<[^>]*>/g, '') : 'Sem descrição disponível'}
                          </p>
                          <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                            <span>Salvo em {new Date(post.savedAt).toLocaleDateString('pt-BR')}</span>
                            <span>Publicado em {new Date(post.date).toLocaleDateString('pt-BR')}</span>
                          </div>
                          <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                            <span>👁️ {post.views?.toLocaleString() || 0} visualizações</span>
                            <span>✍️ {post.author}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => window.open(`/post/${post.slug}`, '_blank')}
                              className="text-blue-400 hover:text-blue-300 hover:bg-blue-600/20 flex-1"
                            >
                              <ExternalLink className="w-4 h-4 mr-2" />
                              Ler Artigo
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => unsavePost(post.id)}
                              className="text-red-400 hover:text-red-300 hover:bg-red-600/20"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Settings */}
          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Settings className="w-5 h-5" />
                  <span>Configurações</span>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Gerencie suas preferências e configurações de conta.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Notification Settings */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white flex items-center space-x-2">
                    <Bell className="w-5 h-5 text-blue-400" />
                    <span>Notificações</span>
                  </h3>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-700/30 rounded-xl border border-gray-600/30">
                      <div className="flex items-center space-x-3">
                        <Smartphone className="w-5 h-5 text-green-400" />
                        <div>
                          <h4 className="text-white font-medium">Notificações Push</h4>
                          <p className="text-gray-400 text-sm">Receba notificações no seu dispositivo</p>
                        </div>
                      </div>
                      <Switch
                        checked={pushNotifications}
                        onCheckedChange={handlePushNotificationChange}
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-700/30 rounded-xl border border-gray-600/30">
                      <div className="flex items-center space-x-3">
                        <Mail className="w-5 h-5 text-blue-400" />
                        <div>
                          <h4 className="text-white font-medium">Notificações por Email</h4>
                          <p className="text-gray-400 text-sm">Receba atualizações por email</p>
                        </div>
                      </div>
                      <Switch
                        checked={emailNotifications}
                        onCheckedChange={handleEmailNotificationChange}
                      />
                    </div>
                  </div>
                </div>

                {/* Account Actions */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white flex items-center space-x-2">
                    <Shield className="w-5 h-5 text-red-400" />
                    <span>Ações da Conta</span>
                  </h3>
                  
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button
                      onClick={handleLogout}
                      variant="destructive"
                      className="bg-red-600 hover:bg-red-700 h-12 px-6"
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Sair da Conta
                    </Button>
                    <Button
                      variant="outline"
                      className="border-gray-600 text-gray-300 hover:bg-gray-700 h-12 px-6"
                    >
                      <User className="w-4 h-4 mr-2" />
                      Exportar Dados
                    </Button>
                    <Button
                      variant="outline"
                      className="border-red-600 text-red-300 hover:bg-red-700 h-12 px-6"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Excluir Conta
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default PremiumUserPanel;

