import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Bookmark, Share, Eye, BookmarkCheck } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useSavedPosts } from '../hooks/useSavedPosts';
import { toast } from '@/hooks/use-toast';

interface Post {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  featured_media_url?: string;
  slug: string;
  author?: string;
  category?: string;
}

interface SavePostButtonProps {
  post: Post;
}

const SavePostButton: React.FC<SavePostButtonProps> = ({ post }) => {
  const { isLoggedIn } = useAuth();
  const { isPostSaved, savePost, unsavePost, trackShare, trackPageView } = useSavedPosts();
  const [isSharing, setIsSharing] = useState(false);
  const [pageViews, setPageViews] = useState(() => {
    // Carregar visualizações reais do localStorage
    const views = localStorage.getItem(`post_views_${post.id}`);
    return views ? parseInt(views) : Math.floor(Math.random() * 500) + 100; // Fallback inicial
  });

  const isSaved = isPostSaved(post.id);

  // Incrementar visualizações apenas uma vez por sessão
  React.useEffect(() => {
    const sessionKey = `post_viewed_${post.id}_${Date.now().toString().slice(0, -7)}`; // Sessão por hora
    const hasViewed = sessionStorage.getItem(sessionKey);
    
    if (!hasViewed) {
      const currentViews = pageViews + 1;
      setPageViews(currentViews);
      localStorage.setItem(`post_views_${post.id}`, currentViews.toString());
      sessionStorage.setItem(sessionKey, 'true');
      
      // Track page view se o usuário estiver logado
      if (isLoggedIn) {
        // Garantir que o title seja uma string
        const postTitle = typeof post.title === 'string' ? post.title : post.title?.rendered || 'Título não disponível';
        trackPageView(post.id, postTitle, post.slug);
      }
    }
  }, [post.id]); // Removido isLoggedIn, trackPageView, post.title, post.slug das dependências

  const handleSavePost = () => {
    if (!isLoggedIn) {
      toast({
        title: "Login necessário",
        description: "Você precisa estar logado para salvar publicações.",
        variant: "destructive",
      });
      return;
    }

    if (isSaved) {
      unsavePost(post.id);
      toast({
        title: "Publicação removida",
        description: "A publicação foi removida dos seus salvos.",
      });
    } else {
      // Garantir que todos os campos sejam strings
      const postTitle = typeof post.title === 'string' ? post.title : post.title?.rendered || 'Título não disponível';
      const postExcerpt = typeof post.excerpt === 'string' ? post.excerpt : post.excerpt?.rendered || 'Sem descrição disponível';
      
      savePost({
        id: post.id,
        title: postTitle,
        excerpt: postExcerpt,
        date: post.date,
        featured_media_url: post.featured_media_url,
        slug: post.slug,
        author: post.author || 'Autor desconhecido',
        category: post.category || 'Geral',
        views: pageViews
      });
      toast({
        title: "Publicação salva!",
        description: "A publicação foi adicionada aos seus salvos.",
      });
    }
  };

  const handleShare = async () => {
    setIsSharing(true);
    
    try {
      // Garantir que title e excerpt sejam strings
      const postTitle = typeof post.title === 'string' ? post.title : post.title?.rendered || 'Título não disponível';
      const postExcerpt = typeof post.excerpt === 'string' ? post.excerpt : post.excerpt?.rendered || '';
      
      const shareData = {
        title: postTitle,
        text: postExcerpt.replace(/<[^>]*>/g, '').substring(0, 100) + '...',
        url: `${window.location.origin}/post/${post.slug}`,
      };

      if (navigator.share && navigator.canShare(shareData)) {
        await navigator.share(shareData);
        
        // Track share se o usuário estiver logado
        if (isLoggedIn) {
          trackShare(post.id, postTitle, post.slug);
        }
        
        toast({
          title: "Artigo compartilhado!",
          description: "O artigo foi compartilhado com sucesso.",
        });
      } else {
        // Fallback: copiar para clipboard
        await navigator.clipboard.writeText(`${postTitle} - ${window.location.origin}/post/${post.slug}`);
        
        // Track share se o usuário estiver logado
        if (isLoggedIn) {
          trackShare(post.id, postTitle, post.slug);
        }
        
        toast({
          title: "Link copiado!",
          description: "O link do artigo foi copiado para a área de transferência.",
        });
      }
    } catch (error) {
      console.error('Erro ao compartilhar:', error);
      toast({
        title: "Erro ao compartilhar",
        description: "Não foi possível compartilhar o artigo.",
        variant: "destructive",
      });
    } finally {
      setIsSharing(false);
    }
  };

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 space-y-4">
      <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
        <Eye className="w-5 h-5 text-blue-400" />
        <span>Ações do Artigo</span>
      </h3>
      
      {/* Estatísticas do Post */}
      <div className="bg-gray-700/30 rounded-xl p-4 border border-gray-600/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-blue-400">
            <Eye className="w-4 h-4" />
            <span className="text-sm font-medium">Visualizações</span>
          </div>
          <span className="text-white font-bold">{pageViews.toLocaleString()}</span>
        </div>
      </div>

      {/* Botões de Ação */}
      <div className="space-y-3">
        <Button
          onClick={handleSavePost}
          className={`w-full h-12 transition-all duration-300 ${
            isSaved
              ? 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white'
              : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white'
          } shadow-lg hover:shadow-xl transform hover:scale-105`}
        >
          {isSaved ? (
            <>
              <BookmarkCheck className="w-5 h-5 mr-2" />
              Publicação Salva
            </>
          ) : (
            <>
              <Bookmark className="w-5 h-5 mr-2" />
              Salvar Publicação
            </>
          )}
        </Button>

        <Button
          onClick={handleShare}
          disabled={isSharing}
          variant="outline"
          className="w-full h-12 border-gray-600 text-gray-300 hover:bg-gray-700 hover:border-gray-500 transition-all duration-300 transform hover:scale-105"
        >
          <Share className="w-5 h-5 mr-2" />
          {isSharing ? 'Compartilhando...' : 'Compartilhar Artigo'}
        </Button>
      </div>

      {/* Informações Adicionais */}
      <div className="text-xs text-gray-400 space-y-1 pt-2 border-t border-gray-700/50">
        <p>📅 Publicado em {new Date(post.date).toLocaleDateString('pt-BR')}</p>
        {post.author && <p>✍️ Por {post.author}</p>}
        {post.category && <p>🏷️ Categoria: {post.category}</p>}
      </div>
    </div>
  );
};

export default SavePostButton;

