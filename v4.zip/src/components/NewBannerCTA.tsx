
import React from 'react';
import { TrendingUp, Zap, Globe, Users } from 'lucide-react';

const NewBannerCTA: React.FC = () => {
  return (
    <div className="w-screen relative left-1/2 -translate-x-1/2 my-20">
      {/* Background com gradiente e efeitos - largura total da tela */}
      <div className="relative bg-gradient-to-r from-blue-900/40 via-purple-900/40 to-pink-900/40 backdrop-blur-sm border-y border-white/10">
        {/* Elementos flutuantes animados */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-blue-400/30 rounded-full animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${i * 0.3}s`,
                animationDuration: `${3 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>

        <div className="relative px-4 sm:px-6 lg:px-8 py-16">
          <div className="max-w-7xl mx-auto text-center">
            {/* Título principal */}
            <div className="mb-8">
              <h2 className="text-3xl sm:text-4xl lg:text-6xl font-black text-white mb-4 tracking-tight">
                Explore o mercado com{' '}
                <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  Finver.Finance
                </span>
              </h2>
              <p className="text-gray-300 text-base sm:text-lg lg:text-xl max-w-3xl mx-auto leading-relaxed px-4">
                Acompanhe as principais movimentações do mercado financeiro com análises exclusivas e dados em tempo real
              </p>
            </div>

            {/* Grid de recursos - sem estatísticas numéricas */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8 mb-12 px-4">
              {[
                { icon: TrendingUp, label: "Análises Completas", color: "from-green-400 to-emerald-400" },
                { icon: Zap, label: "Atualização em Tempo Real", color: "from-yellow-400 to-orange-400" },
                { icon: Globe, label: "Mercados Mundiais", color: "from-blue-400 to-cyan-400" },
                { icon: Users, label: "Analistas Profissionais", color: "from-purple-400 to-pink-400" }
              ].map((feature, index) => (
                <div 
                  key={index}
                  className="group p-4 sm:p-6 bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-xl hover:border-white/20 transition-all duration-300 animate-fade-in-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="mb-4">
                    <div className={`w-10 h-10 sm:w-12 sm:h-12 mx-auto bg-gradient-to-r ${feature.color} rounded-lg flex items-center justify-center mb-3`}>
                      <feature.icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                    </div>
                  </div>
                  <div className="text-gray-400 text-xs sm:text-sm">{feature.label}</div>
                </div>
              ))}
            </div>

            {/* Call to action - Centralizado e responsivo */}
            <div className="flex justify-center px-4">
              <a 
                href="https://finver.finance" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group px-6 sm:px-8 py-3 sm:py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold rounded-xl transition-all duration-300 hover:shadow-2xl flex items-center relative overflow-hidden text-sm sm:text-base"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                <Globe className="w-4 h-4 sm:w-5 sm:h-5 mr-2 sm:mr-3 relative z-10" />
                <span className="relative z-10">Explorar Mercados</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewBannerCTA;
