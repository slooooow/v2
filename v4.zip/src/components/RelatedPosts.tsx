
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { WordPressPost } from '../types/wordpress';
import { formatDate, stripHtml, getImageUrl } from '../utils/formatting';
import PostCard from './PostCard';
import { useIsMobile } from '../hooks/use-mobile';

interface RelatedPostsProps {
  posts: WordPressPost[];
  title?: string;
  className?: string;
}

const RelatedPosts: React.FC<RelatedPostsProps> = ({ 
  posts, 
  title = "Artigos Relacionados",
  className = "" 
}) => {
  const isMobile = useIsMobile();
  const [currentIndex, setCurrentIndex] = useState(0);

  const navigateRelated = (direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      setCurrentIndex(prev => prev === 0 ? posts.length - 1 : prev - 1);
    } else {
      setCurrentIndex(prev => prev === posts.length - 1 ? 0 : prev + 1);
    }
  };

  if (posts.length === 0) {
    return null;
  }

  // Layout mobile - carrossel
  if (isMobile) {
    return (
      <div className={`mt-12 pt-8 border-t border-gray-800 ${className}`}>
        <h3 className="text-xl font-bold text-white mb-6">{title}</h3>
        
        <div className="relative">
          {/* Navegação */}
          {posts.length > 1 && (
            <>
              <button 
                onClick={() => navigateRelated('prev')}
                className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 flex items-center justify-center bg-gray-800/70 backdrop-blur-sm text-white rounded-full shadow-lg"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              
              <button 
                onClick={() => navigateRelated('next')}
                className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 flex items-center justify-center bg-gray-800/70 backdrop-blur-sm text-white rounded-full shadow-lg"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </>
          )}
          
          {/* Post atual */}
          {posts[currentIndex] && (
            <div className="px-4">
              <PostCard post={posts[currentIndex]} size="medium" />
            </div>
          )}
          
          {/* Indicadores */}
          {posts.length > 1 && (
            <div className="flex justify-center space-x-2 mt-4">
              {posts.map((_, index) => (
                <button 
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentIndex 
                      ? 'bg-blue-500 w-4' 
                      : 'bg-gray-600'
                  }`}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Layout desktop - sidebar
  return (
    <div className={`bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 ${className}`}>
      <h3 className="text-xl font-bold text-white mb-6">{title}</h3>
      
      <div className="space-y-4">
        {posts.slice(0, 4).map((post) => (
          <Link 
            key={post.id} 
            to={`/post/${post.slug}`}
            className="group block"
          >
            <div className="flex space-x-4 p-3 bg-gray-700/30 hover:bg-gray-700/50 rounded-xl transition-all duration-300 hover:scale-105">
              <div className="w-20 h-20 flex-shrink-0 overflow-hidden rounded-lg">
                <img
                  src={getImageUrl(post)}
                  alt={stripHtml(post.title.rendered)}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  onError={(e) => {
                    e.currentTarget.src = '/placeholder.svg';
                  }}
                />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-white font-semibold line-clamp-2 group-hover:text-blue-300 transition-colors duration-300 mb-2">
                  {stripHtml(post.title.rendered)}
                </h4>
                <div className="flex items-center space-x-2 text-xs text-gray-500">
                  <Calendar className="w-3 h-3" />
                  <span>{formatDate(post.date)}</span>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default RelatedPosts;
