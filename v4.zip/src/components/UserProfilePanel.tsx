import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useSavedPosts } from '../hooks/useSavedPosts';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { wordpressApi } from '../services/wordpress';
import { toast } from '@/hooks/use-toast';
import { 
  User, LogOut, Edit, Mail, Calendar, Shield, Star, MapPin, Phone, 
  Globe, Briefcase, Heart, Settings, Camera, Award, TrendingUp,
  Eye, EyeOff, Lock, Bell, Palette, Monitor, BarChart3, Target,
  Zap, Crown, Bookmark, Clock, Activity, Users, MessageSquare,
  FileText, Download, Upload, Trash2, Plus, Search, Filter,
  ChevronRight, ChevronDown, ExternalLink, Copy, Check
} from 'lucide-react';
import ProfilePhotoUpload from './ProfilePhotoUpload';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';

const profileSchema = z.object({
  first_name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  last_name: z.string().min(2, 'Sobrenome deve ter pelo menos 2 caracteres'),
  email: z.string().email('Email inválido'),
  bio: z.string().max(500, 'Bio deve ter no máximo 500 caracteres').optional(),
  website: z.string().url('URL inválida').optional().or(z.literal('')),
  location: z.string().max(100, 'Localização deve ter no máximo 100 caracteres').optional(),
  phone: z.string().max(20, 'Telefone deve ter no máximo 20 caracteres').optional(),
  company: z.string().max(100, 'Empresa deve ter no máximo 100 caracteres').optional(),
  job_title: z.string().max(100, 'Cargo deve ter no máximo 100 caracteres').optional(),
});

interface UserProfilePanelProps {
  isEditingFromBanner?: boolean;
  onEditComplete?: () => void;
}

const UserProfilePanel: React.FC<UserProfilePanelProps> = ({ 
  isEditingFromBanner = false, 
  onEditComplete 
}) => {
  const { user, logout } = useAuth();
  const { savedPosts, userComments, unsavePost, removeUserComment } = useSavedPosts();
  const [isEditing, setIsEditing] = useState(isEditingFromBanner);
  const [profilePhoto, setProfilePhoto] = useState<string>('');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showPassword, setShowPassword] = useState(false);
  const [notifications, setNotifications] = useState({
    email: true,
    push: false,
    marketing: false,
  });
  const [theme, setTheme] = useState('dark');
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});
  const [copiedField, setCopiedField] = useState<string>('');

  // Sync with external editing state
  useEffect(() => {
    setIsEditing(isEditingFromBanner);
  }, [isEditingFromBanner]);

  // Carregar avatar salvo quando o componente inicializar
  useEffect(() => {
    if (user) {
      const savedAvatar = localStorage.getItem(`avatar_${user.id}`);
      if (savedAvatar) {
        setProfilePhoto(savedAvatar);
      }
    }
  }, [user]);

  const form = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      first_name: user?.first_name || '',
      last_name: user?.last_name || '',
      email: user?.email || '',
      bio: '',
      website: '',
      location: '',
      phone: '',
      company: '',
      job_title: '',
    },
  });

  const onSubmit = async (data: z.infer<typeof profileSchema>) => {
    if (!user) return;

    try {
      await wordpressApi.updateUserProfile(user.id, data);
      setIsEditing(false);
      onEditComplete?.();
      toast({
        title: "Perfil atualizado!",
        description: "Suas informações foram atualizadas com sucesso.",
      });
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar perfil",
        description: error.response?.data?.message || "Erro ao atualizar perfil",
        variant: "destructive",
      });
    }
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso.",
    });
  };

  const handlePhotoChange = (photoUrl: string) => {
    setProfilePhoto(photoUrl);
    if (user) {
      localStorage.setItem(`avatar_${user.id}`, photoUrl);
    }
  };

  const handleEditToggle = () => {
    const newEditingState = !isEditing;
    setIsEditing(newEditingState);
    if (!newEditingState) {
      onEditComplete?.();
    }
  };

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(''), 2000);
      toast({
        title: "Copiado!",
        description: "Texto copiado para a área de transferência.",
      });
    } catch (error) {
      toast({
        title: "Erro ao copiar",
        description: "Não foi possível copiar o texto.",
        variant: "destructive",
      });
    }
  };

  const getRoleDisplay = (roles: string[]) => {
    const roleMap: Record<string, { label: string; icon: React.ReactNode; color: string; gradient: string }> = {
      administrator: { 
        label: 'Administrador', 
        icon: <Crown className="w-4 h-4" />, 
        color: 'bg-red-500', 
        gradient: 'from-red-500 to-red-600' 
      },
      editor: { 
        label: 'Editor', 
        icon: <Star className="w-4 h-4" />, 
        color: 'bg-purple-500', 
        gradient: 'from-purple-500 to-purple-600' 
      },
      author: { 
        label: 'Autor', 
        icon: <FileText className="w-4 h-4" />, 
        color: 'bg-blue-500', 
        gradient: 'from-blue-500 to-blue-600' 
      },
      subscriber: { 
        label: 'Assinante', 
        icon: <User className="w-4 h-4" />, 
        color: 'bg-green-500', 
        gradient: 'from-green-500 to-green-600' 
      },
    };
    
    const role = roles?.[0] || 'subscriber';
    const roleInfo = roleMap[role] || roleMap.subscriber;
    
    return (
      <Badge className={`bg-gradient-to-r ${roleInfo.gradient} text-white border-0 shadow-lg`}>
        {roleInfo.icon}
        <span className="ml-1 font-semibold">{roleInfo.label}</span>
      </Badge>
    );
  };

  const getFullName = () => {
    if (user?.first_name && user?.last_name) {
      return `${user.first_name} ${user.last_name}`;
    }
    return user?.name || 'Nome não informado';
  };

  const getInitials = () => {
    const name = getFullName();
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  // Mock data para demonstração
  const mockStats = {
    articles: 24,
    views: 12500,
    likes: 892,
    comments: 156,
    followers: 1240,
    following: 89,
    readingTime: 45,
    streak: 12
  };

  const mockActivities = [
    { action: 'Artigo publicado', title: 'Análise do mercado de ações em dezembro', time: '2 horas atrás', icon: <FileText className="w-4 h-4" />, color: 'text-blue-400' },
    { action: 'Comentário curtido', title: 'Seu comentário em "Bitcoin em alta"', time: '4 horas atrás', icon: <Heart className="w-4 h-4" />, color: 'text-red-400' },
    { action: 'Novo seguidor', title: 'Maria Silva começou a seguir você', time: '6 horas atrás', icon: <Users className="w-4 h-4" />, color: 'text-green-400' },
    { action: 'Artigo salvo', title: 'Salvou "Estratégias de investimento"', time: '1 dia atrás', icon: <Bookmark className="w-4 h-4" />, color: 'text-yellow-400' },
    { action: 'Perfil atualizado', title: 'Foto de perfil alterada', time: '2 dias atrás', icon: <Camera className="w-4 h-4" />, color: 'text-purple-400' },
  ];

  const mockAchievements = [
    { title: 'Primeiro Artigo', description: 'Publicou seu primeiro artigo', icon: <FileText className="w-6 h-6" />, earned: true, date: '15 Nov 2024' },
    { title: 'Escritor Popular', description: '1000+ visualizações em um artigo', icon: <TrendingUp className="w-6 h-6" />, earned: true, date: '20 Nov 2024' },
    { title: 'Engajamento Alto', description: '100+ curtidas em um artigo', icon: <Heart className="w-6 h-6" />, earned: true, date: '25 Nov 2024' },
    { title: 'Influenciador', description: '1000+ seguidores', icon: <Users className="w-6 h-6" />, earned: true, date: '1 Dez 2024' },
    { title: 'Especialista', description: '50+ artigos publicados', icon: <Award className="w-6 h-6" />, earned: false, progress: 48 },
    { title: 'Mentor', description: '500+ comentários úteis', icon: <MessageSquare className="w-6 h-6" />, earned: false, progress: 156 },
  ];

  if (!user) {
    return (
      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8">
        <div className="text-center space-y-4">
          <User className="w-16 h-16 text-gray-500 mx-auto" />
          <p className="text-gray-300">Usuário não encontrado.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header Premium com Avatar e Informações */}
      <div className="relative overflow-hidden">
        {/* Background com gradiente animado */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-purple-600/20 to-pink-600/20 animate-gradient-x"></div>
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.03"%3E%3Ccircle cx="30" cy="30" r="2"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-50"></div>
        
        <Card className="relative bg-gray-800/60 backdrop-blur-xl border-gray-700/50 shadow-2xl">
          <CardContent className="p-8">
            <div className="flex flex-col xl:flex-row items-center xl:items-start gap-8">
              {/* Avatar Section */}
              <div className="flex-shrink-0 relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full opacity-20 blur-xl animate-pulse"></div>
                <ProfilePhotoUpload
                  currentPhoto={profilePhoto}
                  userName={getFullName()}
                  onPhotoChange={handlePhotoChange}
                />
              </div>
              
              {/* User Info */}
              <div className="flex-1 text-center xl:text-left space-y-6">
                <div>
                  <h1 className="text-5xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent mb-3">
                    {getFullName()}
                  </h1>
                  <div className="flex items-center justify-center xl:justify-start space-x-3 mb-4">
                    <p className="text-gray-300 text-xl">@{user.username}</p>
                    <button
                      onClick={() => copyToClipboard(user.username, 'username')}
                      className="p-1 hover:bg-gray-700 rounded transition-colors"
                    >
                      {copiedField === 'username' ? (
                        <Check className="w-4 h-4 text-green-400" />
                      ) : (
                        <Copy className="w-4 h-4 text-gray-400" />
                      )}
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-3 justify-center xl:justify-start">
                    {getRoleDisplay(user.roles)}
                    <Badge variant="outline" className="border-gray-600 text-gray-300 bg-gray-800/50">
                      <Calendar className="w-3 h-3 mr-1" />
                      Membro desde {new Date(user.registered_date).getFullYear()}
                    </Badge>
                    <Badge variant="outline" className="border-green-600 text-green-300 bg-green-800/20">
                      <Zap className="w-3 h-3 mr-1" />
                      {mockStats.streak} dias consecutivos
                    </Badge>
                  </div>
                </div>
                
                {/* Stats Grid Premium */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/20 p-4 rounded-2xl border border-blue-500/30 backdrop-blur-sm">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white mb-1">{mockStats.articles}</div>
                      <div className="text-xs text-blue-300 font-medium">Artigos</div>
                    </div>
                  </div>
                  <div className="bg-gradient-to-br from-purple-500/20 to-purple-600/20 p-4 rounded-2xl border border-purple-500/30 backdrop-blur-sm">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white mb-1">{mockStats.views.toLocaleString()}</div>
                      <div className="text-xs text-purple-300 font-medium">Visualizações</div>
                    </div>
                  </div>
                  <div className="bg-gradient-to-br from-green-500/20 to-green-600/20 p-4 rounded-2xl border border-green-500/30 backdrop-blur-sm">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white mb-1">{mockStats.likes}</div>
                      <div className="text-xs text-green-300 font-medium">Curtidas</div>
                    </div>
                  </div>
                  <div className="bg-gradient-to-br from-orange-500/20 to-orange-600/20 p-4 rounded-2xl border border-orange-500/30 backdrop-blur-sm">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white mb-1">{mockStats.followers}</div>
                      <div className="text-xs text-orange-300 font-medium">Seguidores</div>
                    </div>
                  </div>
                </div>

                {/* Quick Actions Premium */}
                <div className="flex flex-wrap gap-3 justify-center xl:justify-start">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleEditToggle}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:border-gray-500 bg-gray-800/50 backdrop-blur-sm"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    {isEditing ? 'Cancelar' : 'Editar Perfil'}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:border-gray-500 bg-gray-800/50 backdrop-blur-sm"
                  >
                    <Settings className="w-4 h-4 mr-2" />
                    Configurações
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:border-gray-500 bg-gray-800/50 backdrop-blur-sm"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Ver Perfil Público
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs Premium */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 md:grid-cols-7 bg-gray-800/50 border border-gray-700/50 backdrop-blur-sm h-14">
          <TabsTrigger value="dashboard" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-blue-700 data-[state=active]:text-white">
            <BarChart3 className="w-4 h-4 mr-2" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="profile" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-purple-700 data-[state=active]:text-white">
            <User className="w-4 h-4 mr-2" />
            Perfil
          </TabsTrigger>
          <TabsTrigger value="comments" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-600 data-[state=active]:to-orange-700 data-[state=active]:text-white">
            <MessageSquare className="w-4 h-4 mr-2" />
            Comentários
          </TabsTrigger>
          <TabsTrigger value="saved" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-600 data-[state=active]:to-pink-700 data-[state=active]:text-white">
            <Bookmark className="w-4 h-4 mr-2" />
            Salvos
          </TabsTrigger>
          <TabsTrigger value="activity" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-600 data-[state=active]:to-green-700 data-[state=active]:text-white">
            <Activity className="w-4 h-4 mr-2" />
            Atividade
          </TabsTrigger>
          <TabsTrigger value="achievements" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-yellow-600 data-[state=active]:to-yellow-700 data-[state=active]:text-white">
            <Award className="w-4 h-4 mr-2" />
            Conquistas
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-gray-600 data-[state=active]:to-gray-700 data-[state=active]:text-white">
            <Settings className="w-4 h-4 mr-2" />
            Configurações
          </TabsTrigger>
        </TabsList>

        {/* Tab: Dashboard */}
        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Métricas Principais */}
            <div className="lg:col-span-2 space-y-6">
              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5 text-blue-400" />
                    <span>Desempenho dos Últimos 30 Dias</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-400">Visualizações</span>
                          <span className="text-white font-semibold">8,420</span>
                        </div>
                        <Progress value={84} className="h-2" />
                        <p className="text-xs text-green-400 mt-1">+12% vs mês anterior</p>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-400">Engajamento</span>
                          <span className="text-white font-semibold">6.8%</span>
                        </div>
                        <Progress value={68} className="h-2" />
                        <p className="text-xs text-green-400 mt-1">+3.2% vs mês anterior</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-400">Novos Seguidores</span>
                          <span className="text-white font-semibold">156</span>
                        </div>
                        <Progress value={78} className="h-2" />
                        <p className="text-xs text-green-400 mt-1">+8% vs mês anterior</p>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-400">Tempo de Leitura</span>
                          <span className="text-white font-semibold">4.2min</span>
                        </div>
                        <Progress value={92} className="h-2" />
                        <p className="text-xs text-green-400 mt-1">+15% vs mês anterior</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Artigos Recentes */}
              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <FileText className="w-5 h-5 text-purple-400" />
                      <span>Artigos Recentes</span>
                    </div>
                    <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                      <Plus className="w-4 h-4 mr-2" />
                      Novo Artigo
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { title: 'Análise do mercado de ações em dezembro', views: 1240, likes: 89, status: 'Publicado', date: '2 dias atrás' },
                      { title: 'Estratégias de investimento para 2025', views: 856, likes: 67, status: 'Publicado', date: '5 dias atrás' },
                      { title: 'Bitcoin: perspectivas para o próximo ano', views: 2100, likes: 156, status: 'Publicado', date: '1 semana atrás' },
                    ].map((article, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-gray-700/30 rounded-xl border border-gray-600/30">
                        <div className="flex-1">
                          <h4 className="text-white font-medium mb-1">{article.title}</h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-400">
                            <span>{article.views} visualizações</span>
                            <span>{article.likes} curtidas</span>
                            <span>{article.date}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className="border-green-600 text-green-300">
                            {article.status}
                          </Badge>
                          <Button variant="ghost" size="sm">
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar com Atividades */}
            <div className="space-y-6">
              {/* Atividade Recente */}
              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <Clock className="w-5 h-5 text-green-400" />
                    <span>Atividade Recente</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockActivities.slice(0, 5).map((activity, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <div className={`w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center ${activity.color}`}>
                          {activity.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-white text-sm font-medium">{activity.action}</p>
                          <p className="text-gray-400 text-xs truncate">{activity.title}</p>
                          <p className="text-gray-500 text-xs">{activity.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Metas */}
              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <Target className="w-5 h-5 text-orange-400" />
                    <span>Metas do Mês</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-gray-300">Artigos Publicados</span>
                        <span className="text-white">3/5</span>
                      </div>
                      <Progress value={60} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-gray-300">Novos Seguidores</span>
                        <span className="text-white">156/200</span>
                      </div>
                      <Progress value={78} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-gray-300">Engajamento</span>
                        <span className="text-white">6.8%/8%</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Tab: Perfil */}
        <TabsContent value="profile" className="space-y-6">
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <User className="w-5 h-5" />
                <span>Informações Pessoais</span>
              </CardTitle>
              <CardDescription className="text-gray-400">
                Gerencie suas informações pessoais e como elas aparecem para outros usuários.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isEditing ? (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="first_name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300 font-medium">Nome</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 h-12"
                                placeholder="Seu nome"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="last_name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300 font-medium">Sobrenome</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 h-12"
                                placeholder="Seu sobrenome"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300 font-medium">Email</FormLabel>
                          <FormControl>
                            <Input 
                              {...field} 
                              type="email"
                              className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 h-12"
                              placeholder="seu@email.com"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300 font-medium">Bio</FormLabel>
                          <FormControl>
                            <Textarea 
                              {...field} 
                              className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 min-h-[100px]"
                              placeholder="Conte um pouco sobre você..."
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="website"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300 font-medium">Website</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 h-12"
                                placeholder="https://seusite.com"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300 font-medium">Localização</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 h-12"
                                placeholder="São Paulo, Brasil"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="company"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300 font-medium">Empresa</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 h-12"
                                placeholder="Sua empresa"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="job_title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300 font-medium">Cargo</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                className="bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 h-12"
                                placeholder="Seu cargo"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="flex flex-col sm:flex-row gap-4 pt-4">
                      <Button
                        type="submit"
                        className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white h-12 px-8"
                      >
                        Salvar Alterações
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handleEditToggle}
                        className="border-gray-600 text-gray-300 hover:bg-gray-700 h-12 px-8"
                      >
                        Cancelar
                      </Button>
                    </div>
                  </form>
                </Form>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="bg-gradient-to-r from-blue-500/10 to-blue-600/10 rounded-xl p-4 border border-blue-500/20">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                          <User className="w-4 h-4 text-blue-400 mr-2" />
                          <h4 className="text-white font-medium">Nome Completo</h4>
                        </div>
                        <button
                          onClick={() => copyToClipboard(getFullName(), 'fullname')}
                          className="p-1 hover:bg-gray-700 rounded transition-colors"
                        >
                          {copiedField === 'fullname' ? (
                            <Check className="w-4 h-4 text-green-400" />
                          ) : (
                            <Copy className="w-4 h-4 text-gray-400" />
                          )}
                        </button>
                      </div>
                      <p className="text-gray-300 text-lg">{getFullName()}</p>
                    </div>

                    <div className="bg-gradient-to-r from-green-500/10 to-green-600/10 rounded-xl p-4 border border-green-500/20">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                          <Mail className="w-4 h-4 text-green-400 mr-2" />
                          <h4 className="text-white font-medium">Email</h4>
                        </div>
                        <button
                          onClick={() => copyToClipboard(user.email, 'email')}
                          className="p-1 hover:bg-gray-700 rounded transition-colors"
                        >
                          {copiedField === 'email' ? (
                            <Check className="w-4 h-4 text-green-400" />
                          ) : (
                            <Copy className="w-4 h-4 text-gray-400" />
                          )}
                        </button>
                      </div>
                      <p className="text-gray-300">{user.email}</p>
                    </div>

                    <div className="bg-gradient-to-r from-red-500/10 to-red-600/10 rounded-xl p-4 border border-red-500/20">
                      <div className="flex items-center mb-2">
                        <MapPin className="w-4 h-4 text-red-400 mr-2" />
                        <h4 className="text-white font-medium">Localização</h4>
                      </div>
                      <p className="text-gray-300">São Paulo, Brasil</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 rounded-xl p-4 border border-purple-500/20">
                      <div className="flex items-center mb-2">
                        <Calendar className="w-4 h-4 text-purple-400 mr-2" />
                        <h4 className="text-white font-medium">Membro desde</h4>
                      </div>
                      <p className="text-gray-300">
                        {new Date(user.registered_date).toLocaleDateString('pt-BR', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                    </div>

                    <div className="bg-gradient-to-r from-yellow-500/10 to-yellow-600/10 rounded-xl p-4 border border-yellow-500/20">
                      <div className="flex items-center mb-2">
                        <Shield className="w-4 h-4 text-yellow-400 mr-2" />
                        <h4 className="text-white font-medium">Tipo de Conta</h4>
                      </div>
                      {getRoleDisplay(user.roles)}
                    </div>

                    <div className="bg-gradient-to-r from-orange-500/10 to-orange-600/10 rounded-xl p-4 border border-orange-500/20">
                      <div className="flex items-center mb-2">
                        <Briefcase className="w-4 h-4 text-orange-400 mr-2" />
                        <h4 className="text-white font-medium">Profissão</h4>
                      </div>
                      <p className="text-gray-300">Analista Financeiro</p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab: Comentários */}
        <TabsContent value="comments" className="space-y-6">
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <MessageSquare className="w-5 h-5" />
                <span>Meus Comentários</span>
                <Badge className="bg-orange-600 text-white">
                  {userComments.length}
                </Badge>
              </CardTitle>
              <CardDescription className="text-gray-400">
                Todos os comentários que você fez em publicações.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {userComments.length === 0 ? (
                <div className="text-center py-12">
                  <MessageSquare className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-300 mb-2">Nenhum comentário ainda</h3>
                  <p className="text-gray-400 mb-6">Você ainda não fez nenhum comentário em publicações.</p>
                  <Button
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <Search className="w-4 h-4 mr-2" />
                    Explorar Artigos
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {userComments.map((comment) => (
                    <div
                      key={comment.id}
                      className="bg-gray-700/50 rounded-xl p-4 border border-gray-600/50 hover:border-gray-500/50 transition-all duration-300"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h4 className="font-semibold text-white mb-1 hover:text-blue-400 cursor-pointer">
                            {comment.post_title}
                          </h4>
                          <div className="flex items-center space-x-3 text-sm text-gray-400">
                            <span>{new Date(comment.date).toLocaleDateString('pt-BR')}</span>
                            <Badge 
                              className={`text-xs ${
                                comment.status === 'approved' 
                                  ? 'bg-green-600 text-white' 
                                  : comment.status === 'pending'
                                  ? 'bg-yellow-600 text-white'
                                  : 'bg-red-600 text-white'
                              }`}
                            >
                              {comment.status === 'approved' ? 'Aprovado' : 
                               comment.status === 'pending' ? 'Pendente' : 'Spam'}
                            </Badge>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeUserComment(comment.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-600/20"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="text-gray-300 text-sm leading-relaxed mb-3">
                        {comment.content.length > 200 
                          ? `${comment.content.substring(0, 200)}...` 
                          : comment.content}
                      </div>
                      <div className="flex items-center space-x-3">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-blue-400 hover:text-blue-300 hover:bg-blue-600/20"
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Ver Publicação
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-400 hover:text-gray-300 hover:bg-gray-600/20"
                        >
                          <Edit className="w-4 h-4 mr-2" />
                          Editar
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab: Salvos */}
        <TabsContent value="saved" className="space-y-6">
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Bookmark className="w-5 h-5" />
                <span>Publicações Salvas</span>
                <Badge className="bg-pink-600 text-white">
                  {savedPosts.length}
                </Badge>
              </CardTitle>
              <CardDescription className="text-gray-400">
                Todas as publicações que você salvou para ler mais tarde.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {savedPosts.length === 0 ? (
                <div className="text-center py-12">
                  <Bookmark className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-300 mb-2">Nenhuma publicação salva</h3>
                  <p className="text-gray-400 mb-6">Você ainda não salvou nenhuma publicação. Comece explorando nossos artigos!</p>
                  <Button
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <Search className="w-4 h-4 mr-2" />
                    Explorar Artigos
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {savedPosts.map((post) => (
                    <div
                      key={post.id}
                      className="bg-gray-700/50 rounded-xl overflow-hidden border border-gray-600/50 hover:border-gray-500/50 transition-all duration-300 group"
                    >
                      {post.featured_media_url && (
                        <div className="aspect-video overflow-hidden">
                          <img
                            src={post.featured_media_url}
                            alt={post.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      )}
                      <div className="p-4">
                        <h4 className="font-semibold text-white mb-2 line-clamp-2 hover:text-blue-400 cursor-pointer">
                          {post.title}
                        </h4>
                        <p className="text-gray-400 text-sm mb-3 line-clamp-2">
                          {post.excerpt.replace(/<[^>]*>/g, '')}
                        </p>
                        <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                          <span>Salvo em {new Date(post.savedAt).toLocaleDateString('pt-BR')}</span>
                          <span>Publicado em {new Date(post.date).toLocaleDateString('pt-BR')}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-blue-400 hover:text-blue-300 hover:bg-blue-600/20 flex-1"
                          >
                            <ExternalLink className="w-4 h-4 mr-2" />
                            Ler Artigo
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => unsavePost(post.id)}
                            className="text-red-400 hover:text-red-300 hover:bg-red-600/20"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab: Atividade */}
        <TabsContent value="activity" className="space-y-6">
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-green-400" />
                  <span>Histórico de Atividades</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                    <Filter className="w-4 h-4 mr-2" />
                    Filtrar
                  </Button>
                  <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockActivities.map((activity, index) => (
                  <div key={index} className="flex items-center space-x-4 p-4 bg-gray-700/30 rounded-xl border border-gray-600/30 hover:bg-gray-700/50 transition-colors">
                    <div className={`w-12 h-12 rounded-full bg-gray-700 flex items-center justify-center ${activity.color}`}>
                      {activity.icon}
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-medium">{activity.action}</p>
                      <p className="text-gray-400 text-sm">{activity.title}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-gray-500 text-xs">{activity.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab: Conquistas */}
        <TabsContent value="achievements" className="space-y-6">
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Award className="w-5 h-5 text-yellow-400" />
                <span>Conquistas e Badges</span>
              </CardTitle>
              <CardDescription className="text-gray-400">
                Acompanhe seu progresso e desbloqueie novas conquistas.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {mockAchievements.map((achievement, index) => (
                  <div 
                    key={index} 
                    className={`p-6 rounded-2xl border transition-all duration-300 hover:scale-105 ${
                      achievement.earned 
                        ? 'bg-gradient-to-br from-yellow-500/20 to-yellow-600/20 border-yellow-500/30 shadow-lg shadow-yellow-500/10' 
                        : 'bg-gray-700/30 border-gray-600/30'
                    }`}
                  >
                    <div className="text-center space-y-4">
                      <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center ${
                        achievement.earned 
                          ? 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-white' 
                          : 'bg-gray-600 text-gray-400'
                      }`}>
                        {achievement.icon}
                      </div>
                      <div>
                        <h3 className={`font-bold text-lg ${achievement.earned ? 'text-white' : 'text-gray-400'}`}>
                          {achievement.title}
                        </h3>
                        <p className={`text-sm ${achievement.earned ? 'text-gray-300' : 'text-gray-500'}`}>
                          {achievement.description}
                        </p>
                      </div>
                      {achievement.earned ? (
                        <Badge className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white border-0">
                          Conquistado em {achievement.date}
                        </Badge>
                      ) : (
                        <div className="space-y-2">
                          <Progress value={(achievement.progress! / (achievement.title === 'Especialista' ? 50 : 500)) * 100} className="h-2" />
                          <p className="text-xs text-gray-400">
                            {achievement.progress}/{achievement.title === 'Especialista' ? '50' : '500'}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab: Configurações */}
        <TabsContent value="settings" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Segurança */}
            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Lock className="w-5 h-5" />
                  <span>Segurança</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h4 className="text-white font-medium">Alterar Senha</h4>
                  <div className="space-y-3">
                    <div>
                      <label className="text-sm text-gray-400">Senha Atual</label>
                      <div className="relative">
                        <Input
                          type={showPassword ? 'text' : 'password'}
                          className="bg-gray-700/50 border-gray-600 text-white pr-10"
                          placeholder="Senha atual"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                    <div>
                      <label className="text-sm text-gray-400">Nova Senha</label>
                      <Input
                        type="password"
                        className="bg-gray-700/50 border-gray-600 text-white"
                        placeholder="Nova senha"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-gray-400">Confirmar Nova Senha</label>
                      <Input
                        type="password"
                        className="bg-gray-700/50 border-gray-600 text-white"
                        placeholder="Confirmar nova senha"
                      />
                    </div>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700">
                      Alterar Senha
                    </Button>
                  </div>
                </div>

                <Separator className="bg-gray-700" />

                <div className="space-y-4">
                  <h4 className="text-white font-medium">Autenticação de Dois Fatores</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">2FA via SMS</span>
                      <Switch />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">2FA via App</span>
                      <Switch />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">2FA via Email</span>
                      <Switch checked />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Preferências */}
            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Settings className="w-5 h-5" />
                  <span>Preferências</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h4 className="text-white font-medium flex items-center space-x-2">
                    <Bell className="w-4 h-4" />
                    <span>Notificações</span>
                  </h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Notificações por Email</span>
                      <Switch 
                        checked={notifications.email}
                        onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, email: checked }))}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Notificações Push</span>
                      <Switch 
                        checked={notifications.push}
                        onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, push: checked }))}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Marketing</span>
                      <Switch 
                        checked={notifications.marketing}
                        onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, marketing: checked }))}
                      />
                    </div>
                  </div>
                </div>

                <Separator className="bg-gray-700" />

                <div className="space-y-4">
                  <h4 className="text-white font-medium flex items-center space-x-2">
                    <Palette className="w-4 h-4" />
                    <span>Aparência</span>
                  </h4>
                  <div className="space-y-3">
                    <div>
                      <label className="text-sm text-gray-400 mb-2 block">Tema</label>
                      <Select value={theme} onValueChange={setTheme}>
                        <SelectTrigger className="bg-gray-700/50 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-800 border-gray-700">
                          <SelectItem value="dark">Escuro</SelectItem>
                          <SelectItem value="light">Claro</SelectItem>
                          <SelectItem value="auto">Automático</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm text-gray-400 mb-2 block">Idioma</label>
                      <Select defaultValue="pt-BR">
                        <SelectTrigger className="bg-gray-700/50 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-800 border-gray-700">
                          <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                          <SelectItem value="en-US">English (US)</SelectItem>
                          <SelectItem value="es-ES">Español</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Ações da Conta */}
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-white">Ações da Conta</CardTitle>
              <CardDescription className="text-gray-400">
                Gerencie sua conta e dados.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={handleLogout}
                  variant="destructive"
                  className="bg-red-600 hover:bg-red-700 h-12 px-6"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sair da Conta
                </Button>
                <Button
                  variant="outline"
                  className="border-gray-600 text-gray-300 hover:bg-gray-700 h-12 px-6"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Exportar Dados
                </Button>
                <Button
                  variant="outline"
                  className="border-red-600 text-red-300 hover:bg-red-700 h-12 px-6"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Excluir Conta
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UserProfilePanel;

