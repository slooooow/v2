
import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, User, ArrowRight, MessageCircle } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { WordPressPost } from '../types/wordpress';
import { formatRelativeDate, stripHtml, truncateText, getImageUrl, getAuthorName, getCategoryFromPost } from '../utils/formatting';
import { getCategoryColor, getCategoryName } from '../utils/categories';
import { wordpressApi } from '../services/wordpress';

interface PostCardProps {
  post: WordPressPost;
  size?: 'small' | 'medium' | 'large';
  layout?: 'vertical' | 'horizontal';
}

const PostCard: React.FC<PostCardProps> = ({ post, size = 'medium', layout = 'vertical' }) => {
  const categorySlug = getCategoryFromPost(post);
  const categoryColor = getCategoryColor(categorySlug);
  const categoryName = getCategoryName(categorySlug);
  const imageUrl = getImageUrl(post);
  const authorName = getAuthorName(post);
  const excerpt = stripHtml(post.excerpt.rendered);

  // Buscar contagem de comentários
  const { data: commentsCount = 0 } = useQuery({
    queryKey: ['commentsCount', post.id],
    queryFn: () => wordpressApi.getCommentsCount(post.id),
  });

  const sizeClasses = {
    small: 'h-48',
    medium: 'h-64',
    large: 'h-80'
  };

  if (layout === 'horizontal') {
    return (
      <Link to={`/post/${post.slug}`} className="block group">
        <article className="relative rounded-3xl bg-gray-800/30 backdrop-blur-sm border border-gray-700/30 overflow-hidden transition-all duration-700 hover:shadow-2xl hover:shadow-blue-500/20">
          <div className="flex h-64 relative z-10">
            {/* Enhanced image section */}
            <div className="relative w-2/5 overflow-hidden group/image">
              <img
                src={imageUrl}
                alt={stripHtml(post.title.rendered)}
                className="w-full h-full object-cover transition-all duration-700"
                onError={(e) => {
                  e.currentTarget.src = '/placeholder.svg';
                }}
              />
              
              {/* Image glow effect with category color */}
              <div 
                className="absolute inset-0 opacity-0 group-hover/image:opacity-30 transition-opacity duration-500"
                style={{
                  background: `radial-gradient(circle at center, ${categoryColor}, transparent 70%)`,
                  filter: 'blur(20px)'
                }}
              />
              
              {/* Category badge */}
              <div className="absolute top-4 left-4">
                <span
                  className="px-3 py-2 text-xs font-bold text-white rounded-full backdrop-blur-md border border-white/20 shadow-lg"
                  style={{ 
                    background: `linear-gradient(135deg, ${categoryColor}, ${categoryColor}cc)`,
                    boxShadow: `0 4px 15px ${categoryColor}40`
                  }}
                >
                  {categoryName}
                </span>
              </div>
            </div>

            {/* Content section with transparent blur on hover */}
            <div className="flex-1 p-6 flex flex-col justify-between transition-all duration-300 group-hover:bg-black/20 group-hover:backdrop-blur-md">
              <div>
                <h2 className="text-xl font-bold text-white mb-3 line-clamp-2 transition-colors duration-300 relative">
                  {stripHtml(post.title.rendered)}
                  {/* Linha horizontal de destaque */}
                  <div 
                    className="absolute -bottom-2 left-0 h-0.5 w-0 group-hover:w-full transition-all duration-500"
                    style={{ backgroundColor: categoryColor }}
                  />
                </h2>
                
                <p className="text-gray-400 text-sm mb-4 line-clamp-3 leading-relaxed">
                  {truncateText(excerpt, 120)}
                </p>
              </div>

              {/* Enhanced meta section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-xs text-gray-500">
                    <div className="flex items-center space-x-1">
                      <User className="w-3 h-3" />
                      <span>{authorName}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-3 h-3" />
                      <span>{formatRelativeDate(post.date)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <MessageCircle className="w-3 h-3" />
                      <span>{commentsCount}</span>
                    </div>
                  </div>
                  
                  <ArrowRight className="w-5 h-5 text-blue-400 transform group-hover:translate-x-2 transition-transform duration-300" />
                </div>

                {/* Category color indicator */}
                <div className="flex items-center justify-end">
                  <div 
                    className="w-3 h-3 rounded-full animate-pulse"
                    style={{ backgroundColor: categoryColor }}
                  />
                </div>
              </div>
            </div>
          </div>
        </article>
      </Link>
    );
  }

  return (
    <Link to={`/post/${post.slug}`} className="block group">
      <article className="relative rounded-3xl bg-gray-800/30 backdrop-blur-sm border border-gray-700/30 overflow-hidden transition-all duration-700 hover:shadow-2xl">
        {/* Background glow effect on hover - spanning entire card */}
        <div 
          className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-3xl pointer-events-none"
          style={{
            background: `radial-gradient(circle at center, ${categoryColor}, transparent 60%)`,
            filter: 'blur(30px)'
          }}
        />

        {/* Enhanced image section */}
        <div className={`relative ${sizeClasses[size]} overflow-hidden group/image`}>
          <img
            src={imageUrl}
            alt={stripHtml(post.title.rendered)}
            className="w-full h-full object-cover transition-all duration-700"
            onError={(e) => {
              e.currentTarget.src = '/placeholder.svg';
            }}
          />
          
          {/* Multi-layer gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
          
          {/* Category badge with enhanced styling */}
          <div className="absolute top-4 left-4">
            <span
              className="px-3 py-2 text-xs font-bold text-white rounded-full backdrop-blur-md border border-white/20 shadow-lg transition-all duration-300"
              style={{ 
                background: `linear-gradient(135deg, ${categoryColor}, ${categoryColor}cc)`,
                boxShadow: `0 4px 15px ${categoryColor}40`
              }}
            >
              {categoryName}
            </span>
          </div>

          {/* Enhanced meta info overlay */}
          <div className="absolute bottom-4 right-4">
            <div className="flex items-center space-x-2 text-white/90 text-xs glass rounded-full px-3 py-2 backdrop-blur-md">
              <Calendar className="w-3 h-3" />
              <span>{formatRelativeDate(post.date)}</span>
            </div>
          </div>

          {/* Comments count indicator */}
          <div className="absolute bottom-4 left-4">
            <div className="flex items-center space-x-1 text-white/90 text-xs glass rounded-full px-3 py-2 backdrop-blur-md">
              <MessageCircle className="w-3 h-3" />
              <span>{commentsCount}</span>
            </div>
          </div>
        </div>

        {/* Content section with transparent blur on hover */}
        <div className="p-6 relative z-10 transition-all duration-300 group-hover:bg-black/20 group-hover:backdrop-blur-md">
          <h2 className="text-lg font-bold text-white mb-3 line-clamp-2 transition-colors duration-300 relative">
            {stripHtml(post.title.rendered)}
            {/* Linha horizontal de destaque */}
            <div 
              className="absolute -bottom-2 left-0 h-0.5 w-0 group-hover:w-full transition-all duration-500"
              style={{ backgroundColor: categoryColor }}
            />
          </h2>
          
          <p className="text-gray-400 text-sm mb-4 line-clamp-3 leading-relaxed">
            {truncateText(excerpt, 120)}
          </p>

          {/* Enhanced meta section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-xs text-gray-500">
                <div className="flex items-center space-x-1">
                  <User className="w-3 h-3" />
                  <span>{authorName}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <MessageCircle className="w-3 h-3" />
                  <span>{commentsCount} comentários</span>
                </div>
              </div>
              
              <div 
                className="w-3 h-3 rounded-full animate-pulse"
                style={{ backgroundColor: categoryColor }}
              />
            </div>

            {/* Read more arrow */}
            <div className="flex items-center justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <ArrowRight className="w-4 h-4 text-blue-400 transform group-hover:translate-x-1 transition-transform duration-300" />
            </div>
          </div>
        </div>
      </article>
    </Link>
  );
};

export default PostCard;
