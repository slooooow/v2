
import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { wordpressApi } from '../services/wordpress';
import { toast } from '@/hooks/use-toast';
import { 
  User, 
  Mail, 
  Calendar, 
  Shield, 
  Star, 
  Settings, 
  Lock,
  Bell,
  Globe,
  Save,
  X
} from 'lucide-react';
import PasswordChangeModal from './PasswordChangeModal';

const profileSchema = z.object({
  first_name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  last_name: z.string().min(2, 'Sobrenome deve ter pelo menos 2 caracteres'),
  email: z.string().email('Email inválido'),
});

const UserAccountCards: React.FC = () => {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);

  const form = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      first_name: user?.first_name || '',
      last_name: user?.last_name || '',
      email: user?.email || '',
    },
  });

  const onSubmit = async (data: z.infer<typeof profileSchema>) => {
    if (!user) return;

    try {
      await wordpressApi.updateUserProfile(user.id, data);
      setIsEditing(false);
      toast({
        title: "Perfil atualizado!",
        description: "Suas informações foram atualizadas com sucesso.",
      });
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar perfil",
        description: error.response?.data?.message || "Erro ao atualizar perfil",
        variant: "destructive",
      });
    }
  };

  const getRoleInfo = (roles: string[]) => {
    const roleMap: Record<string, { label: string; icon: React.ReactNode; color: string; bg: string }> = {
      administrator: { 
        label: 'Administrador', 
        icon: <Shield className="w-5 h-5" />, 
        color: 'text-red-400',
        bg: 'bg-red-500/10 border-red-500/20'
      },
      editor: { 
        label: 'Editor', 
        icon: <Star className="w-5 h-5" />, 
        color: 'text-purple-400',
        bg: 'bg-purple-500/10 border-purple-500/20'
      },
      author: { 
        label: 'Autor', 
        icon: <User className="w-5 h-5" />, 
        color: 'text-blue-400',
        bg: 'bg-blue-500/10 border-blue-500/20'
      },
      subscriber: { 
        label: 'Assinante', 
        icon: <User className="w-5 h-5" />, 
        color: 'text-green-400',
        bg: 'bg-green-500/10 border-green-500/20'
      },
    };
    
    const role = roles?.[0] || 'subscriber';
    return roleMap[role] || roleMap.subscriber;
  };

  if (!user) return null;

  const roleInfo = getRoleInfo(user.roles);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Personal Information Card */}
        <Card className="lg:col-span-2 bg-gray-800/90 backdrop-blur-sm border-gray-700/50 shadow-xl">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2 text-white">
                <User className="w-5 h-5 text-blue-400" />
                <span>Informações Pessoais</span>
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="text-gray-400 text-sm">Nome Completo</label>
                  <p className="text-white font-medium">{user.first_name} {user.last_name}</p>
                </div>
                <div>
                  <label className="text-gray-400 text-sm">Email</label>
                  <p className="text-white font-medium">{user.email}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-gray-400 text-sm">Nome de Usuário</label>
                  <p className="text-white font-medium">@{user.username}</p>
                </div>
                <div>
                  <label className="text-gray-400 text-sm">Data de Registro</label>
                  <p className="text-white font-medium">
                    {new Date(user.registered_date).toLocaleDateString('pt-BR')}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Account Type Card */}
        <Card className="bg-gray-800/90 backdrop-blur-sm border-gray-700/50 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white">
              <Shield className="w-5 h-5 text-blue-400" />
              <span>Tipo de Conta</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`flex items-center space-x-3 p-4 rounded-lg border ${roleInfo.bg}`}>
              <div className={roleInfo.color}>
                {roleInfo.icon}
              </div>
              <div>
                <p className={`font-semibold ${roleInfo.color}`}>
                  {roleInfo.label}
                </p>
                <p className="text-gray-400 text-sm">
                  Nível de acesso atual
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security Card */}
        <Card className="bg-gray-800/90 backdrop-blur-sm border-gray-700/50 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white">
              <Lock className="w-5 h-5 text-blue-400" />
              <span>Segurança</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Senha</span>
              <PasswordChangeModal>
                <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                  Alterar
                </Button>
              </PasswordChangeModal>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Autenticação 2FA</span>
              <span className="text-yellow-400 text-sm">Desativada</span>
            </div>
          </CardContent>
        </Card>

        {/* Preferences Card */}
        <Card className="lg:col-span-2 bg-gray-800/90 backdrop-blur-sm border-gray-700/50 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white">
              <Settings className="w-5 h-5 text-blue-400" />
              <span>Preferências</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Bell className="w-4 h-4 text-gray-400" />
                <span className="text-gray-300">Notificações</span>
              </div>
              <span className="text-green-400 text-sm">Ativadas</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Globe className="w-4 h-4 text-gray-400" />
                <span className="text-gray-300">Idioma</span>
              </div>
              <span className="text-gray-400 text-sm">Português</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default UserAccountCards;
