
import React, { useState } from 'react';
import { Bell, Crown, CreditCard, Settings, Shield, Mail, Globe, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { toast } from '@/hooks/use-toast';

const UserProfileSettings: React.FC = () => {
  const [pushNotifications, setPushNotifications] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [showPlansModal, setShowPlansModal] = useState(false);

  const handleNotificationChange = (type: 'push' | 'email', enabled: boolean) => {
    if (type === 'push') {
      setPushNotifications(enabled);
      if (enabled) {
        // Request notification permission
        if ('Notification' in window) {
          Notification.requestPermission().then((permission) => {
            if (permission === 'granted') {
              toast({
                title: "Notificações ativadas!",
                description: "Você receberá notificações push das principais notícias.",
              });
            } else {
              setPushNotifications(false);
              toast({
                title: "Permissão negada",
                description: "Habilite as notificações nas configurações do navegador.",
                variant: "destructive"
              });
            }
          });
        }
      } else {
        toast({
          title: "Notificações desativadas",
          description: "Você não receberá mais notificações push.",
        });
      }
    } else {
      setEmailNotifications(enabled);
      toast({
        title: enabled ? "Email ativado" : "Email desativado",
        description: enabled ? "Você receberá newsletters por email." : "Emails de newsletter foram desabilitados.",
      });
    }
  };

  const PlansModal = () => (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-800 rounded-2xl max-w-md w-full p-6 relative">
        <button
          onClick={() => setShowPlansModal(false)}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X className="w-6 h-6" />
        </button>
        
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Crown className="w-8 h-8 text-white" />
          </div>
          
          <h3 className="text-2xl font-bold text-white mb-3">Em breve mais planos</h3>
          <p className="text-gray-300 mb-6">
            Estamos preparando planos exclusivos com benefícios especiais para nossos leitores mais dedicados.
          </p>
          
          <div className="space-y-3 text-left mb-6">
            <div className="flex items-center space-x-3 text-gray-300">
              <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
              <span>Acesso antecipado às notícias</span>
            </div>
            <div className="flex items-center space-x-3 text-gray-300">
              <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
              <span>Análises exclusivas de mercado</span>
            </div>
            <div className="flex items-center space-x-3 text-gray-300">
              <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
              <span>Newsletter personalizada</span>
            </div>
            <div className="flex items-center space-x-3 text-gray-300">
              <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
              <span>Sem anúncios</span>
            </div>
          </div>
          
          <Button
            onClick={() => setShowPlansModal(false)}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            Entendi
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Access Level Card */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">Nível de acesso atual</h3>
              <p className="text-gray-400 text-sm">Plano Gratuito</p>
            </div>
          </div>
          <div className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-sm font-medium">
            Ativo
          </div>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-300 text-sm">Artigos lidos este mês</span>
            <span className="text-white font-semibold">12/50</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full" style={{ width: '24%' }}></div>
          </div>
        </div>
        
        <Button
          onClick={() => setShowPlansModal(true)}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold"
        >
          <Crown className="w-4 h-4 mr-2" />
          Mudar Assinatura
        </Button>
      </div>

      {/* Notifications Settings */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-6 border border-gray-700">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-blue-600 rounded-xl flex items-center justify-center">
            <Bell className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Notificações</h3>
            <p className="text-gray-400 text-sm">Configure como quer receber as notícias</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-700/30 rounded-xl">
            <div className="flex items-center space-x-3">
              <Bell className="w-5 h-5 text-blue-400" />
              <div>
                <p className="text-white font-medium">Notificações Push</p>
                <p className="text-gray-400 text-sm">Receba alertas direto no navegador</p>
              </div>
            </div>
            <Switch
              checked={pushNotifications}
              onCheckedChange={(checked) => handleNotificationChange('push', checked)}
            />
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-700/30 rounded-xl">
            <div className="flex items-center space-x-3">
              <Mail className="w-5 h-5 text-green-400" />
              <div>
                <p className="text-white font-medium">Newsletter por Email</p>
                <p className="text-gray-400 text-sm">Resumo semanal das principais notícias</p>
              </div>
            </div>
            <Switch
              checked={emailNotifications}
              onCheckedChange={(checked) => handleNotificationChange('email', checked)}
            />
          </div>
        </div>
      </div>

      {/* Preferences */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-6 border border-gray-700">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl flex items-center justify-center">
            <Settings className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Preferências</h3>
            <p className="text-gray-400 text-sm">Personalize sua experiência</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 bg-gray-700/30 rounded-xl text-center">
            <Globe className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <p className="text-white font-medium mb-1">Idioma</p>
            <p className="text-gray-400 text-sm">Português (BR)</p>
          </div>
          
          <div className="p-4 bg-gray-700/30 rounded-xl text-center">
            <CreditCard className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <p className="text-white font-medium mb-1">Moeda</p>
            <p className="text-gray-400 text-sm">Real (BRL)</p>
          </div>
        </div>
      </div>

      {showPlansModal && <PlansModal />}
    </div>
  );
};

export default UserProfileSettings;
