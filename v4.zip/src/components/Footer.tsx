
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, Youtube } from 'lucide-react';
import { CATEGORY_CONFIGS } from '../utils/categories';

const Footer = () => {
  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Youtube, href: '#', label: 'YouTube' },
  ];

  return (
    <footer className="border-t border-white/10" style={{ backgroundColor: '#1a1f29' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo e Descrição */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 flex items-center justify-center">
                <img 
                  src="/lovable-uploads/d5f08bad-4a22-451b-8cd0-d2cbce38848c.png" 
                  alt="Finver Finance Logo" 
                  className="w-8 h-8 object-contain"
                />
              </div>
              <span className="text-xl font-bold text-white">Finver Finance</span>
            </Link>
            <p className="text-sm text-gray-400 leading-relaxed">
              Portal de notícias sobre mercado financeiro, oferecendo análises especializadas 
              em ações, FIIs, tecnologia e criptomoedas para investidores inteligentes.
            </p>
          </div>

          {/* Navegação */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Navegação</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/"
                  className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200"
                >
                  Home
                </Link>
              </li>
              {CATEGORY_CONFIGS.map((category) => (
                <li key={category.slug}>
                  <Link
                    to={`/categoria/${category.slug}`}
                    className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Links Institucionais */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Institucional</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="#"
                  className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200"
                >
                  Sobre Nós
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200"
                >
                  Contato
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200"
                >
                  Política de Privacidade
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200"
                >
                  Termos de Uso
                </a>
              </li>
            </ul>
          </div>

          {/* Redes Sociais */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Siga-nos</h3>
            <div className="flex space-x-3">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-all duration-200 group"
                >
                  <social.icon size={18} className="group-hover:scale-110 transition-transform duration-200" />
                </a>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-4">
              Fique por dentro das últimas novidades do mercado financeiro
            </p>
          </div>
        </div>

        {/* Divisória */}
        <div className="border-t border-white/10 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-gray-400">
              © 2024 Finver Finance. Todos os direitos reservados.
            </p>
            <div className="flex space-x-6">
              <a
                href="#"
                className="text-xs text-gray-500 hover:text-gray-400 transition-colors duration-200"
              >
                Política de Cookies
              </a>
              <a
                href="#"
                className="text-xs text-gray-500 hover:text-gray-400 transition-colors duration-200"
              >
                Disclaimer
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
