
import React, { useState, useRef, useEffect } from 'react';
import { Search, X, TrendingUp, Clock } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { wordpressApi } from '../services/wordpress';
import { stripHtml, formatRelativeDate, getCategoryFromPost, getCategoryColor } from '../utils/formatting';

const SearchBar: React.FC = () => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerms, setSearchTerms] = useState<string[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);

  const { data: searchResults = [], isLoading } = useQuery({
    queryKey: ['search', query],
    queryFn: async () => {
      if (query.length < 2) return [];
      
      // Busca posts que contenham o termo no título ou conteúdo
      const posts = await wordpressApi.getPosts({ 
        per_page: 8, 
        _embed: true,
        search: query
      });
      
      return posts;
    },
    enabled: query.length >= 2,
  });

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    setIsOpen(value.length > 0);
    
    // Adiciona termos de busca ao histórico
    if (value.length >= 2 && !searchTerms.includes(value)) {
      setSearchTerms(prev => [value, ...prev.slice(0, 4)]);
    }
  };

  const clearSearch = () => {
    setQuery('');
    setIsOpen(false);
  };

  const handleResultClick = () => {
    setIsOpen(false);
    setQuery('');
  };

  const handleTermClick = (term: string) => {
    setQuery(term);
    setIsOpen(true);
  };

  const highlightMatch = (text: string, query: string) => {
    if (!query) return text;
    const regex = new RegExp(`(${query})`, 'gi');
    return text.replace(regex, '<mark class="bg-yellow-300 text-gray-900 px-1 rounded">$1</mark>');
  };

  return (
    <div ref={searchRef} className="relative w-full max-w-md">
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={query}
          onChange={handleInputChange}
          placeholder="Buscar notícias..."
          className="w-full pl-12 pr-12 py-3 bg-gradient-to-r from-gray-900/80 to-gray-800/80 backdrop-blur-xl border border-gray-700/50 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
        />
        {query && (
          <button
            onClick={clearSearch}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors duration-200"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Dropdown de resultados */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-3 bg-gradient-to-br from-gray-900/95 to-gray-800/95 backdrop-blur-xl border border-gray-700/50 rounded-2xl shadow-2xl z-50 max-h-96 overflow-y-auto">
          {/* Termos de busca recentes */}
          {query.length < 2 && searchTerms.length > 0 && (
            <div className="p-4 border-b border-gray-700/50">
              <h4 className="text-gray-400 text-xs font-medium mb-3 uppercase tracking-wider">Buscas Recentes</h4>
              <div className="flex flex-wrap gap-2">
                {searchTerms.slice(0, 3).map((term, index) => (
                  <button
                    key={index}
                    onClick={() => handleTermClick(term)}
                    className="px-3 py-1 bg-gray-700/50 hover:bg-gray-600/50 text-gray-300 text-sm rounded-full transition-colors duration-200"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Loading state */}
          {isLoading && query.length >= 2 && (
            <div className="p-6 text-center">
              <div className="animate-spin w-6 h-6 border-2 border-blue-500/30 border-t-blue-500 rounded-full mx-auto mb-2" />
              <span className="text-gray-400 text-sm">Buscando...</span>
            </div>
          )}

          {/* Resultados da busca */}
          {!isLoading && query.length >= 2 && (
            <>
              {searchResults.length > 0 ? (
                <div className="py-2">
                  <div className="px-4 py-2 border-b border-gray-700/30">
                    <span className="text-gray-400 text-xs font-medium uppercase tracking-wider">
                      {searchResults.length} resultado{searchResults.length !== 1 ? 's' : ''} encontrado{searchResults.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  
                  {searchResults.map((post) => {
                    const categorySlug = getCategoryFromPost(post);
                    const categoryColor = getCategoryColor(categorySlug);
                    
                    return (
                      <a
                        key={post.id}
                        href={`/post/${post.slug}`}
                        onClick={handleResultClick}
                        className="flex items-start p-4 hover:bg-white/5 transition-all duration-200 group border-b border-gray-800/50 last:border-b-0"
                      >
                        <div className="flex-shrink-0 w-12 h-12 rounded-lg overflow-hidden mr-4">
                          <img
                            src={post._embedded?.['wp:featuredmedia']?.[0]?.source_url || '/placeholder.svg'}
                            alt=""
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                            onError={(e) => {
                              e.currentTarget.src = '/placeholder.svg';
                            }}
                          />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-2">
                            <div 
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: categoryColor }}
                            />
                            <span className="text-xs text-gray-500">
                              {formatRelativeDate(post.date)}
                            </span>
                          </div>
                          
                          <h4 
                            className="text-white text-sm font-medium line-clamp-2 group-hover:text-blue-300 transition-colors duration-200 mb-2"
                            dangerouslySetInnerHTML={{
                              __html: highlightMatch(stripHtml(post.title.rendered), query)
                            }}
                          />
                          
                          <p 
                            className="text-gray-400 text-xs line-clamp-2"
                            dangerouslySetInnerHTML={{
                              __html: highlightMatch(stripHtml(post.excerpt.rendered), query)
                            }}
                          />
                        </div>
                        
                        <TrendingUp className="w-4 h-4 text-blue-400 flex-shrink-0 ml-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                      </a>
                    );
                  })}
                  
                  {/* Ver todos os resultados */}
                  <div className="p-4 border-t border-gray-700/30">
                    <button 
                      onClick={handleResultClick}
                      className="w-full text-center text-blue-400 hover:text-blue-300 text-sm font-medium transition-colors duration-200"
                    >
                      Ver todos os resultados para "{query}"
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-6 text-center">
                  <div className="text-gray-400 text-sm mb-4">
                    Nenhum resultado encontrado para "<span className="text-white font-medium">{query}</span>"
                  </div>
                  <div className="text-xs text-gray-500">
                    Tente usar palavras-chave diferentes ou menos específicas
                  </div>
                </div>
              )}
            </>
          )}

          {/* Sugestões quando não há query */}
          {query.length === 0 && (
            <div className="p-4">
              <h4 className="text-gray-400 text-xs font-medium mb-3 uppercase tracking-wider">Tópicos em Alta</h4>
              <div className="space-y-2">
                {['mercado financeiro', 'criptomoedas', 'investimentos', 'economia'].map((topic, index) => (
                  <button
                    key={index}
                    onClick={() => handleTermClick(topic)}
                    className="flex items-center w-full text-left px-3 py-2 hover:bg-gray-700/30 rounded-lg transition-colors duration-200 group"
                  >
                    <TrendingUp className="w-4 h-4 text-gray-500 mr-3 group-hover:text-blue-400 transition-colors duration-200" />
                    <span className="text-gray-300 text-sm group-hover:text-white transition-colors duration-200">{topic}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchBar;
