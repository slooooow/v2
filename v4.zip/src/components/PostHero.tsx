import React from 'react';
import { Link } from 'react-router-dom';
import { Post } from '../types/wordpress';
import { CategoryConfig } from '../types/wordpress';
import { stripHtml, getImageUrl } from '../utils/formatting';
import PostMeta from './PostMeta';

interface PostHeroProps {
  post: Post;
  categoryConfig: CategoryConfig | null;
  imageUrl: string;
}

const PostHero: React.FC<PostHeroProps> = ({ post, categoryConfig, imageUrl }) => {
  return (
    <div 
      className="relative overflow-hidden"
      style={{ 
        height: '60vh',
        minHeight: '400px',
        marginTop: '80px' // Ajustado para corresponder à altura do navbar (h-20 = 80px)
      }}
    >
      <div className="absolute inset-0">
        <img
          src={imageUrl}
          alt={stripHtml(post.title.rendered)}
          className="w-full h-full object-cover"
          onError={(e) => {
            e.currentTarget.src = '/placeholder.svg';
          }}
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0d1117] via-[#0d1117]/70 to-transparent" />
        
        {/* Content */}
        <div className="absolute inset-0 flex items-end">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-16 w-full">
            {/* Breadcrumb */}
            <div className="flex items-center space-x-2 text-gray-300 text-sm mb-4 sm:mb-8">
              <Link to="/" className="hover:text-blue-400 transition-colors duration-200">Início</Link>
              <span>/</span>
              {categoryConfig && (
                <>
                  <Link 
                    to={`/categoria/${categoryConfig.slug}`}
                    className="hover:text-blue-400 transition-colors duration-200"
                  >
                    {categoryConfig.name}
                  </Link>
                  <span>/</span>
                </>
              )}
              <span className="text-gray-500">Artigo</span>
            </div>

            {/* Category badge */}
            {categoryConfig && (
              <div className="mb-3 sm:mb-6">
                <span
                  className="px-3 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm font-bold text-white backdrop-blur-md border border-white/20 rounded-full"
                  style={{ 
                    background: `linear-gradient(135deg, ${categoryConfig.color}, ${categoryConfig.color}80)`
                  }}
                >
                  {categoryConfig.name}
                </span>
              </div>
            )}
            
            {/* Title */}
            <h1 className="text-xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white mb-4 sm:mb-8 leading-tight max-w-4xl">
              {stripHtml(post.title.rendered)}
            </h1>
            
            {/* Meta info */}
            <PostMeta post={post} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostHero;
