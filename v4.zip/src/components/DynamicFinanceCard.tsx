import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import FinanceCard from './FinanceCard';

interface DynamicFinanceCardProps {
  title: string;
  keywords: string[];
  content: string;
}

const DynamicFinanceCard: React.FC<DynamicFinanceCardProps> = ({ 
  title, 
  keywords, 
  content 
}) => {
  const [detectedSymbols, setDetectedSymbols] = useState<string[]>([]);
  const [stockMap, setStockMap] = useState<Map<string, string>>(new Map());
  const [cryptoSet, setCryptoSet] = useState<Set<string>>(new Set());
  
  // Token configurado
  const TOKEN = import.meta.env.VITE_BRAPI_TOKEN || 'xp4thdSxhTeWTP2S5j62WN';

  // Se não há token, renderizar mensagem informativa
  if (!TOKEN) {
    return (
      <div className="bg-yellow-600/20 border border-yellow-600/30 rounded-lg p-4 text-yellow-200">
        <p className="text-sm">
          💡 Configure a variável VITE_BRAPI_TOKEN para exibir informações financeiras dos ativos mencionados.
        </p>
      </div>
    );
  }

  // Buscar lista de ações disponíveis
  const { data: rawStockList, isLoading: loadingStocks, error: stocksError } = useQuery<string[]>({
    queryKey: ['stocksAvailable'],
    queryFn: async () => {
      try {
        const url = `https://brapi.dev/api/available?token=${TOKEN}`;
        const res = await fetch(url);
        
        if (!res.ok) {
          throw new Error(`HTTP error! status: ${res.status}`);
        }
        
        const json = await res.json();
        
        if (!json.stocks || !Array.isArray(json.stocks)) {
          console.error('Formato de resposta inválido para ações:', json);
          return [];
        }
        
        return json.stocks;
      } catch (error) {
        console.error('Erro ao buscar ações:', error);
        throw error;
      }
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
  });

  // Buscar lista de criptomoedas disponíveis
  const { data: rawCryptoList, isLoading: loadingCryptos, error: cryptosError } = useQuery<string[]>({
    queryKey: ['cryptoAvailable'],
    queryFn: async () => {
      try {
        const url = `https://brapi.dev/api/v2/crypto/available?token=${TOKEN}`;
        const res = await fetch(url);
        
        if (!res.ok) {
          const errorText = await res.text();
          console.error('Erro HTTP criptos:', res.status, errorText);
          throw new Error(`HTTP error! status: ${res.status}`);
        }
        
        const json = await res.json();
        
        if (!json.coins || !Array.isArray(json.coins)) {
          console.error('Formato de resposta inválido para criptos:', json);
          return [];
        }
        
        // Converter para maiúsculo para consistência
        const symbols = json.coins.map((coin: string) => coin.toUpperCase());
        return symbols;
      } catch (error) {
        console.error('Erro ao buscar criptomoedas:', error);
        throw error;
      }
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
  });

  // Processar lista de ações em Map
  useEffect(() => {
    if (!loadingStocks && rawStockList && !stocksError) {
      const map = new Map<string, string>();
      rawStockList.forEach(symbol => {
        map.set(symbol, symbol);
        const baseSymbol = symbol.replace(/\.SA$/, '');
        if (baseSymbol !== symbol) {
          map.set(baseSymbol, symbol);
        }
      });
      setStockMap(map);
    }
  }, [loadingStocks, rawStockList, stocksError]);

  // Processar lista de criptomoedas em Set
  useEffect(() => {
    if (!loadingCryptos && rawCryptoList && !cryptosError) {
      const set = new Set(rawCryptoList);
      setCryptoSet(set);
    }
  }, [loadingCryptos, rawCryptoList, cryptosError]);

  // Detectar tickers no texto com regex mais preciso
  useEffect(() => {
    if (loadingStocks || loadingCryptos) {
      return;
    }

    if (stocksError && cryptosError) {
      console.error('Erros em ambas as APIs');
      return;
    }

    if (stockMap.size === 0 && cryptoSet.size === 0) {
      return;
    }
    
    const fullText = `${title || ''} ${keywords.join(' ')} ${content || ''}`;
    
    console.log('=== DETECÇÃO DE TICKERS CORRIGIDA ===');
    console.log('Texto completo:', fullText);
    
    const matches = new Set<string>();
    
    // 1. AÇÕES BRASILEIRAS - Detectar apenas tickers brasileiros (PETR4, VALE3, etc.)
    // Padrão: 4 letras + 1-2 números, opcionalmente com .SA
    const brazilianStockPattern = /\b([A-Z]{4}[0-9]{1,2}(?:\.SA)?)\b/g;
    let stockMatch;
    while ((stockMatch = brazilianStockPattern.exec(fullText)) !== null) {
      const ticker = stockMatch[1];
      console.log('Ticker brasileiro encontrado:', ticker);
      
      // Verificar se existe na lista de ações
      if (stockMap.has(ticker) || stockMap.has(ticker.replace('.SA', ''))) {
        const fullSymbol = stockMap.get(ticker) || stockMap.get(ticker.replace('.SA', ''));
        if (fullSymbol) {
          matches.add(fullSymbol);
          console.log('✅ Ação brasileira confirmada:', fullSymbol);
        }
      }
    }
    
    // 2. CRIPTOMOEDAS - Detectar APENAS entre parênteses, ignorando índices
    // Abordagem mais simples e confiável
    const parenthesesPattern = /\(([A-Z]{2,10})\)/g;
    let parenthesesMatch;
    
    // Primeiro, identificar todos os tickers que aparecem com índices para ignorá-los completamente
    const tickersWithExchanges = new Set<string>();
    const exchangePattern = /(NYSE|NASDAQ|BOVESPA|B3|LSE|TSE|HKEX|ASX|TSX|EURONEXT|XETRA|SIX|BME|MOEX|JSE|KRX|SET|IDX|PSE|TADAWUL|EGX|CSE|BSE|NSE|SSE|SZSE|TWSE|KOSDAQ|JASDAQ|MOTHERS|ChiNext|STAR|GEM|AIM|PLUS|OTCBB|OTCQX|OTCQB|PINK)[\s]*:[\s]*([A-Z]{1,10})/gi;
    let exchangeMatch;
    while ((exchangeMatch = exchangePattern.exec(fullText)) !== null) {
      const ticker = exchangeMatch[2];
      tickersWithExchanges.add(ticker.toUpperCase());
      console.log('❌ Ticker com índice identificado para ignorar:', exchangeMatch[1] + ':', ticker);
    }
    
    // Agora processar tickers entre parênteses, ignorando os que foram identificados com índices
    while ((parenthesesMatch = parenthesesPattern.exec(fullText)) !== null) {
      const ticker = parenthesesMatch[1];
      
      console.log('Ticker entre parênteses encontrado:', ticker);
      
      // Se este ticker foi identificado com um índice, ignorar completamente
      if (tickersWithExchanges.has(ticker)) {
        console.log('❌ Ignorando ticker que aparece com índice:', ticker);
        continue;
      }
      
      // Verificar se é uma criptomoeda válida
      if (cryptoSet.has(ticker)) {
        matches.add(ticker);
        console.log('✅ Criptomoeda confirmada:', ticker);
      } else {
        console.log('❌ Ticker não encontrado na lista de criptos:', ticker);
      }
    }
    
    // 3. FIIs BRASILEIROS - Detectar tickers de FIIs (terminados em 11)
    const fiisPattern = /\b([A-Z]{4}11(?:\.SA)?)\b/g;
    let fiisMatch;
    while ((fiisMatch = fiisPattern.exec(fullText)) !== null) {
      const ticker = fiisMatch[1];
      console.log('Ticker FII encontrado:', ticker);
      
      // Verificar se existe na lista de ações (FIIs estão incluídos)
      if (stockMap.has(ticker) || stockMap.has(ticker.replace('.SA', ''))) {
        const fullSymbol = stockMap.get(ticker) || stockMap.get(ticker.replace('.SA', ''));
        if (fullSymbol) {
          matches.add(fullSymbol);
          console.log('✅ FII confirmado:', fullSymbol);
        }
      }
    }
    
    const symbolsArray = Array.from(matches);
    console.log('=== SÍMBOLOS FINAIS DETECTADOS ===', symbolsArray);
    setDetectedSymbols(symbolsArray);
  }, [loadingStocks, loadingCryptos, stockMap, cryptoSet, title, keywords, content, stocksError, cryptosError]);

  // Renderizar erros se houver
  if (stocksError && cryptosError) {
    return (
      <div className="bg-red-600/20 border border-red-600/30 rounded-lg p-4 text-red-200">
        <p className="text-sm mb-2">⚠️ Erro ao carregar dados financeiros da API BRAPI.</p>
        <details className="text-xs">
          <summary className="cursor-pointer">Ver detalhes dos erros</summary>
          <div className="mt-2 space-y-1">
            {stocksError && <div>Ações: {stocksError.message}</div>}
            {cryptosError && <div>Criptos: {cryptosError.message}</div>}
          </div>
        </details>
      </div>
    );
  }

  // Se não há símbolos detectados, não renderiza nada
  if (detectedSymbols.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white mb-4">
        Ativos Mencionados
      </h3>
      {detectedSymbols.map(symbol => (
        <FinanceCard
          key={symbol}
          symbol={symbol}
          isCrypto={cryptoSet.has(symbol)}
          token={TOKEN}
        />
      ))}
    </div>
  );
};

export default DynamicFinanceCard;

