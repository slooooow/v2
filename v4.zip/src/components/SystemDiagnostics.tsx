import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, XCircle, AlertCircle, RefreshCw, Copy, ExternalLink } from 'lucide-react';
import { wordpressApi } from '../services/wordpress';
import { toast } from '@/hooks/use-toast';

interface DiagnosticResult {
  wordpressApi: boolean;
  ultimateMembers: boolean;
  jwtAuth: boolean;
  userRegistration: boolean;
  customEndpoints: boolean;
  wpMailer: boolean;
  details: {
    wordpressVersion: string | null;
    ultimateMembersVersion: string | null;
    jwtAuthVersion: string | null;
    registrationMethods: string[];
    errors: string[];
  };
}

const SystemDiagnostics: React.FC = () => {
  const [diagnostics, setDiagnostics] = useState<DiagnosticResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  const runDiagnostics = async () => {
    setIsRunning(true);
    try {
      const result = await wordpressApi.diagnoseSystem();
      setDiagnostics(result);
    } catch (error) {
      console.error('Erro no diagnóstico:', error);
      toast({
        title: "Erro no diagnóstico",
        description: "Não foi possível executar o diagnóstico completo",
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copiado!",
      description: "Código copiado para a área de transferência",
    });
  };

  const DiagnosticItem = ({ 
    label, 
    status, 
    description,
    version 
  }: { 
    label: string; 
    status: boolean; 
    description: string;
    version?: string | null;
  }) => (
    <div className="flex items-center justify-between p-3 border border-gray-600 rounded-lg">
      <div className="flex items-center space-x-3">
        {status ? (
          <CheckCircle className="w-5 h-5 text-green-500" />
        ) : (
          <XCircle className="w-5 h-5 text-red-500" />
        )}
        <div>
          <p className="text-white font-medium">{label}</p>
          <p className="text-gray-400 text-sm">{description}</p>
          {version && (
            <p className="text-gray-500 text-xs">Versão: {version}</p>
          )}
        </div>
      </div>
      <span className={`px-2 py-1 rounded text-xs font-medium ${
        status ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
      }`}>
        {status ? 'OK' : 'Erro'}
      </span>
    </div>
  );

  const customEndpointCode = `<?php
// Adicione este código ao functions.php do seu tema WordPress

add_action('rest_api_init', function () {
  register_rest_route('custom/v1', '/register', array(
    'methods' => 'POST',
    'callback' => 'custom_user_registration',
    'permission_callback' => '__return_true'
  ));
});

function custom_user_registration($request) {
  $params = $request->get_json_params();
  
  // Validar dados obrigatórios
  if (empty($params['username']) || empty($params['email']) || empty($params['password'])) {
    return new WP_Error('missing_fields', 'Campos obrigatórios não preenchidos', array('status' => 400));
  }
  
  // Verificar se usuário já existe
  if (username_exists($params['username']) || email_exists($params['email'])) {
    return new WP_Error('user_exists', 'Usuário ou email já existe', array('status' => 400));
  }
  
  // Criar usuário
  $user_id = wp_create_user(
    sanitize_user($params['username']),
    $params['password'],
    sanitize_email($params['email'])
  );
  
  if (is_wp_error($user_id)) {
    return new WP_Error('registration_failed', $user_id->get_error_message(), array('status' => 400));
  }
  
  // Atualizar campos adicionais
  if (!empty($params['first_name'])) {
    update_user_meta($user_id, 'first_name', sanitize_text_field($params['first_name']));
  }
  
  if (!empty($params['last_name'])) {
    update_user_meta($user_id, 'last_name', sanitize_text_field($params['last_name']));
  }
  
  // Definir role padrão
  $user = new WP_User($user_id);
  $user->set_role('subscriber');
  
  // Executar ações de registro
  do_action('user_register', $user_id);
  
  return array(
    'user_id' => $user_id,
    'message' => 'Usuário registrado com sucesso',
    'status' => 'success'
  );
}

// Habilitar registro no WordPress
add_filter('pre_option_users_can_register', '__return_true');

// Permitir CORS para requisições do frontend
add_action('rest_api_init', function() {
  remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
  add_filter('rest_pre_serve_request', function($value) {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    return $value;
  });
});
?>`;

  return (
    <Card className="bg-gray-800 border-gray-700 mt-6">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          Diagnóstico Avançado do Sistema
        </CardTitle>
        <CardDescription className="text-gray-400">
          Análise completa dos componentes necessários para autenticação e registro
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button
          onClick={runDiagnostics}
          disabled={isRunning}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white"
        >
          {isRunning ? (
            <>
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              Executando diagnóstico avançado...
            </>
          ) : (
            'Executar Diagnóstico Completo'
          )}
        </Button>

        {diagnostics && (
          <div className="space-y-4">
            <div className="space-y-3">
              <DiagnosticItem
                label="WordPress REST API"
                status={diagnostics.wordpressApi}
                description="API básica do WordPress"
                version={diagnostics.details.wordpressVersion}
              />
              
              <DiagnosticItem
                label="JWT Authentication"
                status={diagnostics.jwtAuth}
                description="Sistema de autenticação via token"
                version={diagnostics.details.jwtAuthVersion}
              />
              
              <DiagnosticItem
                label="Ultimate Members"
                status={diagnostics.ultimateMembers}
                description="Plugin para gerenciamento de usuários"
                version={diagnostics.details.ultimateMembersVersion}
              />
              
              <DiagnosticItem
                label="Registro via WordPress API"
                status={diagnostics.userRegistration}
                description="Permissão para criar usuários via REST API"
              />
              
              <DiagnosticItem
                label="Endpoints Customizados"
                status={diagnostics.customEndpoints}
                description="Endpoints personalizados para registro"
              />
              
              <DiagnosticItem
                label="Sistema de Email"
                status={diagnostics.wpMailer}
                description="Capacidade de envio de emails"
              />
            </div>

            {/* Métodos de registro disponíveis */}
            {diagnostics.details.registrationMethods.length > 0 && (
              <Alert className="bg-green-500/10 border-green-500/20">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <AlertDescription className="text-green-200">
                  <strong>Métodos de registro disponíveis:</strong>
                  <ul className="mt-2 list-disc list-inside">
                    {diagnostics.details.registrationMethods.map((method, index) => (
                      <li key={index}>{method}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            {/* Erros encontrados */}
            {diagnostics.details.errors.length > 0 && (
              <Alert className="bg-red-500/10 border-red-500/20">
                <XCircle className="h-4 w-4 text-red-500" />
                <AlertDescription className="text-red-200">
                  <strong>Problemas encontrados:</strong>
                  <ul className="mt-2 list-disc list-inside text-sm">
                    {diagnostics.details.errors.map((error, index) => (
                      <li key={index}>{error}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            {/* Soluções recomendadas */}
            {(!diagnostics.jwtAuth || !diagnostics.userRegistration) && (
              <div className="space-y-4">
                <Alert className="bg-yellow-500/10 border-yellow-500/20">
                  <AlertCircle className="h-4 w-4 text-yellow-500" />
                  <AlertDescription className="text-yellow-200">
                    <strong>Configuração necessária no WordPress:</strong>
                    <div className="mt-3 space-y-2">
                      {!diagnostics.jwtAuth && (
                        <div className="flex items-center justify-between">
                          <span>• Instalar plugin JWT Authentication for WP-API</span>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => window.open('https://wordpress.org/plugins/jwt-authentication-for-wp-rest-api/', '_blank')}
                            className="text-xs"
                          >
                            <ExternalLink className="w-3 h-3 mr-1" />
                            Download
                          </Button>
                        </div>
                      )}
                      {!diagnostics.ultimateMembers && (
                        <div className="flex items-center justify-between">
                          <span>• Instalar plugin Ultimate Members (recomendado)</span>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => window.open('https://wordpress.org/plugins/ultimate-member/', '_blank')}
                            className="text-xs"
                          >
                            <ExternalLink className="w-3 h-3 mr-1" />
                            Download
                          </Button>
                        </div>
                      )}
                    </div>
                  </AlertDescription>
                </Alert>

                {/* Código para endpoint customizado */}
                <Alert className="bg-blue-500/10 border-blue-500/20">
                  <AlertCircle className="h-4 w-4 text-blue-500" />
                  <AlertDescription className="text-blue-200">
                    <div className="flex items-center justify-between mb-2">
                      <strong>Solução alternativa: Endpoint customizado</strong>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(customEndpointCode)}
                        className="text-xs"
                      >
                        <Copy className="w-3 h-3 mr-1" />
                        Copiar código
                      </Button>
                    </div>
                    <p className="text-sm mb-2">
                      Adicione este código ao arquivo functions.php do seu tema WordPress:
                    </p>
                    <pre className="bg-gray-900 p-3 rounded text-xs overflow-x-auto max-h-40">
                      {customEndpointCode}
                    </pre>
                  </AlertDescription>
                </Alert>

                {/* Configurações adicionais */}
                <Alert className="bg-purple-500/10 border-purple-500/20">
                  <AlertCircle className="h-4 w-4 text-purple-500" />
                  <AlertDescription className="text-purple-200">
                    <strong>Configurações adicionais no wp-config.php:</strong>
                    <div className="mt-2 space-y-2">
                      <div className="flex items-center justify-between">
                        <code className="text-xs bg-gray-900 px-2 py-1 rounded">
                          define('WP_ALLOW_REGISTRATION', true);
                        </code>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard("define('WP_ALLOW_REGISTRATION', true);")}
                          className="text-xs"
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                      <div className="flex items-center justify-between">
                        <code className="text-xs bg-gray-900 px-2 py-1 rounded">
                          define('JWT_AUTH_SECRET_KEY', 'sua-chave-secreta');
                        </code>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard("define('JWT_AUTH_SECRET_KEY', 'sua-chave-secreta');")}
                          className="text-xs"
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </AlertDescription>
                </Alert>
              </div>
            )}

            {/* Status geral */}
            <div className="pt-4 border-t border-gray-600">
              <div className="flex items-center justify-between">
                <span className="text-gray-300">Status geral do sistema:</span>
                <span className={`px-3 py-1 rounded text-sm font-medium ${
                  diagnostics.details.registrationMethods.length > 0
                    ? 'bg-green-500/20 text-green-400'
                    : 'bg-red-500/20 text-red-400'
                }`}>
                  {diagnostics.details.registrationMethods.length > 0 ? 'Funcional' : 'Requer configuração'}
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SystemDiagnostics;

