
import React from 'react';
import { Link } from 'react-router-dom';
import { CategoryConfig } from '../types/wordpress';

interface TagsCardProps {
  categoryConfig?: CategoryConfig;
  customTags?: string[];
  contentKeywords?: string[];
  className?: string;
}

const TagsCard: React.FC<TagsCardProps> = ({ 
  categoryConfig, 
  customTags = [],
  contentKeywords = [],
  className = "" 
}) => {
  const defaultTags = ['Notícias', 'Destaque', 'Tendências'];
  const allTags = [...contentKeywords, ...customTags, ...defaultTags];

  return (
    <div className={`bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 ${className}`}>
      <h3 className="text-xl font-bold text-white mb-6">Tags</h3>
      
      <div className="flex flex-wrap gap-2">
        {categoryConfig && (
          <Link 
            to={`/categoria/${categoryConfig.slug}`}
            className="px-3 py-1 bg-gray-700/50 hover:bg-gray-700 text-gray-300 hover:text-white rounded-full text-sm transition-colors duration-200"
          >
            {categoryConfig.name}
          </Link>
        )}
        
        {allTags.slice(0, 12).map((tag, index) => (
          <span 
            key={index}
            className="px-3 py-1 bg-gray-700/50 hover:bg-gray-700 text-gray-300 hover:text-white rounded-full text-sm transition-colors duration-200 cursor-pointer"
          >
            {tag}
          </span>
        ))}
      </div>
    </div>
  );
};

export default TagsCard;
