
import React from 'react';
import { Calendar, User, Clock } from 'lucide-react';
import { formatDate, getAuthorName } from '../utils/formatting';
import { Post } from '../types/wordpress';

interface PostMetaProps {
  post: Post;
  className?: string;
}

const PostMeta: React.FC<PostMetaProps> = ({ post, className = "" }) => {
  const authorName = getAuthorName(post);

  return (
    <div className={`flex flex-wrap items-center gap-3 sm:gap-6 text-gray-300 text-sm ${className}`}>
      <div className="flex items-center space-x-2">
        <User size={14} className="sm:w-4 sm:h-4" />
        <span>{authorName}</span>
      </div>
      <div className="flex items-center space-x-2">
        <Calendar size={14} className="sm:w-4 sm:h-4" />
        <span>{formatDate(post.date)}</span>
      </div>
      <div className="flex items-center space-x-2">
        <Clock size={14} className="sm:w-4 sm:h-4" />
        <span>5 min de leitura</span>
      </div>
    </div>
  );
};

export default PostMeta;
