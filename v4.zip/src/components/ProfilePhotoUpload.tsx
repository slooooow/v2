import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Camera, Upload, User, Image, Crop, RotateCw, Download, X, Check, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';
import { wordpressApi } from '../services/wordpress';
import { useAuth } from '../hooks/useAuth';
import { useProfileSync } from '../hooks/useProfileSync';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';

interface ProfilePhotoUploadProps {
  currentPhoto?: string;
  userName: string;
  onPhotoChange: (photoUrl: string) => void;
}

interface CropArea {
  x: number;
  y: number;
  width: number;
  height: number;
}

const ProfilePhotoUpload: React.FC<ProfilePhotoUploadProps> = ({
  currentPhoto,
  userName,
  onPhotoChange,
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [showEditor, setShowEditor] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [cropArea, setCropArea] = useState<CropArea>({ x: 0, y: 0, width: 200, height: 200 });
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [gravatarEmail, setGravatarEmail] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const dropZoneRef = useRef<HTMLDivElement>(null);
  
  const { user, updateProfile } = useAuth();
  const { triggerSync } = useProfileSync();

  // Carregar avatar salvo no localStorage ou do usuário
  useEffect(() => {
    const savedAvatar = localStorage.getItem(`avatar_${user?.id}`);
    if (savedAvatar) {
      setPreviewUrl(savedAvatar);
    } else if (currentPhoto) {
      setPreviewUrl(currentPhoto);
    } else if (user?.email) {
      const gravatarUrl = getGravatarUrl(user.email);
      setPreviewUrl(gravatarUrl);
    }
  }, [currentPhoto, user]);

  // Listen for avatar updates from sync
  useEffect(() => {
    const handleAvatarUpdate = (event: CustomEvent) => {
      if (user && event.detail.userId === user.id) {
        console.log('=== UPDATING AVATAR FROM SYNC (PhotoUpload) ===', event.detail.avatar);
        setPreviewUrl(event.detail.avatar);
        onPhotoChange(event.detail.avatar);
      }
    };

    window.addEventListener('avatarUpdate', handleAvatarUpdate as EventListener);
    
    return () => {
      window.removeEventListener('avatarUpdate', handleAvatarUpdate as EventListener);
    };
  }, [user, onPhotoChange]);

  // Função para gerar Gravatar baseado no email
  const getGravatarUrl = (email: string, size: number = 200) => {
    const hash = btoa(email.toLowerCase().trim()).replace(/=+$/, '');
    return `https://www.gravatar.com/avatar/${hash}?s=${size}&d=identicon&r=g`;
  };

  // Drag and Drop handlers
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    const imageFile = files.find(file => file.type.startsWith('image/'));
    
    if (imageFile) {
      handleFileSelection(imageFile);
    }
  }, []);

  const handleFileSelection = (file: File) => {
    // Validar tipo de arquivo
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Arquivo inválido",
        description: "Por favor, selecione uma imagem válida (JPG, PNG, GIF, WebP).",
        variant: "destructive",
      });
      return;
    }

    // Validar tamanho do arquivo (máximo 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Arquivo muito grande",
        description: "A imagem deve ter no máximo 5MB.",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
    setShowEditor(true);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleFileSelection(file);
    }
  };

  const cropImage = async (): Promise<string> => {
    return new Promise((resolve) => {
      const canvas = canvasRef.current;
      const image = imageRef.current;
      
      if (!canvas || !image) {
        resolve('');
        return;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve('');
        return;
      }

      // Configurar canvas para o tamanho final
      canvas.width = 200;
      canvas.height = 200;

      // Aplicar rotação se necessário
      ctx.save();
      ctx.translate(100, 100);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.scale(zoom, zoom);

      // Desenhar a imagem cropada
      ctx.drawImage(
        image,
        cropArea.x,
        cropArea.y,
        cropArea.width,
        cropArea.height,
        -100,
        -100,
        200,
        200
      );

      ctx.restore();

      // Converter para blob
      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          resolve(url);
        } else {
          resolve('');
        }
      }, 'image/jpeg', 0.9);
    });
  };

  const handleSaveEdit = async () => {
    if (!selectedFile || !user) return;

    setIsUploading(true);

    try {
      // Criar imagem cropada
      const croppedImageUrl = await cropImage();
      
      if (!croppedImageUrl) {
        throw new Error('Erro ao processar imagem');
      }

      // Converter blob URL para File
      const response = await fetch(croppedImageUrl);
      const blob = await response.blob();
      const croppedFile = new File([blob], `avatar_${user.id}.jpg`, { type: 'image/jpeg' });

      console.log('=== INICIANDO UPLOAD DE AVATAR EDITADO ===');
      
      // Tentar fazer upload via API do WordPress
      const uploadedUrl = await wordpressApi.uploadAvatar(user.id, croppedFile);
      
      if (uploadedUrl) {
        console.log('✅ Upload bem-sucedido, salvando URL:', uploadedUrl);
        
        // Salvar no localStorage como backup
        localStorage.setItem(`avatar_${user.id}`, uploadedUrl);
        
        // Atualizar estado local
        setPreviewUrl(uploadedUrl);
        onPhotoChange(uploadedUrl);
        
        // Trigger sync para outras instâncias
        triggerSync({
          userId: user.id,
          avatar: uploadedUrl
        });
        
        toast({
          title: "Avatar atualizado!",
          description: "Sua foto de perfil foi atualizada com sucesso.",
        });
      } else {
        // Usar imagem local como fallback
        setPreviewUrl(croppedImageUrl);
        onPhotoChange(croppedImageUrl);
        localStorage.setItem(`avatar_${user.id}`, croppedImageUrl);
        
        toast({
          title: "Avatar configurado!",
          description: "Imagem salva localmente. Para sincronizar, configure o WordPress.",
        });
      }

      setShowEditor(false);
      setSelectedFile(null);
      
    } catch (error: any) {
      console.error('=== ERRO NO UPLOAD ===', error);
      
      toast({
        title: "Erro no upload",
        description: "Não foi possível atualizar o avatar. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleGravatarLoad = () => {
    if (!gravatarEmail) {
      toast({
        title: "Email necessário",
        description: "Digite um email para carregar o Gravatar.",
        variant: "destructive",
      });
      return;
    }

    const gravatarUrl = getGravatarUrl(gravatarEmail);
    setPreviewUrl(gravatarUrl);
    onPhotoChange(gravatarUrl);
    
    if (user) {
      localStorage.setItem(`avatar_${user.id}`, gravatarUrl);
      triggerSync({
        userId: user.id,
        avatar: gravatarUrl
      });
    }

    toast({
      title: "Gravatar carregado!",
      description: "Avatar do Gravatar aplicado com sucesso.",
    });
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const displayUrl = previewUrl || (user?.email ? getGravatarUrl(user.email) : '');

  return (
    <>
      <div className="flex flex-col items-center space-y-6">
        {/* Avatar principal */}
        <div className="relative group">
          <div className="w-40 h-40 rounded-full overflow-hidden bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 p-1 shadow-2xl">
            <div className="w-full h-full rounded-full overflow-hidden bg-gray-800 flex items-center justify-center">
              {displayUrl ? (
                <img 
                  src={displayUrl} 
                  alt={`Avatar de ${userName}`}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    console.log('⚠️ Erro ao carregar imagem, usando fallback');
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                  }}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-600 to-purple-600 text-white font-bold text-5xl">
                  {userName?.charAt(0).toUpperCase() || <User className="w-16 h-16" />}
                </div>
              )}
            </div>
          </div>
          
          {/* Overlay com animação aprimorada */}
          <div 
            className="absolute inset-0 bg-black/70 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 cursor-pointer backdrop-blur-sm border-2 border-white/20" 
            onClick={triggerFileInput}
          >
            <div className="text-center">
              <Camera className="w-10 h-10 text-white mx-auto mb-2" />
              <span className="text-white text-sm font-medium">Alterar</span>
            </div>
          </div>

          {/* Indicador de upload */}
          {isUploading && (
            <div className="absolute inset-0 bg-black/80 rounded-full flex items-center justify-center">
              <div className="text-center">
                <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-white mb-2"></div>
                <span className="text-white text-xs">Enviando...</span>
              </div>
            </div>
          )}
        </div>

        {/* Botões de ação */}
        <div className="flex flex-wrap gap-3 justify-center">
          <Button
            variant="outline"
            size="sm"
            onClick={triggerFileInput}
            disabled={isUploading}
            className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white hover:border-gray-500 transition-all duration-200"
          >
            <Upload className="w-4 h-4 mr-2" />
            Upload
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowEditor(true)}
            disabled={isUploading}
            className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white hover:border-gray-500 transition-all duration-200"
          >
            <Crop className="w-4 h-4 mr-2" />
            Editor
          </Button>
        </div>
        
        <p className="text-xs text-gray-500 text-center max-w-64">
          JPG, PNG, GIF ou WebP até 5MB.<br />
          Arraste e solte ou clique para selecionar.
        </p>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/gif,image/webp"
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>

      {/* Editor de imagem */}
      <Dialog open={showEditor} onOpenChange={setShowEditor}>
        <DialogContent className="max-w-4xl bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center space-x-2">
              <Image className="w-5 h-5" />
              <span>Editor de Avatar</span>
            </DialogTitle>
          </DialogHeader>

          <Tabs defaultValue="upload" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-700">
              <TabsTrigger value="upload" className="text-gray-300 data-[state=active]:bg-gray-600 data-[state=active]:text-white">
                Upload
              </TabsTrigger>
              <TabsTrigger value="gravatar" className="text-gray-300 data-[state=active]:bg-gray-600 data-[state=active]:text-white">
                Gravatar
              </TabsTrigger>
              <TabsTrigger value="default" className="text-gray-300 data-[state=active]:bg-gray-600 data-[state=active]:text-white">
                Padrão
              </TabsTrigger>
            </TabsList>

            <TabsContent value="upload" className="space-y-4">
              {/* Zona de drop */}
              <div
                ref={dropZoneRef}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 ${
                  isDragging 
                    ? 'border-blue-500 bg-blue-500/10' 
                    : 'border-gray-600 hover:border-gray-500'
                }`}
              >
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-300 mb-2">
                  Arraste uma imagem aqui ou clique para selecionar
                </p>
                <Button
                  variant="outline"
                  onClick={triggerFileInput}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Selecionar Arquivo
                </Button>
              </div>

              {/* Preview e controles de edição */}
              {selectedFile && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Preview da imagem */}
                  <div className="space-y-4">
                    <Label className="text-gray-300">Preview Original</Label>
                    <div className="relative bg-gray-700 rounded-lg overflow-hidden">
                      <img
                        ref={imageRef}
                        src={URL.createObjectURL(selectedFile)}
                        alt="Preview"
                        className="w-full h-64 object-contain"
                        style={{
                          transform: `scale(${zoom}) rotate(${rotation}deg)`,
                          transformOrigin: 'center'
                        }}
                      />
                    </div>
                  </div>

                  {/* Controles de edição */}
                  <div className="space-y-4">
                    <Label className="text-gray-300">Controles de Edição</Label>
                    
                    <div className="space-y-3">
                      <div>
                        <Label className="text-sm text-gray-400">Zoom: {zoom.toFixed(1)}x</Label>
                        <Slider
                          value={[zoom]}
                          onValueChange={(value) => setZoom(value[0])}
                          min={0.5}
                          max={3}
                          step={0.1}
                          className="mt-2"
                        />
                      </div>

                      <div>
                        <Label className="text-sm text-gray-400">Rotação: {rotation}°</Label>
                        <Slider
                          value={[rotation]}
                          onValueChange={(value) => setRotation(value[0])}
                          min={0}
                          max={360}
                          step={15}
                          className="mt-2"
                        />
                      </div>

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setRotation(rotation + 90)}
                        className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        <RotateCw className="w-4 h-4 mr-2" />
                        Girar 90°
                      </Button>
                    </div>

                    {/* Preview do resultado */}
                    <div className="bg-gray-700 rounded-lg p-4">
                      <Label className="text-sm text-gray-400 mb-2 block">Preview Final</Label>
                      <div className="w-32 h-32 mx-auto rounded-full overflow-hidden bg-gray-600">
                        <canvas
                          ref={canvasRef}
                          className="w-full h-full object-cover"
                          style={{ display: 'none' }}
                        />
                        <div className="w-full h-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-white text-2xl font-bold">
                          {userName?.charAt(0).toUpperCase()}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="gravatar" className="space-y-4">
              <div className="text-center space-y-4">
                <div className="w-32 h-32 mx-auto rounded-full overflow-hidden bg-gray-700">
                  {gravatarEmail ? (
                    <img
                      src={getGravatarUrl(gravatarEmail)}
                      alt="Gravatar Preview"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400">
                      <User className="w-12 h-12" />
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-300">Email do Gravatar</Label>
                  <Input
                    type="email"
                    placeholder="seu@email.com"
                    value={gravatarEmail}
                    onChange={(e) => setGravatarEmail(e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>

                <Button
                  onClick={handleGravatarLoad}
                  disabled={!gravatarEmail}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Carregar Gravatar
                </Button>

                <p className="text-xs text-gray-400">
                  O Gravatar é um serviço que permite usar a mesma foto de perfil em vários sites.
                  <br />
                  <a href="https://gravatar.com" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">
                    Criar conta no Gravatar.com
                  </a>
                </p>
              </div>
            </TabsContent>

            <TabsContent value="default" className="space-y-4">
              <div className="text-center space-y-4">
                <div className="w-32 h-32 mx-auto rounded-full overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-white text-4xl font-bold">
                  {userName?.charAt(0).toUpperCase()}
                </div>

                <p className="text-gray-300">
                  Avatar padrão baseado na primeira letra do seu nome
                </p>

                <Button
                  onClick={() => {
                    const defaultAvatar = `data:image/svg+xml,${encodeURIComponent(`
                      <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                          <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" style="stop-color:#3B82F6;stop-opacity:1" />
                            <stop offset="100%" style="stop-color:#8B5CF6;stop-opacity:1" />
                          </linearGradient>
                        </defs>
                        <circle cx="100" cy="100" r="100" fill="url(#grad)" />
                        <text x="100" y="130" font-family="Arial, sans-serif" font-size="80" font-weight="bold" text-anchor="middle" fill="white">
                          ${userName?.charAt(0).toUpperCase() || 'U'}
                        </text>
                      </svg>
                    `)}`;
                    
                    setPreviewUrl(defaultAvatar);
                    onPhotoChange(defaultAvatar);
                    
                    if (user) {
                      localStorage.setItem(`avatar_${user.id}`, defaultAvatar);
                    }
                    
                    setShowEditor(false);
                    
                    toast({
                      title: "Avatar padrão aplicado!",
                      description: "Avatar padrão configurado com sucesso.",
                    });
                  }}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Usar Avatar Padrão
                </Button>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter className="space-x-2">
            <Button
              variant="outline"
              onClick={() => setShowEditor(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            
            {selectedFile && (
              <Button
                onClick={handleSaveEdit}
                disabled={isUploading}
                className="bg-green-600 hover:bg-green-700"
              >
                {isUploading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Salvando...
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Salvar
                  </>
                )}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ProfilePhotoUpload;

