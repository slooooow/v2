import { LucideIcon } from 'lucide-react';

export interface Post {
  id: number;
  title: {
    rendered: string;
  };
  excerpt: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  slug: string;
  date: string;
  categories: number[];
  featured_media: number;
  _embedded?: {
    'wp:featuredmedia'?: Array<{
      source_url: string;
      alt_text: string;
    }>;
    'wp:term'?: Array<Array<{
      id: number;
      name: string;
      slug: string;
    }>>;
  };
}

export interface Comment {
  id: number;
  post: number;
  parent: number;
  author: number;
  author_name: string;
  author_url: string;
  date: string;
  content: {
    rendered: string;
  };
  status: string;
  meta: any[];
  _links: {
    self: Array<{ href: string }>;
    collection: Array<{ href: string }>;
    up: Array<{ href: string; embeddable?: boolean }>;
  };
}

export interface User {
  id: number;
  username: string;
  email: string;
  name: string;
  first_name: string;
  last_name: string;
  roles: string[];
  registered_date: string;
  display_name: string;
  slug?: string;
  url?: string;
  description?: string;
}

export interface UserRegistration {
  username: string;
  email: string;
  password: string;
  first_name?: string;
  last_name?: string;
}

export interface UserLogin {
  username: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  user: User;
  user_email?: string;
  user_nicename?: string;
  user_display_name?: string;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  count: number;
  description?: string;
}

// Export aliases for backward compatibility
export type WordPressPost = Post;
export type WordPressCategory = Category;

export interface CategoryConfig {
  slug: string;
  name: string;
  color: string;
  icon: LucideIcon;
}

export interface WordPressResponse<T> {
  data: T[];
  headers: {
    'x-wp-total': string;
    'x-wp-totalpages': string;
  };
}
