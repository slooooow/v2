import axios from 'axios';
import { WordPressPost, WordPressCategory, Comment, User, UserRegistration, UserLogin, AuthResponse } from '../types/wordpress';

const BASE_URL = 'https://news.finver.finance/wp-json/wp/v2';
const JWT_URL = 'https://news.finver.finance/wp-json/jwt-auth/v1';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
});

const jwtApi = axios.create({
  baseURL: JWT_URL,
  timeout: 15000,
});

// Interceptor para adicionar token JWT aos requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('wp_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const wordpressApi = {
  // Buscar posts com filtros
  async getPosts(params?: {
    categories?: number[];
    per_page?: number;
    page?: number;
    _embed?: boolean;
    search?: string;
    exclude?: number[];
  }) {
    try {
      const response = await api.get<WordPressPost[]>('/posts', {
        params: {
          _embed: true,
          per_page: 10,
          ...params,
        }
      });
      return response.data;
    } catch (error) {
      console.error('Erro ao buscar posts:', error);
      return [];
    }
  },

  // Buscar post por slug
  async getPostBySlug(slug: string) {
    try {
      const response = await api.get<WordPressPost[]>('/posts', {
        params: {
          slug,
          _embed: true,
        }
      });
      return response.data[0] || null;
    } catch (error) {
      console.error('Erro ao buscar post:', error);
      return null;
    }
  },

  // Buscar categorias
  async getCategories() {
    try {
      const response = await api.get<WordPressCategory[]>('/categories', {
        params: {
          per_page: 50,
          hide_empty: true,
        }
      });
      return response.data;
    } catch (error) {
      console.error('Erro ao buscar categorias:', error);
      return [];
    }
  },

  // Buscar categoria por slug
  async getCategoryBySlug(slug: string) {
    try {
      const response = await api.get<WordPressCategory[]>('/categories', {
        params: {
          slug,
        }
      });
      return response.data[0] || null;
    } catch (error) {
      console.error('Erro ao buscar categoria:', error);
      return null;
    }
  },

  // Buscar posts de uma categoria
  async getPostsByCategory(categoryId: number, page = 1, perPage = 6) {
    try {
      const response = await api.get<WordPressPost[]>('/posts', {
        params: {
          categories: categoryId,
          per_page: perPage,
          page,
          _embed: true,
        }
      });
      return {
        posts: response.data,
        total: parseInt(response.headers['x-wp-total'] || '0'),
        totalPages: parseInt(response.headers['x-wp-totalpages'] || '0'),
      };
    } catch (error) {
      console.error('Erro ao buscar posts da categoria:', error);
      return {
        posts: [],
        total: 0,
        totalPages: 0,
      };
    }
  },

  // Buscar comentários de um post
  async getCommentsByPost(postId: number) {
    try {
      const response = await api.get<Comment[]>('/comments', {
        params: {
          post: postId,
          status: 'approve',
          per_page: 50,
          orderby: 'date',
          order: 'asc',
        }
      });
      return response.data;
    } catch (error) {
      console.error('Erro ao buscar comentários:', error);
      return [];
    }
  },

  // Buscar contagem de comentários de um post
  async getCommentsCount(postId: number): Promise<number> {
    try {
      const response = await api.get<Comment[]>('/comments', {
        params: {
          post: postId,
          status: 'approve',
          per_page: 1,
        }
      });
      return parseInt(response.headers['x-wp-total'] || '0');
    } catch (error) {
      console.error('Erro ao buscar contagem de comentários:', error);
      return 0;
    }
  },

  // Diagnóstico avançado do sistema
  async diagnoseSystem() {
    const diagnostics = {
      wordpressApi: false,
      ultimateMembers: false,
      jwtAuth: false,
      userRegistration: false,
      customEndpoints: false,
      wpMailer: false,
      details: {
        wordpressVersion: null,
        ultimateMembersVersion: null,
        jwtAuthVersion: null,
        registrationMethods: [],
        errors: []
      }
    };

    try {
      // Testar API do WordPress
      console.log('🔍 Testando WordPress REST API...');
      const wpResponse = await axios.get(`${BASE_URL}`, { timeout: 10000 });
      diagnostics.wordpressApi = wpResponse.status === 200;
      
      if (wpResponse.data?.name) {
        diagnostics.details.wordpressVersion = wpResponse.data.name;
      }
      
      console.log('✅ WordPress REST API disponível');
    } catch (error: any) {
      console.log('❌ WordPress REST API indisponível:', error.message);
      diagnostics.details.errors.push(`WordPress API: ${error.message}`);
    }

    try {
      // Testar Ultimate Members
      console.log('🔍 Testando Ultimate Members API...');
      const umResponse = await axios.get('https://news.finver.finance/wp-json/ultimate-members/v1', { timeout: 10000 });
      diagnostics.ultimateMembers = umResponse.status === 200;
      
      if (umResponse.data?.version) {
        diagnostics.details.ultimateMembersVersion = umResponse.data.version;
      }
      
      console.log('✅ Ultimate Members REST API disponível');
      diagnostics.details.registrationMethods.push('Ultimate Members API');
    } catch (error: any) {
      console.log('❌ Ultimate Members REST API indisponível:', error.message);
      diagnostics.details.errors.push(`Ultimate Members: ${error.message}`);
    }

    try {
      // Testar JWT
      console.log('🔍 Testando JWT Authentication...');
      const jwtResponse = await axios.get(`${JWT_URL}`, { timeout: 10000 });
      diagnostics.jwtAuth = jwtResponse.status === 200;
      
      if (jwtResponse.data?.version) {
        diagnostics.details.jwtAuthVersion = jwtResponse.data.version;
      }
      
      console.log('✅ JWT Authentication disponível');
    } catch (error: any) {
      console.log('❌ JWT Authentication indisponível:', error.message);
      diagnostics.details.errors.push(`JWT Auth: ${error.message}`);
    }

    try {
      // Testar endpoints customizados
      console.log('🔍 Testando endpoints customizados...');
      const customResponse = await axios.get('https://news.finver.finance/wp-json/custom/v1', { timeout: 10000 });
      diagnostics.customEndpoints = customResponse.status === 200;
      console.log('✅ Endpoints customizados disponíveis');
      diagnostics.details.registrationMethods.push('Custom Endpoints');
    } catch (error: any) {
      console.log('❌ Endpoints customizados indisponíveis:', error.message);
    }

    try {
      // Testar se permite registro direto via WordPress API
      console.log('🔍 Testando registro via WordPress API...');
      const testUser = {
        username: `test_${Date.now()}`,
        email: `test_${Date.now()}@example.com`,
        password: 'test123456'
      };
      
      const regResponse = await api.post('/users', testUser, { timeout: 10000 });
      
      if (regResponse.status === 201) {
        diagnostics.userRegistration = true;
        console.log('✅ Registro de usuários permitido via WordPress API');
        diagnostics.details.registrationMethods.push('WordPress REST API');
        
        // Limpar usuário de teste
        try {
          await api.delete(`/users/${regResponse.data.id}?force=true`);
        } catch (cleanupError) {
          console.log('⚠️ Não foi possível remover usuário de teste');
        }
      }
    } catch (error: any) {
      console.log('❌ Registro via WordPress API bloqueado:', error.response?.status, error.response?.data?.message);
      diagnostics.details.errors.push(`WordPress Registration: ${error.response?.data?.message || error.message}`);
    }

    try {
      // Testar sistema de email
      console.log('🔍 Testando sistema de email...');
      const emailTest = await axios.post('https://news.finver.finance/wp-json/wp/v2/contact', {
        test: true
      }, { timeout: 10000 });
      diagnostics.wpMailer = emailTest.status === 200;
      console.log('✅ Sistema de email disponível');
    } catch (error: any) {
      console.log('❌ Sistema de email indisponível:', error.message);
    }

    console.log('📊 Diagnóstico completo:', diagnostics);
    return diagnostics;
  },

  // Verificar se email ou username já existem
  async checkUserExists(email: string, username: string): Promise<{
    emailExists: boolean;
    usernameExists: boolean;
    errors: string[];
  }> {
    const result = {
      emailExists: false,
      usernameExists: false,
      errors: []
    };

    try {
      console.log('=== VERIFICANDO USUÁRIO EXISTENTE ===');
      console.log('Email:', email, 'Username:', username);

      // Verificar em modo desenvolvimento
      if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        console.log('🔍 Verificando em modo desenvolvimento...');
        const existingUsers = JSON.parse(localStorage.getItem('dev_users') || '[]');
        
        result.emailExists = existingUsers.some((u: any) => u.email === email);
        result.usernameExists = existingUsers.some((u: any) => u.username === username);
        
        if (result.emailExists) {
          result.errors.push('Este email já está em uso');
        }
        if (result.usernameExists) {
          result.errors.push('Este username já está em uso');
        }
        
        console.log('✅ Verificação local concluída:', result);
        return result;
      }

      // Verificar via API do WordPress (produção)
      try {
        console.log('🔍 Verificando email via WordPress API...');
        const emailResponse = await api.get('/users', {
          params: { search: email },
          timeout: 10000
        });
        
        if (emailResponse.data && emailResponse.data.length > 0) {
          const userWithEmail = emailResponse.data.find((u: any) => u.email === email);
          if (userWithEmail) {
            result.emailExists = true;
            result.errors.push('Este email já está em uso');
          }
        }
      } catch (emailError: any) {
        console.log('⚠️ Não foi possível verificar email via API:', emailError.message);
      }

      try {
        console.log('🔍 Verificando username via WordPress API...');
        const usernameResponse = await api.get('/users', {
          params: { search: username },
          timeout: 10000
        });
        
        if (usernameResponse.data && usernameResponse.data.length > 0) {
          const userWithUsername = usernameResponse.data.find((u: any) => u.username === username || u.slug === username);
          if (userWithUsername) {
            result.usernameExists = true;
            result.errors.push('Este username já está em uso');
          }
        }
      } catch (usernameError: any) {
        console.log('⚠️ Não foi possível verificar username via API:', usernameError.message);
      }

      // Verificar via endpoint customizado se disponível
      try {
        console.log('🔍 Verificando via endpoint customizado...');
        const checkResponse = await axios.post(
          'https://news.finver.finance/wp-json/custom/v1/check-user',
          { email, username },
          { timeout: 10000 }
        );
        
        if (checkResponse.data) {
          result.emailExists = checkResponse.data.emailExists || result.emailExists;
          result.usernameExists = checkResponse.data.usernameExists || result.usernameExists;
          
          if (checkResponse.data.emailExists && !result.errors.includes('Este email já está em uso')) {
            result.errors.push('Este email já está em uso');
          }
          if (checkResponse.data.usernameExists && !result.errors.includes('Este username já está em uso')) {
            result.errors.push('Este username já está em uso');
          }
        }
      } catch (customError: any) {
        console.log('⚠️ Endpoint customizado não disponível:', customError.message);
      }

      console.log('✅ Verificação de usuário concluída:', result);
      return result;

    } catch (error: any) {
      console.error('=== ERRO NA VERIFICAÇÃO DE USUÁRIO ===');
      console.error('Erro:', error);
      result.errors.push('Erro ao verificar disponibilidade');
      return result;
    }
  },

  // Registrar usuário com múltiplas estratégias
  async registerUser(userData: UserRegistration): Promise<User | null> {
    try {
      console.log('=== INICIANDO REGISTRO INTELIGENTE ===');
      console.log('Dados do usuário:', { ...userData, password: '[HIDDEN]' });
      
      // Verificar se usuário já existe ANTES de tentar registrar
      const userCheck = await this.checkUserExists(userData.email, userData.username);
      
      if (userCheck.emailExists || userCheck.usernameExists) {
        console.log('❌ Usuário já existe:', userCheck.errors);
        throw new Error(userCheck.errors.join('. '));
      }
      
      // Executar diagnóstico
      const diagnostics = await this.diagnoseSystem();
      console.log('Métodos de registro disponíveis:', diagnostics.details.registrationMethods);

      // Estratégia 1: Ultimate Members API
      if (diagnostics.ultimateMembers) {
        try {
          console.log('🚀 Tentativa 1: Ultimate Members API');
          const umResponse = await axios.post(
            'https://news.finver.finance/wp-json/ultimate-members/v1/user/register',
            {
              ...userData,
              role: 'um_member'
            },
            { timeout: 15000 }
          );
          
          if (umResponse.data && umResponse.data.user_id) {
            console.log('✅ Registro bem-sucedido via Ultimate Members');
            return {
              id: umResponse.data.user_id,
              username: userData.username,
              email: userData.email,
              name: `${userData.first_name || ''} ${userData.last_name || ''}`.trim() || userData.username,
              first_name: userData.first_name || '',
              last_name: userData.last_name || '',
              roles: ['um_member'],
              registered_date: new Date().toISOString(),
              display_name: `${userData.first_name || ''} ${userData.last_name || ''}`.trim() || userData.username
            };
          }
        } catch (umError: any) {
          console.log('❌ Falha no Ultimate Members:', umError.response?.data || umError.message);
        }
      }

      // Estratégia 2: WordPress REST API
      if (diagnostics.userRegistration) {
        try {
          console.log('🚀 Tentativa 2: WordPress REST API');
          const response = await api.post<User>('/users', {
            ...userData,
            roles: ['subscriber']
          }, { timeout: 15000 });
          
          console.log('✅ Registro bem-sucedido via WordPress API');
          return response.data;
        } catch (restError: any) {
          console.log('❌ Falha no WordPress API:', restError.response?.data || restError.message);
        }
      }

      // Estratégia 3: Endpoint customizado
      if (diagnostics.customEndpoints) {
        try {
          console.log('🚀 Tentativa 3: Endpoint customizado');
          const customResponse = await axios.post(
            'https://news.finver.finance/wp-json/custom/v1/register',
            userData,
            { timeout: 15000 }
          );
          
          if (customResponse.data && customResponse.data.user_id) {
            console.log('✅ Registro bem-sucedido via endpoint customizado');
            return {
              id: customResponse.data.user_id,
              username: userData.username,
              email: userData.email,
              name: `${userData.first_name || ''} ${userData.last_name || ''}`.trim() || userData.username,
              first_name: userData.first_name || '',
              last_name: userData.last_name || '',
              roles: ['subscriber'],
              registered_date: new Date().toISOString(),
              display_name: `${userData.first_name || ''} ${userData.last_name || ''}`.trim() || userData.username
            };
          }
        } catch (customError: any) {
          console.log('❌ Falha no endpoint customizado:', customError.response?.data || customError.message);
        }
      }

      // Estratégia 4: Simulação local (desenvolvimento)
      if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        console.log('🚀 Tentativa 4: Simulação local para desenvolvimento');
        
        // Verificar se usuário já existe no localStorage
        const existingUsers = JSON.parse(localStorage.getItem('dev_users') || '[]');
        const userExists = existingUsers.find((u: any) => 
          u.username === userData.username || u.email === userData.email
        );
        
        if (userExists) {
          throw new Error('Usuário ou email já existe');
        }
        
        // Criar usuário simulado
        const newUser: User = {
          id: Date.now(),
          username: userData.username,
          email: userData.email,
          name: `${userData.first_name || ''} ${userData.last_name || ''}`.trim() || userData.username,
          first_name: userData.first_name || '',
          last_name: userData.last_name || '',
          roles: ['subscriber'],
          registered_date: new Date().toISOString(),
          display_name: `${userData.first_name || ''} ${userData.last_name || ''}`.trim() || userData.username
        };
        
        existingUsers.push({ ...newUser, password: userData.password });
        localStorage.setItem('dev_users', JSON.stringify(existingUsers));
        
        console.log('✅ Usuário criado em modo desenvolvimento');
        return newUser;
      }

      // Se nenhuma estratégia funcionou, fornecer orientações detalhadas
      const errorMessage = this.generateRegistrationErrorMessage(diagnostics);
      throw new Error(errorMessage);

    } catch (error: any) {
      console.error('=== ERRO FINAL NO REGISTRO ===');
      console.error('Erro:', error);
      throw error;
    }
  },

  // Gerar mensagem de erro detalhada para registro
  generateRegistrationErrorMessage(diagnostics: any): string {
    let message = 'Sistema de registro não configurado corretamente.\n\n';
    
    if (!diagnostics.jwtAuth) {
      message += '❌ JWT Authentication plugin não instalado\n';
    }
    
    if (!diagnostics.ultimateMembers) {
      message += '❌ Ultimate Members plugin não instalado\n';
    }
    
    if (!diagnostics.userRegistration) {
      message += '❌ Registro via WordPress API bloqueado\n';
    }
    
    message += '\n📋 SOLUÇÕES RECOMENDADAS:\n\n';
    
    message += '1️⃣ INSTALAR PLUGINS NECESSÁRIOS:\n';
    message += '• JWT Authentication for WP-API\n';
    message += '• Ultimate Members (recomendado)\n\n';
    
    message += '2️⃣ CONFIGURAR ULTIMATE MEMBERS:\n';
    message += '• Ativar "Enable registration" nas configurações\n';
    message += '• Habilitar REST API nas configurações avançadas\n\n';
    
    message += '3️⃣ ADICIONAR ENDPOINT CUSTOMIZADO:\n';
    message += 'Adicione este código ao functions.php do tema:\n\n';
    message += `add_action('rest_api_init', function () {
  register_rest_route('custom/v1', '/register', array(
    'methods' => 'POST',
    'callback' => 'custom_user_registration',
    'permission_callback' => '__return_true'
  ));
});

function custom_user_registration($request) {
  $params = $request->get_json_params();
  
  if (empty($params['username']) || empty($params['email']) || empty($params['password'])) {
    return new WP_Error('missing_fields', 'Campos obrigatórios não preenchidos', array('status' => 400));
  }
  
  $user_id = wp_create_user($params['username'], $params['password'], $params['email']);
  
  if (is_wp_error($user_id)) {
    return new WP_Error('registration_failed', $user_id->get_error_message(), array('status' => 400));
  }
  
  update_user_meta($user_id, 'first_name', sanitize_text_field($params['first_name']));
  update_user_meta($user_id, 'last_name', sanitize_text_field($params['last_name']));
  
  return array('user_id' => $user_id, 'message' => 'Usuário registrado com sucesso');
}\n\n`;
    
    message += '4️⃣ HABILITAR REGISTRO NATIVO:\n';
    message += 'No wp-config.php, adicione:\n';
    message += "define('WP_ALLOW_REGISTRATION', true);\n\n";
    
    message += '📞 Entre em contato com o administrador do site para implementar essas configurações.';
    
    return message;
  },

  // Login com múltiplos métodos (mantido igual)
  async loginUser(credentials: UserLogin): Promise<AuthResponse | null> {
    try {
      console.log('=== INICIANDO PROCESSO DE LOGIN ===');
      
      // Verificar modo desenvolvimento primeiro
      if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        console.log('🔍 Verificando login em modo desenvolvimento...');
        const devUsers = JSON.parse(localStorage.getItem('dev_users') || '[]');
        const devUser = devUsers.find((u: any) => 
          (u.username === credentials.username || u.email === credentials.username) && 
          u.password === credentials.password
        );
        
        if (devUser) {
          console.log('✅ Login bem-sucedido em modo desenvolvimento');
          const authResponse: AuthResponse = {
            token: `dev_token_${Date.now()}`,
            user: {
              id: devUser.id,
              username: devUser.username,
              email: devUser.email,
              name: devUser.name,
              first_name: devUser.first_name,
              last_name: devUser.last_name,
              roles: devUser.roles,
              registered_date: devUser.registered_date,
              display_name: devUser.display_name
            }
          };
          
          localStorage.setItem('wp_token', authResponse.token);
          localStorage.setItem('wp_user', JSON.stringify(authResponse.user));
          
          return authResponse;
        }
      }
      
      // Diagnóstico rápido do JWT
      try {
        const jwtCheck = await axios.get(`${JWT_URL}`, { timeout: 10000 });
        console.log('✅ JWT Authentication disponível');
      } catch (jwtError) {
        console.log('❌ JWT Authentication não disponível');
        throw new Error(
          'Sistema de login não configurado.\n\n' +
          'É necessário instalar e configurar o plugin JWT Authentication no WordPress.\n\n' +
          'Entre em contato com o administrador do site.'
        );
      }

      // Tentar login via JWT
      console.log('Tentando login via JWT...');
      const response = await jwtApi.post<any>('/token', {
        username: credentials.username,
        password: credentials.password
      }, { timeout: 15000 });

      console.log('=== RESPOSTA BRUTA DO JWT ===');
      console.log('Status:', response.status);
      console.log('Data:', response.data);

      if (response.data && response.data.token) {
        // Verificar se os dados do usuário estão presentes
        let userData = response.data.user;
        
        if (!userData) {
          console.log('⚠️ Dados do usuário não encontrados na resposta, tentando buscar...');
          
          // Se não há dados do usuário na resposta, tentar buscar via API
          try {
            localStorage.setItem('wp_token', response.data.token);
            
            // Buscar dados do usuário atual
            const userResponse = await api.get('/users/me');
            userData = userResponse.data;
            console.log('✅ Dados do usuário obtidos via /users/me:', userData);
          } catch (userError) {
            console.error('❌ Erro ao buscar dados do usuário:', userError);
            throw new Error('Login realizado, mas não foi possível obter dados do usuário');
          }
        }

        // Garantir que os dados essenciais existem
        const userObject: User = {
          id: userData.id || 0,
          username: userData.username || credentials.username,
          email: userData.email || '',
          name: userData.name || userData.display_name || userData.username || 'Usuário',
          first_name: userData.first_name || '',
          last_name: userData.last_name || '',
          roles: userData.roles || ['subscriber'],
          registered_date: userData.registered_date || new Date().toISOString(),
          display_name: userData.display_name || userData.name || userData.username || 'Usuário'
        };

        const authResponse: AuthResponse = {
          token: response.data.token,
          user: userObject
        };

        localStorage.setItem('wp_token', response.data.token);
        localStorage.setItem('wp_user', JSON.stringify(userObject));
        
        console.log('✅ Login bem-sucedido!');
        console.log('✅ Dados do usuário processados:', userObject);
        
        return authResponse;
      }

      throw new Error('Resposta de login inválida');

    } catch (error: any) {
      console.error('=== ERRO NO LOGIN ===');
      console.error('Erro:', error.response?.data || error.message);
      
      // Tratamento específico de erros
      if (error.response?.status === 403) {
        const errorData = error.response.data;
        
        if (errorData.code === '[jwt_auth] incorrect_password') {
          throw new Error('Senha incorreta');
        } else if (errorData.code === '[jwt_auth] invalid_username') {
          throw new Error('Usuário não encontrado');
        } else if (errorData.code === '[jwt_auth] invalid_email') {
          throw new Error('Email não encontrado');
        } else {
          throw new Error('Credenciais inválidas');
        }
      } else if (error.response?.status === 404) {
        throw new Error(
          'Endpoint de login não encontrado.\n\n' +
          'O plugin JWT Authentication não está instalado ou configurado corretamente.\n\n' +
          'Entre em contato com o administrador do site.'
        );
      } else if (error.response?.status === 500) {
        throw new Error('Erro interno do servidor. Tente novamente.');
      }
      
      throw error;
    }
  },

  // Validar token
  async validateToken(): Promise<boolean> {
    try {
      const token = localStorage.getItem('wp_token');
      if (!token) return false;
      
      // Se for token de desenvolvimento, sempre válido
      if (token.startsWith('dev_token_')) {
        return true;
      }
      
      await jwtApi.post('/token/validate', {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      return true;
    } catch (error) {
      console.error('Token inválido:', error);
      this.logout();
      return false;
    }
  },

  // Logout
  logout() {
    localStorage.removeItem('wp_token');
    localStorage.removeItem('wp_user');
  },

  // Obter usuário atual
  getCurrentUser(): User | null {
    const userString = localStorage.getItem('wp_user');
    if (userString) {
      try {
        return JSON.parse(userString);
      } catch (error) {
        console.error('Erro ao parsear usuário:', error);
        this.logout();
      }
    }
    return null;
  },

  // Verificar se está logado
  isLoggedIn(): boolean {
    return !!localStorage.getItem('wp_token');
  },

  // Buscar perfil do usuário
  async getUserProfile(userId: number): Promise<User | null> {
    try {
      const response = await api.get<User>(`/users/${userId}`);
      return response.data;
    } catch (error) {
      console.error('Erro ao buscar perfil:', error);
      return null;
    }
  },

  // Atualizar perfil do usuário
  async updateUserProfile(userId: number, data: Partial<User>): Promise<User | null> {
    try {
      const response = await api.post<User>(`/users/${userId}`, data);
      localStorage.setItem('wp_user', JSON.stringify(response.data));
      return response.data;
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
      throw error;
    }
  },

  // Alterar senha do usuário
  async changePassword(userId: number, currentPassword: string, newPassword: string): Promise<boolean> {
    try {
      console.log('=== INICIANDO ALTERAÇÃO DE SENHA ===');
      
      // Primeiro, validar a senha atual fazendo login novamente
      const currentUser = this.getCurrentUser();
      if (!currentUser) {
        throw new Error('Usuário não está logado');
      }

      // Tentar fazer login com a senha atual para validar
      try {
        const loginResponse = await jwtApi.post('/token', {
          username: currentUser.username,
          password: currentPassword
        });
        
        if (!loginResponse.data.token) {
          throw new Error('Senha atual incorreta');
        }
      } catch (loginError: any) {
        console.error('Erro ao validar senha atual:', loginError);
        if (loginError.response?.status === 403) {
          throw new Error('Senha atual incorreta');
        }
        throw new Error('Erro ao validar senha atual');
      }

      // Agora tentar alterar a senha via WordPress API
      try {
        const response = await api.post(`/users/${userId}`, {
          password: newPassword
        });
        
        console.log('✅ Senha alterada com sucesso via WordPress API');
        return true;
      } catch (updateError: any) {
        console.error('Erro ao alterar senha via API:', updateError);
        
        // Se falhar via API, tentar métodos alternativos
        if (updateError.response?.status === 403 || updateError.response?.status === 401) {
          // Tentar via endpoint customizado se existir
          try {
            const customResponse = await axios.post(
              'https://news.finver.finance/wp-json/custom/v1/change-password',
              {
                user_id: userId,
                current_password: currentPassword,
                new_password: newPassword
              },
              {
                headers: {
                  'Authorization': `Bearer ${localStorage.getItem('wp_token')}`
                }
              }
            );
            console.log('✅ Senha alterada via endpoint customizado');
            return true;
          } catch (customError) {
            console.log('Endpoint customizado não disponível');
          }
        }
        
        throw new Error(
          'Não foi possível alterar a senha.\n\n' +
          'Possíveis motivos:\n' +
          '• Permissões insuficientes no WordPress\n' +
          '• Plugin de alteração de senha não configurado\n' +
          '• Configuração de segurança bloqueando a alteração\n\n' +
          'Entre em contato com o administrador do site ou use a função "Esqueci minha senha" na página de login.'
        );
      }
    } catch (error: any) {
      console.error('=== ERRO NA ALTERAÇÃO DE SENHA ===');
      console.error('Erro:', error);
      throw error;
    }
  },

  // Criar comentário
  async createComment(postId: number, content: string, parentId?: number): Promise<Comment | null> {
    try {
      const response = await api.post<Comment>('/comments', {
        post: postId,
        content,
        parent: parentId || 0,
      });
      return response.data;
    } catch (error) {
      console.error('Erro ao criar comentário:', error);
      throw error;
    }
  },

  // Upload de avatar do usuário
  async uploadAvatar(userId: number, file: File): Promise<string | null> {
    try {
      console.log('=== INICIANDO UPLOAD DE AVATAR ===');
      
      // Primeiro, tentar fazer upload da imagem como media
      const formData = new FormData();
      formData.append('file', file);
      formData.append('title', `Avatar do usuário ${userId}`);
      formData.append('alt_text', `Avatar do usuário ${userId}`);

      const mediaResponse = await api.post('/media', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (mediaResponse.data && mediaResponse.data.source_url) {
        console.log('✅ Upload de imagem bem-sucedido:', mediaResponse.data.source_url);
        
        // Tentar atualizar o meta do usuário com a URL do avatar
        try {
          await api.post(`/users/${userId}`, {
            meta: {
              avatar_url: mediaResponse.data.source_url
            }
          });
          console.log('✅ Avatar atualizado no perfil do usuário');
        } catch (metaError) {
          console.log('⚠️ Não foi possível atualizar meta do usuário, mas upload foi bem-sucedido');
        }

        return mediaResponse.data.source_url;
      }

      return null;
    } catch (error: any) {
      console.error('=== ERRO NO UPLOAD DE AVATAR ===');
      console.error('Erro:', error.response?.data || error.message);
      
      // Se der erro de permissão, orientar sobre configuração
      if (error.response?.status === 401 || error.response?.status === 403) {
        console.log('❌ Permissões insuficientes para upload de mídia');
        throw new Error(
          'Sem permissão para upload de imagens.\n\n' +
          'É necessário configurar as permissões no WordPress para permitir upload de mídia pelos usuários.\n\n' +
          'Como alternativa, você pode usar o Gravatar.com para definir sua foto de perfil.'
        );
      }
      
      throw error;
    }
  },
};

