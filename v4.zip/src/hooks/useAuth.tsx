
import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, UserLogin, UserRegistration } from '../types/wordpress';
import { wordpressApi } from '../services/wordpress';
import { toast } from '@/hooks/use-toast';

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  isLoading: boolean;
  login: (credentials: UserLogin) => Promise<boolean>;
  register: (userData: UserRegistration) => Promise<boolean>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => Promise<boolean>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initAuth = async () => {
      const currentUser = wordpressApi.getCurrentUser();
      if (currentUser) {
        const isValid = await wordpressApi.validateToken();
        if (isValid) {
          console.log('=== USUÁRIO CARREGADO NO CONTEXTO ===');
          console.log('Current user:', currentUser);
          setUser(currentUser);
        } else {
          wordpressApi.logout();
        }
      }
      setIsLoading(false);
    };

    initAuth();
  }, []);

  const login = async (credentials: UserLogin): Promise<boolean> => {
    try {
      setIsLoading(true);
      console.log('=== INICIANDO LOGIN NO HOOK ===');
      
      const response = await wordpressApi.loginUser(credentials);
      console.log('=== RESPOSTA COMPLETA DO LOGIN ===');
      console.log('Response:', response);
      
      if (response && response.user) {
        console.log('=== DADOS DO USUÁRIO ===');
        console.log('User object:', response.user);
        console.log('User name:', response.user.name);
        console.log('User email:', response.user.email);
        
        setUser(response.user);
        console.log('✅ Login realizado com sucesso!');
        
        // Verificação segura do nome do usuário
        const userName = response.user.name || response.user.display_name || response.user.username || 'Usuário';
        
        toast({
          title: "Login realizado com sucesso!",
          description: `Bem-vindo, ${userName}!`,
        });
        return true;
      } else {
        console.error('=== RESPOSTA INVÁLIDA ===');
        console.error('Response object:', response);
        throw new Error('Resposta de login inválida - dados do usuário não encontrados');
      }
    } catch (error: any) {

    try {
      const response = await axios.post(`${baseUrl}/wp-json/ultimate-members/v1/user/register`, {
        username,
        email,
        password,
      });
      return response.data;
    } catch (ultimateError) {
      console.error("Falha no Ultimate Members:", ultimateError.response?.data || ultimateError.message);
      throw new Error("Sistema de registro não configurado corretamente.");
    }
    
      console.error('=== ERRO NO LOGIN (HOOK) ===');
      console.error('Erro:', error);
      
      toast({
        title: "Erro no login",
        description: error.message || "Erro desconhecido no login",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: UserRegistration): Promise<boolean> => {
    try {
      setIsLoading(true);
      console.log('=== INICIANDO REGISTRO NO HOOK ===');
      
      await wordpressApi.registerUser(userData);
      
      toast({
        title: "Registro realizado com sucesso!",
        description: "Você pode fazer login agora com suas credenciais.",
      });
      return true;
    } catch (error: any) {

    try {
      const response = await axios.post(`${baseUrl}/wp-json/ultimate-members/v1/user/register`, {
        username,
        email,
        password,
      });
      return response.data;
    } catch (ultimateError) {
      console.error("Falha no Ultimate Members:", ultimateError.response?.data || ultimateError.message);
      throw new Error("Sistema de registro não configurado corretamente.");
    }
    
      console.error('=== ERRO NO REGISTRO (HOOK) ===');
      console.error('Erro:', error);
      
      toast({
        title: "Erro no registro",
        description: error.message || "Erro desconhecido no registro",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    wordpressApi.logout();
    setUser(null);
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso.",
    });
  };

  const updateProfile = async (data: Partial<User>): Promise<boolean> => {
    if (!user) return false;
    
    try {
      setIsLoading(true);
      console.log('=== INICIANDO ATUALIZAÇÃO DE PERFIL ===');
      console.log('Dados recebidos:', data);
      console.log('ID do usuário:', user.id);
      
      const updatedUser = await wordpressApi.updateUserProfile(user.id, data);
      
      if (updatedUser) {
        console.log('=== USUÁRIO ATUALIZADO COM SUCESSO ===');
        console.log('Updated user:', updatedUser);
        
        // Atualizar o estado local com os novos dados
        const newUserData = { ...user, ...updatedUser };
        setUser(newUserData);
        
        // Atualizar também o localStorage
        localStorage.setItem('wordpress_user', JSON.stringify(newUserData));
        
        console.log('✅ Estado local atualizado!');
        return true;
      }
      return false;
    } catch (error: any) {

    try {
      const response = await axios.post(`${baseUrl}/wp-json/ultimate-members/v1/user/register`, {
        username,
        email,
        password,
      });
      return response.data;
    } catch (ultimateError) {
      console.error("Falha no Ultimate Members:", ultimateError.response?.data || ultimateError.message);
      throw new Error("Sistema de registro não configurado corretamente.");
    }
    
      console.error('=== ERRO NA ATUALIZAÇÃO ===', error);
      toast({
        title: "Erro ao atualizar perfil",
        description: error.response?.data?.message || "Erro ao atualizar informações",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const changePassword = async (currentPassword: string, newPassword: string): Promise<boolean> => {
    if (!user) return false;
    
    try {
      setIsLoading(true);
      await wordpressApi.changePassword(user.id, currentPassword, newPassword);
      toast({
        title: "Senha alterada com sucesso!",
        description: "Sua senha foi atualizada com segurança.",
      });
      return true;
    } catch (error: any) {

    try {
      const response = await axios.post(`${baseUrl}/wp-json/ultimate-members/v1/user/register`, {
        username,
        email,
        password,
      });
      return response.data;
    } catch (ultimateError) {
      console.error("Falha no Ultimate Members:", ultimateError.response?.data || ultimateError.message);
      throw new Error("Sistema de registro não configurado corretamente.");
    }
    
      toast({
        title: "Erro ao alterar senha",
        description: error.message || "Erro ao alterar senha",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoggedIn: !!user,
        isLoading,
        login,
        register,
        logout,
        updateProfile,
        changePassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
