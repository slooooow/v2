
import { useEffect, useCallback } from 'react';
import { useAuth } from './useAuth';

interface ProfileSyncData {
  userId: number;
  avatar?: string;
  profileData?: any;
}

export const useProfileSync = () => {
  const { user, updateProfile } = useAuth();

  // Trigger sync event when profile data changes
  const triggerSync = useCallback((data: ProfileSyncData) => {
    console.log('=== TRIGGERING PROFILE SYNC ===', data);
    
    const syncEvent = new CustomEvent('profileSync', {
      detail: data
    });
    
    window.dispatchEvent(syncEvent);
  }, []);

  // Listen for sync events from other instances
  useEffect(() => {
    const handleProfileSync = (event: CustomEvent<ProfileSyncData>) => {
      console.log('=== RECEIVED PROFILE SYNC EVENT ===', event.detail);
      
      if (!user || event.detail.userId !== user.id) return;

      // Force update the auth context with new data
      if (event.detail.profileData) {
        // Update the user data in localStorage
        const currentUser = JSON.parse(localStorage.getItem('wordpress_user') || '{}');
        const updatedUser = { ...currentUser, ...event.detail.profileData };
        localStorage.setItem('wordpress_user', JSON.stringify(updatedUser));
        
        // Trigger a re-render by updating the profile
        updateProfile(event.detail.profileData);
      }

      // Update avatar if provided
      if (event.detail.avatar) {
        localStorage.setItem(`avatar_${user.id}`, event.detail.avatar);
        
        // Trigger avatar update event
        const avatarEvent = new CustomEvent('avatarUpdate', {
          detail: { userId: user.id, avatar: event.detail.avatar }
        });
        window.dispatchEvent(avatarEvent);
      }
    };

    window.addEventListener('profileSync', handleProfileSync as EventListener);
    
    return () => {
      window.removeEventListener('profileSync', handleProfileSync as EventListener);
    };
  }, [user, updateProfile]);

  return { triggerSync };
};
