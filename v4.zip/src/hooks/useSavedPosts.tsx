import { useState, useEffect } from 'react';
import { useAuth } from './useAuth';

export interface SavedPost {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  featured_media_url?: string;
  savedAt: string;
  slug: string;
  author: string;
  category: string;
  views?: number;
}

export interface UserComment {
  id: string;
  post_id: string;
  post_title: string;
  post_slug: string;
  content: string;
  date: string;
  status: 'approved' | 'pending' | 'spam';
  author_name: string;
}

export interface UserActivity {
  id: string;
  type: 'comment' | 'save' | 'view' | 'like' | 'share';
  title: string;
  description: string;
  date: string;
  post_id?: string;
  post_slug?: string;
  icon: string;
}

export interface UserStats {
  totalViews: number;
  totalComments: number;
  totalSaved: number;
  totalLikes: number;
  totalShares: number;
  articlesRead: number;
}

export const useSavedPosts = () => {
  const { user } = useAuth();
  const [savedPosts, setSavedPosts] = useState<SavedPost[]>([]);
  const [userComments, setUserComments] = useState<UserComment[]>([]);
  const [userActivities, setUserActivities] = useState<UserActivity[]>([]);
  const [userStats, setUserStats] = useState<UserStats>({
    totalViews: 0,
    totalComments: 0,
    totalSaved: 0,
    totalLikes: 0,
    totalShares: 0,
    articlesRead: 0
  });

  // Carregar dados do localStorage quando o usuário mudar
  useEffect(() => {
    if (user) {
      loadUserData();
    } else {
      // Limpar dados quando não há usuário logado
      setSavedPosts([]);
      setUserComments([]);
      setUserActivities([]);
      setUserStats({
        totalViews: 0,
        totalComments: 0,
        totalSaved: 0,
        totalLikes: 0,
        totalShares: 0,
        articlesRead: 0
      });
    }
  }, [user]);

  const loadUserData = () => {
    if (!user) return;

    // Carregar posts salvos
    const savedPostsKey = `user_saved_posts_${user.id}`;
    const savedPostsData = localStorage.getItem(savedPostsKey);
    if (savedPostsData) {
      setSavedPosts(JSON.parse(savedPostsData));
    }

    // Carregar comentários
    const commentsKey = `user_comments_${user.id}`;
    const commentsData = localStorage.getItem(commentsKey);
    if (commentsData) {
      setUserComments(JSON.parse(commentsData));
    }

    // Carregar atividades
    const activitiesKey = `user_activities_${user.id}`;
    const activitiesData = localStorage.getItem(activitiesKey);
    if (activitiesData) {
      setUserActivities(JSON.parse(activitiesData));
    }

    // Carregar estatísticas
    const statsKey = `user_stats_${user.id}`;
    const statsData = localStorage.getItem(statsKey);
    if (statsData) {
      setUserStats(JSON.parse(statsData));
    }
  };

  const saveUserData = (posts: SavedPost[], comments: UserComment[], activities: UserActivity[], stats: UserStats) => {
    if (!user) return;

    localStorage.setItem(`user_saved_posts_${user.id}`, JSON.stringify(posts));
    localStorage.setItem(`user_comments_${user.id}`, JSON.stringify(comments));
    localStorage.setItem(`user_activities_${user.id}`, JSON.stringify(activities));
    localStorage.setItem(`user_stats_${user.id}`, JSON.stringify(stats));
  };

  const addActivity = (activity: Omit<UserActivity, 'id' | 'date'>) => {
    if (!user) return;

    const newActivity: UserActivity = {
      ...activity,
      id: Date.now().toString(),
      date: new Date().toISOString()
    };

    const updatedActivities = [newActivity, ...userActivities].slice(0, 50); // Manter apenas as 50 mais recentes
    setUserActivities(updatedActivities);

    // Atualizar estatísticas
    const updatedStats = { ...userStats };
    switch (activity.type) {
      case 'save':
        updatedStats.totalSaved++;
        break;
      case 'comment':
        updatedStats.totalComments++;
        break;
      case 'view':
        updatedStats.totalViews++;
        updatedStats.articlesRead++;
        break;
      case 'like':
        updatedStats.totalLikes++;
        break;
      case 'share':
        updatedStats.totalShares++;
        break;
    }
    setUserStats(updatedStats);

    saveUserData(savedPosts, userComments, updatedActivities, updatedStats);
  };

  const savePost = (post: Omit<SavedPost, 'savedAt'>) => {
    if (!user) return;

    const postWithSaveDate: SavedPost = {
      ...post,
      savedAt: new Date().toISOString()
    };

    const updatedPosts = [...savedPosts, postWithSaveDate];
    setSavedPosts(updatedPosts);

    // Adicionar atividade
    const newActivity: UserActivity = {
      id: Date.now().toString(),
      type: 'save',
      title: 'Publicação Salva',
      description: `Salvou "${post.title}"`,
      date: new Date().toISOString(),
      post_id: post.id,
      post_slug: post.slug,
      icon: 'bookmark'
    };

    const updatedActivities = [newActivity, ...userActivities].slice(0, 50);
    setUserActivities(updatedActivities);

    // Atualizar estatísticas
    const updatedStats = { ...userStats, totalSaved: userStats.totalSaved + 1 };
    setUserStats(updatedStats);

    saveUserData(updatedPosts, userComments, updatedActivities, updatedStats);
  };

  const unsavePost = (postId: string) => {
    if (!user) return;

    const postToRemove = savedPosts.find(p => p.id === postId);
    const updatedPosts = savedPosts.filter(post => post.id !== postId);
    setSavedPosts(updatedPosts);

    if (postToRemove) {
      // Adicionar atividade
      addActivity({
        type: 'save',
        title: 'Publicação Removida',
        description: `Removeu "${postToRemove.title}" dos salvos`,
        post_id: postId,
        post_slug: postToRemove.slug,
        icon: 'bookmark-x'
      });

      // Atualizar estatísticas
      const updatedStats = { ...userStats, totalSaved: Math.max(0, userStats.totalSaved - 1) };
      setUserStats(updatedStats);
      saveUserData(updatedPosts, userComments, userActivities, updatedStats);
    }
  };

  const addUserComment = (comment: Omit<UserComment, 'id' | 'date'>) => {
    if (!user) return;

    const newComment: UserComment = {
      ...comment,
      id: Date.now().toString(),
      date: new Date().toISOString()
    };

    const updatedComments = [newComment, ...userComments];
    setUserComments(updatedComments);

    // Adicionar atividade
    addActivity({
      type: 'comment',
      title: 'Novo Comentário',
      description: `Comentou em "${comment.post_title}"`,
      post_id: comment.post_id,
      post_slug: comment.post_slug,
      icon: 'message-square'
    });

    saveUserData(savedPosts, updatedComments, userActivities, userStats);
  };

  const removeUserComment = (commentId: string) => {
    if (!user) return;

    const commentToRemove = userComments.find(c => c.id === commentId);
    const updatedComments = userComments.filter(comment => comment.id !== commentId);
    setUserComments(updatedComments);

    if (commentToRemove) {
      // Adicionar atividade
      addActivity({
        type: 'comment',
        title: 'Comentário Removido',
        description: `Removeu comentário de "${commentToRemove.post_title}"`,
        post_id: commentToRemove.post_id,
        post_slug: commentToRemove.post_slug,
        icon: 'message-square-x'
      });

      // Atualizar estatísticas
      const updatedStats = { ...userStats, totalComments: Math.max(0, userStats.totalComments - 1) };
      setUserStats(updatedStats);
      saveUserData(savedPosts, updatedComments, userActivities, updatedStats);
    }
  };

  const trackPageView = (postId: string, postTitle: string, postSlug: string) => {
    if (!user) return;

    // Adicionar atividade
    const newActivity: UserActivity = {
      id: Date.now().toString(),
      type: 'view',
      title: 'Artigo Lido',
      description: `Leu "${postTitle}"`,
      date: new Date().toISOString(),
      post_id: postId,
      post_slug: postSlug,
      icon: 'eye'
    };

    const updatedActivities = [newActivity, ...userActivities].slice(0, 50);
    setUserActivities(updatedActivities);

    // Atualizar estatísticas
    const updatedStats = { 
      ...userStats, 
      totalViews: userStats.totalViews + 1,
      articlesRead: userStats.articlesRead + 1
    };
    setUserStats(updatedStats);

    saveUserData(savedPosts, userComments, updatedActivities, updatedStats);
  };

  const trackLike = (postId: string, postTitle: string, postSlug: string) => {
    if (!user) return;

    // Adicionar atividade
    addActivity({
      type: 'like',
      title: 'Artigo Curtido',
      description: `Curtiu "${postTitle}"`,
      post_id: postId,
      post_slug: postSlug,
      icon: 'heart'
    });
  };

  const trackShare = (postId: string, postTitle: string, postSlug: string) => {
    if (!user) return;

    // Adicionar atividade
    addActivity({
      type: 'share',
      title: 'Artigo Compartilhado',
      description: `Compartilhou "${postTitle}"`,
      post_id: postId,
      post_slug: postSlug,
      icon: 'share'
    });
  };

  const isPostSaved = (postId: string): boolean => {
    return savedPosts.some(post => post.id === postId);
  };

  const getRecentActivities = (limit: number = 10): UserActivity[] => {
    return userActivities.slice(0, limit);
  };

  return {
    savedPosts,
    userComments,
    userActivities,
    userStats,
    savePost,
    unsavePost,
    addUserComment,
    removeUserComment,
    trackPageView,
    trackLike,
    trackShare,
    isPostSaved,
    getRecentActivities,
    loadUserData
  };
};

