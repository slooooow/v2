import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft } from 'lucide-react';
import { wordpressApi } from '../services/wordpress';
import { 
  getImageUrl, 
  getCategoryFromPost 
} from '../utils/formatting';
import { getCategoryConfig } from '../utils/categories';
import { extractKeywords } from '../utils/keywords';
import LoadingSpinner from '../components/LoadingSpinner';
import FullWidthCTA from '../components/FullWidthCTA';
import RelatedPosts from '../components/RelatedPosts';
import PostHero from '../components/PostHero';
import DynamicFinanceCard from '../components/DynamicFinanceCard';
import PostContent from '../components/PostContent';
import PostSidebar from '../components/PostSidebar';

const Post = () => {
  const { slug } = useParams<{ slug: string }>();

  // Buscar post
  const { data: post, isLoading } = useQuery({
    queryKey: ['post', slug],
    queryFn: () => slug ? wordpressApi.getPostBySlug(slug) : null,
    enabled: !!slug,
  });

  // Buscar posts relacionados da mesma categoria
  const { data: relatedPosts = [] } = useQuery({
    queryKey: ['posts', 'related', post?.id],
    queryFn: async () => {
      if (!post) return [];
      
      const categorySlug = getCategoryFromPost(post);
      if (!categorySlug) {
        // Se não há categoria, busca posts gerais
        return wordpressApi.getPosts({ per_page: 4, _embed: true, exclude: [post.id] });
      }
      
      // Busca categoria pelo slug
      const category = await wordpressApi.getCategoryBySlug(categorySlug);
      if (!category) {
        return wordpressApi.getPosts({ per_page: 4, _embed: true, exclude: [post.id] });
      }
      
      // Busca posts da mesma categoria
      const categoryPosts = await wordpressApi.getPostsByCategory(category.id, 1, 4);
      // Filtra o post atual
      return categoryPosts.posts.filter(p => p.id !== post.id).slice(0, 4);
    },
    enabled: !!post,
  });

  // Scroll para o topo quando o post mudar
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0d1117' }}>
        <LoadingSpinner size="large" text="Carregando artigo..." />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0d1117' }}>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Post não encontrado</h1>
          <p className="text-gray-400 mb-6">O artigo solicitado não existe.</p>
          <Link
            to="/"
            className="inline-flex items-center space-x-2 text-blue-400 hover:text-blue-300 transition-colors duration-200"
          >
            <ArrowLeft size={16} />
            <span>Voltar ao início</span>
          </Link>
        </div>
      </div>
    );
  }

  const categorySlug = getCategoryFromPost(post);
  const categoryConfig = getCategoryConfig(categorySlug);
  const imageUrl = getImageUrl(post, 'large');
  
  // Extrair palavras-chave do conteúdo
  const contentKeywords = extractKeywords(post.content.rendered, post.title.rendered);

  // Filtrar para remover duplicatas e garantir formato
  const uniqueTickers = [...new Set(contentKeywords.filter(Boolean))];


  return (
    <div className="min-h-screen" style={{ backgroundColor: '#0d1117' }}>
      {/* Hero Section */}
      <PostHero 
        post={post}
        categoryConfig={categoryConfig}
        imageUrl={imageUrl}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 py-8 sm:py-16">
          {/* Main Content */}
          <PostContent post={post} />

          {/* Sidebar */}
          <PostSidebar 
            post={post}
            categoryConfig={categoryConfig}
            relatedPosts={relatedPosts}
            contentKeywords={contentKeywords}
          />

          {/* Posts relacionados em mobile */}
          <div className="block lg:hidden lg:col-span-12">
            <RelatedPosts posts={relatedPosts} />
          </div>
        </div>

        {/* Newsletter CTA below article */}
        <div className="py-12 sm:py-16">
          <FullWidthCTA type="newsletter" />
        </div>
      </div>
    </div>
  );
};

export default Post;
