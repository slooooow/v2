
import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Grid, List, Filter, ChevronRight, Clock, ArrowRight } from 'lucide-react';
import { wordpressApi } from '../services/wordpress';
import { getCategoryConfig } from '../utils/categories';
import { formatRelativeDate, stripHtml, getImageUrl, getAuthorName } from '../utils/formatting';
import LoadingSpinner from '../components/LoadingSpinner';
import Pagination from '../components/Pagination';
import SearchBar from '../components/SearchBar';

const Category = () => {
  const { slug } = useParams<{ slug: string }>();
  const [currentPage, setCurrentPage] = useState(1);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const postsPerPage = 12;

  // Buscar categoria
  const { data: category } = useQuery({
    queryKey: ['category', slug],
    queryFn: () => slug ? wordpressApi.getCategoryBySlug(slug) : null,
    enabled: !!slug,
  });

  // Buscar posts da categoria
  const { data: postsData, isLoading } = useQuery({
    queryKey: ['posts', 'category', category?.id, currentPage],
    queryFn: () => 
      category ? wordpressApi.getPostsByCategory(category.id, currentPage, postsPerPage) : null,
    enabled: !!category,
  });

  const categoryConfig = getCategoryConfig(slug || '');

  if (!categoryConfig) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0d1117' }}>
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Categoria não encontrada</h1>
          <p className="text-gray-400">A categoria solicitada não existe.</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen pt-16" style={{ backgroundColor: '#0d1117' }}>
        <LoadingSpinner size="large" text="Carregando posts..." />
      </div>
    );
  }

  const posts = postsData?.posts || [];
  const totalPages = postsData?.totalPages || 0;

  // Get the icon component directly
  const IconComponent = categoryConfig.icon;

  return (
    <div className="min-h-screen pt-16" style={{ backgroundColor: '#0d1117' }}>
      {/* Full-width banner */}
      <div className="relative w-screen left-1/2 right-1/2 -ml-[50vw] -mr-[50vw]">
        <div className="relative bg-gray-800/30 backdrop-blur-sm border-y border-gray-700/50">
          {/* Background with animated elements */}
          <div className="absolute inset-0 overflow-hidden">
            <div 
              className="absolute -top-32 -right-32 w-96 h-96 blur-3xl opacity-20 animate-pulse"
              style={{ 
                background: `radial-gradient(circle, ${categoryConfig.color}, transparent 70%)`
              }}
            />
            <div 
              className="absolute -bottom-32 -left-32 w-80 h-80 blur-3xl opacity-30 animate-pulse"
              style={{ 
                background: `radial-gradient(circle, ${categoryConfig.color}, transparent 70%)`
              }}
              data-delay="1s"
            />
          </div>

          <div className="relative py-20 lg:py-32">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              {/* Category icon - usando o ícone real ao invés da letra */}
              <div 
                className="w-24 h-24 mx-auto mb-8 flex items-center justify-center rounded-xl"
                style={{ 
                  background: `linear-gradient(135deg, ${categoryConfig.color}, ${categoryConfig.color}80)`
                }}
              >
                <IconComponent className="w-12 h-12 text-white" />
              </div>
              
              <h1 className="text-6xl font-black text-white mb-6 tracking-tight">
                {categoryConfig.name}
              </h1>
              
              <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-8">
                {category?.description || `Últimas notícias e análises sobre ${categoryConfig.name.toLowerCase()}`}
              </p>

              {/* Stats bar */}
              <div className="flex justify-center space-x-8 text-sm text-gray-500">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span>{posts.length} artigos encontrados</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span>Atualizado hoje</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Controls Bar */}
        <div className="py-8 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          {/* Search usando o SearchBar da navbar */}
          <div className="flex-1 max-w-md">
            <SearchBar />
          </div>

          {/* View Toggle */}
          <div className="flex items-center space-x-4">
            <div className="flex bg-gray-800/50 border border-gray-700/50 rounded-xl overflow-hidden">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-3 transition-all duration-300 ${
                  viewMode === 'grid' 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
                }`}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-3 transition-all duration-300 ${
                  viewMode === 'list' 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
                }`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Posts Grid/List - styled like homepage cards */}
        {posts.length === 0 ? (
          <div className="text-center py-20">
            <h3 className="text-2xl font-bold text-white mb-4">
              Nenhum post encontrado
            </h3>
            <p className="text-gray-400">
              Ainda não há posts nesta categoria. Volte em breve!
            </p>
          </div>
        ) : (
          <>
            <div className={viewMode === 'grid' 
              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-16' 
              : 'space-y-6 mb-16'
            }>
              {posts.map((post, index) => (
                <article 
                  key={post.id} 
                  className={`group cursor-pointer animate-fade-in-up ${
                    viewMode === 'grid' 
                      ? 'bg-gray-800/30 backdrop-blur-sm border border-gray-700/30 rounded-2xl hover:border-blue-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-blue-500/20 hover:scale-[1.02]' 
                      : 'flex bg-gray-800/30 backdrop-blur-sm border border-gray-700/30 rounded-2xl hover:border-blue-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-blue-500/20 hover:scale-[1.02]'
                  }`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <a href={`/post/${post.slug}`} className={viewMode === 'grid' ? 'block' : 'flex w-full'}>
                    {/* Image */}
                    <div className={viewMode === 'grid' 
                      ? 'aspect-video overflow-hidden rounded-t-2xl group/image' 
                      : 'w-64 aspect-video overflow-hidden rounded-l-2xl flex-shrink-0 group/image'
                    }>
                      <img
                        src={getImageUrl(post)}
                        alt={stripHtml(post.title.rendered)}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover/image:scale-110"
                        onError={(e) => {
                          e.currentTarget.src = '/placeholder.svg';
                        }}
                      />
                    </div>
                    
                    {/* Content */}
                    <div className={viewMode === 'grid' ? 'p-6' : 'flex-1 p-6 flex flex-col justify-between'}>
                      {/* Meta */}
                      <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                        <span className="flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>{formatRelativeDate(post.date)}</span>
                        </span>
                      </div>
                      
                      {/* Title */}
                      <h3 className={`font-bold text-white group-hover:text-blue-300 transition-colors duration-300 mb-3 ${
                        viewMode === 'grid' ? 'text-lg line-clamp-2' : 'text-xl line-clamp-3'
                      }`}>
                        {stripHtml(post.title.rendered)}
                      </h3>
                      
                      {/* Excerpt */}
                      <p className={`text-gray-400 mb-4 ${
                        viewMode === 'grid' ? 'text-sm line-clamp-3' : 'text-base line-clamp-2'
                      }`}>
                        {stripHtml(post.excerpt.rendered)}
                      </p>
                      
                      {/* Author and read more */}
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">
                          Por {getAuthorName(post)}
                        </span>
                        <div className="flex items-center text-blue-400 text-sm font-medium group-hover:text-blue-300 transition-colors duration-300">
                          <span>Ler mais</span>
                          <ChevronRight className="w-4 h-4 ml-1 transform group-hover:translate-x-1 transition-transform duration-300" />
                        </div>
                      </div>
                    </div>
                  </a>
                </article>
              ))}
            </div>

            {/* Pagination */}
            <div className="pb-20">
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Category;
