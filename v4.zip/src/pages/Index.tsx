
import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { wordpressApi } from '../services/wordpress';
import { CATEGORY_CONFIGS } from '../utils/categories';
import HeroSection from '../components/HeroSection';
import NewsSlider from '../components/NewsSlider';
import CategoryGrid from '../components/CategoryGrid';
import PostCard from '../components/PostCard';
import FullWidthCTA from '../components/FullWidthCTA';
import NewBannerCTA from '../components/NewBannerCTA';
import LoadingSpinner from '../components/LoadingSpinner';
import { WordPressPost } from '../types/wordpress';

const Index = () => {
  // Query para buscar posts
  const { data: posts = [], isLoading } = useQuery({
    queryKey: ['posts', 'home'],
    queryFn: () => wordpressApi.getPosts({ per_page: 50, _embed: true }),
  });

  const [categoryPosts, setCategoryPosts] = useState<{[key: string]: WordPressPost[]}>({});
  const [latestPosts, setLatestPosts] = useState<WordPressPost[]>([]);

  useEffect(() => {
    if (posts.length > 0) {
      // Primeiros 5 posts para o slider
      setLatestPosts(posts.slice(0, 5));

      // Agrupa posts por categoria - garantindo exatamente 3 posts por categoria
      const remainingPosts = posts.slice(5);
      
      const grouped = CATEGORY_CONFIGS.reduce((acc, category) => {
        // Filtra posts que realmente pertencem à categoria específica
        const categoryPosts = remainingPosts.filter(post => {
          const postCategories = post._embedded?.['wp:term']?.[0] || [];
          
          // Verifica se o post pertence à categoria atual
          const belongsToCategory = postCategories.some(cat => cat.slug === category.slug);
          
          return belongsToCategory;
        });
        
        // Garante exatamente 3 posts por categoria (ou quantos estiverem disponíveis)
        const selectedPosts = categoryPosts.slice(0, 3);
        acc[category.slug] = selectedPosts;
        
        return acc;
      }, {} as {[key: string]: WordPressPost[]});
      
      setCategoryPosts(grouped);
    }
  }, [posts]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0d1117' }}>
        <LoadingSpinner size="large" text="Carregando portal..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: '#0d1117' }}>
      {/* News Slider - Full Width Hero posicionado corretamente após navbar */}
      {latestPosts.length > 0 && (
        <div className="w-full">
          <NewsSlider posts={latestPosts} />
        </div>
      )}

      {/* Conteúdo principal */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Category Grid */}
        <CategoryGrid />

        {/* Novo CTA Banner */}
        <NewBannerCTA />

        {/* Posts por categoria - sempre 3 cards em grade */}
        {CATEGORY_CONFIGS.map((category, categoryIndex) => {
          const postsForCategory = categoryPosts[category.slug] || [];
          
          // Só mostra a seção se tiver posts da categoria
          if (postsForCategory.length === 0) return null;

          const IconComponent = category.icon;

          return (
            <div key={category.slug} className="mb-16">
              {/* Background intercalado ocupando toda a largura da tela - corrigido */}
              <div className={`${categoryIndex % 2 === 1 ? 'bg-gray-800/20' : ''} py-12 sm:py-16 w-screen relative left-1/2 -translate-x-1/2`}>
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  {/* Header da categoria com ícone */}
                  <div className="flex items-center justify-between mb-8 sm:mb-12">
                    {/* Título da categoria com ícone */}
                    <div className="flex items-center space-x-3 sm:space-x-4">
                      <div
                        className="w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center rounded-lg flex-shrink-0"
                        style={{ 
                          background: `linear-gradient(135deg, ${category.color}40, ${category.color}60)`
                        }}
                      >
                        <IconComponent 
                          className="w-5 h-5 sm:w-6 sm:h-6 text-white"
                        />
                      </div>
                      <h2 
                        className="text-2xl sm:text-3xl lg:text-4xl font-black"
                        style={{ color: category.color }}
                      >
                        {category.name}
                      </h2>
                    </div>
                    
                    {/* Link "Ver todas" - alinhado à direita */}
                    <a
                      href={`/categoria/${category.slug}`}
                      className="group flex items-center space-x-2 transition-colors duration-200 font-medium"
                      style={{ color: category.color }}
                    >
                      <span>Ver todas</span>
                      <div 
                        className="w-6 h-6 rounded-full flex items-center justify-center group-hover:opacity-80 transition-colors duration-200"
                        style={{ backgroundColor: `${category.color}20` }}
                      >
                        <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </a>
                  </div>

                  {/* Grid sempre com 3 colunas para garantir 3 cards */}
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 sm:gap-8">
                    {postsForCategory.map((post) => (
                      <div key={post.id} className="animate-fade-in-up">
                        <PostCard post={post} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* CTAs intercalados - CTA de notificação antes da última categoria */}
              {categoryIndex === CATEGORY_CONFIGS.length - 2 && (
                <FullWidthCTA type="notification" />
              )}

              {categoryIndex === 1 && (
                <FullWidthCTA type="newsletter" />
              )}
              
              {categoryIndex === 2 && (
                <FullWidthCTA type="finver" />
              )}
            </div>
          );
        })}

        {/* CTA final */}
        <FullWidthCTA type="newsletter" />
      </div>
    </div>
  );
};

export default Index;
